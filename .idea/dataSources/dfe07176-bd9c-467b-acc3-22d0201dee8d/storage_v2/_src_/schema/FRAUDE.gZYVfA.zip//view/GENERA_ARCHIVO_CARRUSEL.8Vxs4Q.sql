create view GENERA_ARCHIVO_CARRUSEL as
select "SENTENCIA" from (
select
'SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING on
SET LINESIZE 6000
spool d:\CARRUSEL_ALL\'||m.archivo||'.csv'||chr(59)||'
prompt cuenta_nueva,cc_nueva,nombres_cuenta_nueva,estado_cuenta_nueva,tel_contacto_cuenta_nueva,ot_cta_nueva,direccion_cuenta_nueva,usuario_digita,fecha_digitacion_nueva,fecha_primer_usuario_hhpp,comunidad_cuenta_nueva,division_cuenta_nueva,nodo_cuenta_nueva,tarifa_cuenta_nueva,canal,canal2,agente,descripcion,codigo_asesor,nombre_asesor,cuenta_antigua,fecha_dx_cuenta_antigua,cc_antigua,nombres_cuenta_antigua,tel_contacto_cuenta_antigua,direccion_cuenta_antigua,comunidad_cuenta_antigua,division_cuenta_antigua,tarifa_cuenta_antigua,tipo_carrusel,familiaridad,coincidencia_telefonos,fecha_reporte
Select cuenta_nueva||'||chr(39)||','||chr(39)||'||
cc_nueva||'||chr(39)||','||chr(39)||'||
nombres_cuenta_nueva||'||chr(39)||','||chr(39)||'||
estado_cuenta_nueva||'||chr(39)||','||chr(39)||'||
tel_contacto_cuenta_nueva||'||chr(39)||','||chr(39)||'||
ot_cta_nueva||'||chr(39)||','||chr(39)||'||
direccion_cuenta_nueva||'||chr(39)||','||chr(39)||'||
usuario_digita||'||chr(39)||','||chr(39)||'||
fecha_digitacion_nueva||'||chr(39)||','||chr(39)||'||
fecha_primer_usuario_hhpp||'||chr(39)||','||chr(39)||'||
comunidad_cuenta_nueva||'||chr(39)||','||chr(39)||'||
division_cuenta_nueva||'||chr(39)||','||chr(39)||'||
nodo_cuenta_nueva||'||chr(39)||','||chr(39)||'||
tarifa_cuenta_nueva||'||chr(39)||','||chr(39)||'||
canal||'||chr(39)||','||chr(39)||'||
canal2||'||chr(39)||','||chr(39)||'||
agente||'||chr(39)||','||chr(39)||'||
descripcion||'||chr(39)||','||chr(39)||'||
codigo_asesor||'||chr(39)||','||chr(39)||'||
nombre_asesor||'||chr(39)||','||chr(39)||'||
cuenta_antigua||'||chr(39)||','||chr(39)||'||
fecha_dx_cuenta_antigua||'||chr(39)||','||chr(39)||'||
cc_antigua||'||chr(39)||','||chr(39)||'||
nombres_cuenta_antigua||'||chr(39)||','||chr(39)||'||
tel_contacto_cuenta_antigua||'||chr(39)||','||chr(39)||'||
direccion_cuenta_antigua||'||chr(39)||','||chr(39)||'||
comunidad_cuenta_antigua||'||chr(39)||','||chr(39)||'||
division_cuenta_antigua||'||chr(39)||','||chr(39)||'||
tarifa_cuenta_antigua||'||chr(39)||','||chr(39)||'||
tipo_carrusel||'||chr(39)||','||chr(39)||'||
familiaridad||'||chr(39)||','||chr(39)||'||
coincidencia_telefonos||'||chr(39)||','||chr(39)||'||
fecha_reporte
from CARRUSEL C
where UPPER(c.AGENTE) like '||chr(39)||chr(37)||trim(upper(M.AGENTE))||chr(37)||chr(39)||'
and c.fecha_reporte >= to_char(sysdate-1,'||chr(39)||'YYYYMMDD'||chr(39)||')'||chr(59)||'
SPOOL OFF'||chr(59) as sentencia
from mail_agentes m WHERE ( MAIL NOT LIKE '%juan.escobar%' or MAIL NOT LIKE '%edwin.mosquera%')
ORDER BY agente asc
)
/

