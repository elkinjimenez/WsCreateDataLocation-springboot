create PACKAGE radic_movil_analisis_pkg IS

   -- Author  : ICM0613A
   -- Created : 27/09/2019 5:54:50 p. m.
   -- Purpose : Paquete que procesa los mensajes de texto que se enviaran por alarma
   FUNCTION fn_canal_cod_coddistri(vc_cod_distri VARCHAR2) RETURN VARCHAR ;
      
   PROCEDURE inserta_tramite(vc_custcode               radic_movil_data.custcode%TYPE,
                             vc_cod_comentario         radic_movil_data.cod_comentario%TYPE,
                             vc_cod_diagnostico        radic_movil_data.cod_diagnostico%TYPE,
                             vc_desc_diagnostico       radic_movil_data.desc_diagnostico%TYPE,
                             vc_nombre_analista        radic_movil_data.nombre_analista%TYPE,
                             vc_fecha_radicacion       radic_movil_data.fecha_radicacion%TYPE,
                             vc_tipo_doc_cliente       radic_movil_data.tipo_doc_cliente%TYPE,
                             vc_numero_doc_cliente     radic_movil_data.numero_doc_cliente%TYPE,
                             vc_nombre_cliente         radic_movil_data.nombre_cliente%TYPE,
                             vc_tipo_cliente           radic_movil_data.tipo_cliente%TYPE,
                             vc_co_id                  radic_movil_data.co_id%TYPE,
                             vc_estado                 radic_movil_data.estado%TYPE,
                             vc_fecha_activacion       radic_movil_data.fecha_activacion%TYPE,
                             vc_fecha_desactivacion    radic_movil_data.fecha_desactivacion%TYPE,
                             vc_causal                 radic_movil_data.causal%TYPE,
                             vc_tmcode                 radic_movil_data.tmcode%TYPE,
                             vc_tmcode_desc            radic_movil_data.tmcode_desc%TYPE,
                             vc_dealer                 radic_movil_data.dealer%TYPE,
                             vc_cod_distri             radic_movil_data.cod_distri%TYPE,
                             vc_cod_distri_nit         radic_movil_data.cod_distri_nit%TYPE,
                             vc_cod_distri_name        radic_movil_data.cod_distri_name%TYPE,
                             vc_activa_user            radic_movil_data.activa_user%TYPE,
                             vc_activa_ciudad          radic_movil_data.activa_ciudad%TYPE,
                             vc_activa_min             radic_movil_data.activa_min%TYPE,
                             vc_activa_user_habilitado radic_movil_data.activa_user_habilitado%TYPE,
                             vc_observacion            radic_movil_data.observacion%TYPE,
                             p_nm_resp                 OUT NUMBER,
                             p_vc_resp                 OUT VARCHAR2);

   PROCEDURE actualiza_tramite(vc_tipo   radic_bloqueo_users.tipo%TYPE,
                               vc_valor  radic_movil_data.activa_user%TYPE,
                               p_nm_resp OUT NUMBER,
                               p_vc_resp OUT VARCHAR2);

   PROCEDURE consulta_usuario_est(p_nm_max        IN NUMBER,
                                  p_vc_tipo       IN VARCHAR2,
                                  f_inicial       IN VARCHAR2,
                                  f_final         IN VARCHAR2,
                                  p_cur_resultado OUT SYS_REFCURSOR,
                                  p_nm_resp       OUT NUMBER,
                                  p_vc_resp       OUT VARCHAR2);

   --Modificacion 09/08/2020 inclusion de fechas de busquedas
   PROCEDURE inserta_bloqueo_usuario(vc_tipo            IN radic_bloqueo_users.tipo%TYPE,
                                     vc_cod_distri      IN radic_bloqueo_users.cod_distri%TYPE,
                                     vc_usuario         IN radic_bloqueo_users.usuario%TYPE,
                                     vc_cod_distri_name IN radic_bloqueo_users.nombre%TYPE,
                                     vc_habilitado      IN radic_bloqueo_users.activa_user_habilitado%TYPE,
                                     vc_tramite         IN radic_bloqueo_users.tramite%TYPE,
                                     vc_cantidad        IN radic_bloqueo_users.cantidad%TYPE,
                                     --09/08/2020 Inclusion de cantidad de ventas
                                     vc_fec_inicial IN VARCHAR2,
                                     vc_fec_final   IN VARCHAR2,
                                     --Fin inclusion
                                     p_nm_resp OUT NUMBER,
                                     p_vc_resp OUT VARCHAR2);

   PROCEDURE proceso_doc_inv(vc_doc_cliente  radic_movil_data.numero_doc_cliente%TYPE,
                             vc_tipo_cliente radic_movil_data.tipo_doc_cliente%TYPE,
                             p_nm_resp       OUT NUMBER,
                             p_vc_resp       OUT VARCHAR2);

   --Usuario:LC
   --Fecha:24/06/2020 
   FUNCTION fn_cantidad_kit_financiado(f_inicial VARCHAR2,
                                       f_final   VARCHAR2,
                                       usuario   VARCHAR2) RETURN NUMBER;

   FUNCTION fn_cantidad_ventas_movil(f_inicial VARCHAR2,
                                     f_final   VARCHAR2,
                                     usuario   VARCHAR2) RETURN NUMBER;

   FUNCTION fn_cantidad_repos_movil(f_inicial VARCHAR2,
                                    f_final   VARCHAR2,
                                    usuario   VARCHAR2) RETURN NUMBER;

   --Modificacion 09/08/2020 inclusion de consultas de busquedas de cantidades por codigo de distribuidor                                
   FUNCTION fn_cant_kit_coddistr(f_inicial        VARCHAR2,
                                 f_final          VARCHAR2,
                                 cod_distribuidor VARCHAR2) RETURN NUMBER;

   FUNCTION fn_cant_ventasm_coddistri(f_inicial        VARCHAR2,
                                      f_final          VARCHAR2,
                                      cod_distribuidor VARCHAR2) RETURN NUMBER;

   FUNCTION fn_cant_repos_coddistri(f_inicial        VARCHAR2,
                                    f_final          VARCHAR2,
                                    cod_distribuidor VARCHAR2) RETURN NUMBER;

   PROCEDURE pr_cons_estadistica(vc_usuario         IN VARCHAR2,
                                 vc_cod_distri      IN VARCHAR2,
                                 vc_tipo            IN VARCHAR2,
                                 nm_cant_rad        IN NUMBER,
                                 p_nm_consecutivo   OUT NUMBER,
                                 p_nm_total_tramite OUT NUMBER,
                                 p_nm_indic_fraude  OUT NUMBER,
                                 p_nm_resp          OUT NUMBER,
                                 p_vc_resp          OUT VARCHAR2);
                                 
   FUNCTION fn_es_radicado_fraude(vc_coid  radic_movil_data.co_id%type) 
     RETURN NUMBER;                                 
END radic_movil_analisis_pkg;
/

