create PACKAGE BODY PKG_SERVICIOIMEI_FASEDOS
  AS



  -----------------------------------------------------------------------------------------------------
  -- OBJETIVO: Lista las macaras de biometria pertenecientes a los cliente  de claro
  -- PARÁMETROS DE SALIDA:
  --            pCodigo:  Codigo de respuestra del proceso de ejecucion del procedimiento
  --            pDescripcion: Descripcion de respuestra del proceso de ejecucion del procedimiento
  -- FECHA:                17/09/2018
  -- REALIZADO POR:        Hayder Garcia Jimnez
  ---------------------------------------------------------------------------------------------------

 PROCEDURE REQ27NET_MAC_BIOMETRICA
    (
       pCodigo OUT NUMBER,
       pDescripcion OUT VARCHAR2,
       Dataset OUT SYS_REFCURSOR
    )
   IS
     vCantidad NUMBER := 0;
    BEGIN

    DBMS_UTILITY.EXEC_DDL_STATEMENT('TRUNCATE TABLE MAC_DISTRIBUIDORES');

        INSERT INTO MAC_DISTRIBUIDORES
        (
               SELECT a.IDSUCURSAL, a.MAC, ec.NIT, ec.NOMBRE_DISTRIBUIDOR
               FROM EMAIL_COORD_DIST ec,
               (
                    SELECT r.IDSUCURSAL, r.MAC
                    FROM MAC_CARGADAS r
                         INNER JOIN DATOS_DISTRIBUIDORES t ON r.idsucursal = t.cod_distribuidor
                  UNION
                    SELECT r.idsucursal, r.mac
                    FROM MAC_CARGADAS r
                         INNER JOIN EMAIL_COORD_DIST ec ON r.idsucursal = ec.cod_distribuidor
                    WHERE r.IDSUCURSAL NOT IN (
                                       SELECT R.IDSUCURSAL
                                       FROM MAC_CARGADAS r
                                            INNER JOIN DATOS_DISTRIBUIDORES t ON r.idsucursal = t.cod_distribuidor
                                       )
               ) a
               WHERE a.IDSUCURSAL = ec.COD_DISTRIBUIDOR
        );
        COMMIT;


        SELECT COUNT(*) AS Cantidad
        INTO vCantidad
        FROM TBL_MAC_CARGADA_ENVIADO
        WHERE TO_CHAR(FECHA) = TO_CHAR(SYSDATE);


        IF(vCantidad = 0) THEN
            INSERT INTO TBL_MAC_CARGADA_ENVIADO
            (
              SELECT DISTINCT c.IDSUCURSAL, c.MAC, c.NIT, TRIM(c.NOMBRE_DISTRIBUIDOR) AS NOMBRE_DISTRIBUIDOR,
                CASE WHEN eb.email IS NULL THEN 'NULL' ELSE eb.email END EMAIL, SYSDATE, 'NO'
                     FROM MAC_DISTRIBUIDORES c
                LEFT JOIN EMAIL_DISTR_BIOMETRIA eb ON c.nit = eb.nit
                LEFT JOIN DATOS_DISTRIBUIDORES t ON c.nit = t.nit
            );
            COMMIT;
        END IF;

        OPEN Dataset FOR
          SELECT c.IDSUCURSAL, c.MAC, c.NIT, NOMBRE_DISTRIBUIDOR,
           EMAIL, FECHA, ENVIADO
                 FROM TBL_MAC_CARGADA_ENVIADO c
           WHERE TO_CHAR(FECHA, 'DD/MM/YYYY') = TO_CHAR(SYSDATE, 'DD/MM/YYYY');

            --Asignamos valores de respuesta sin presentarse error.
            pCodigo := 0;
            pDescripcion := 'SUCCESS';
        EXCEPTION
        WHEN OTHERS THEN
        pCodigo := -1;
        pDescripcion :='Error: No controlado [' || TO_CHAR (SQLCODE) || '-' ||SUBSTR (SQLERRM, 1, 200)||']';
        ROLLBACK;
    END REQ27NET_MAC_BIOMETRICA;


  -----------------------------------------------------------------------------------------------------
  -- OBJETIVO: Permite actualizar el campo ENVIO de la tabla TBL_MAC_CARGADA_ENVIADO
  -- PARÁMETROS DE SALIDA:
  --            pCodigo:  Codigo de respuestra del proceso de ejecucion del procedimiento
  --            pDescripcion: Descripcion de respuestra del proceso de ejecucion del procedimiento
  -- FECHA:                11/10/2018
  -- REALIZADO POR:        Hayder Garcia Jimnez
  ---------------------------------------------------------------------------------------------------

PROCEDURE REQ27NET_CRUP_ENVIO
    (
       pValor1 IN VARCHAR2, 
       pValor2 IN VARCHAR2, 
       pValor3 IN VARCHAR2, 
       pOpcion In VARCHAR2,              
       pCodigo OUT NUMBER,
       pDescripcion OUT VARCHAR2     
    )
    IS
    BEGIN
      
      IF(pOpcion = 'UPDATE') THEN
          UPDATE TBL_MAC_CARGADA_ENVIADO SET ENVIADO = pValor1 WHERE NIT = pValor2;
          COMMIT;
      END IF;  
      
      IF(pOpcion = 'INSERT') THEN
          INSERT INTO MAC_CARGADAS (IDSUCURSAL, MAC) VALUES (pValor1, pValor2);
          COMMIT;
      END IF; 
      
       IF(pOpcion = 'INSERT_MAC_FITRAR') THEN    
          INSERT INTO TBL_27_MAC_CARGADA (SUCURSALID, DIRECCION_MAC, FECHA_CREACION) VALUES (pValor1, pValor2, TO_DATE(pValor3, 'MM/dd/yyyy'));
          COMMIT;
      END IF;  
      
      --Asignamos valores de respuesta sin presentarse error.
            pCodigo := 0; 
            pDescripcion := 'SUCCESS';  
       EXCEPTION
       WHEN OTHERS THEN
       pCodigo := -1;
       pDescripcion :='Error: No controlado [' || TO_CHAR (SQLCODE) || '-' ||SUBSTR (SQLERRM, 1, 200)||']';
       ROLLBACK;   
    END REQ27NET_CRUP_ENVIO;
 END;
/

