create procedure Proc_alarmas_new_TMX_HFC
is

CURSOR c_acum_CDR_completa IS
select a.ABONADO_A,                      
       a.ACUM_DURA_REAL  ,               
       a.ACUM_DURA_LIQUI  ,              
       a.ACUM_CANT_LLAM    ,             
       a.ACUM_DIAS          ,
       a.acum_valor,
       A.FECHA_MIN,
       A.FECHA_MAX,
       a.tipo_trafico,
       a.avg_ab_b_dif,
       ceil(A.DESTINOS_DIF) destinos_dif,
       ROUND(a.acum_cant_llam/a.acum_dias) AS llamadas_prom_dia,
       ROUND(H.ACUM_CANT_LLAM/H.acum_dias) as Llamadas_prom_dia_historico,
       ROUND(a.acum_dura_liqui/a.acum_dias) as Minutos_prom_dia,
       ROUND(H.acum_dura_liqui/h.acum_dias) as Minutos_prom_dia_historico,
       ROUND((ROUND(a.acum_cant_llam/a.acum_dias)-ROUND(H.ACUM_CANT_LLAM/H.acum_dias))/ROUND(H.ACUM_CANT_LLAM/H.acum_dias)*100) as PORC_DESV_LLAM_RESP_HISTORICO,
       ROUND((ROUND(a.acum_dura_liqui/a.acum_dias)-ROUND(H.acum_dura_liqui/H.acum_dias))/ROUND(H.acum_dura_liqui/H.acum_dias)*100) as PORC_DESV_MIN_RESP_HISTORICO,
       ROUND(TO_NUMBER(SYSDATE - TO_DATE(SUBSTR(C.FECHA_DIGITACION,1,10),'YYYYMMDD'))/30) AS MESES_DE_INSTALADO,
       ROUND(TO_NUMBER(H.ACUM_DIAS/30)) AS MESES_DE_CONSUMO,
       B.MUNICIPIO_SERVICIO POBLACION      ,
       B.CIUDAD DEPTO,          
       'TELMEX HFC' OPERADOR,
       CASE WHEN C.TIPO_CLIENTE IN ('RE','CM','SE') THEN  'RESIDENCIAL'
       WHEN C.TIPO_CLIENTE IN ('PY','TE') THEN 'PYME PEQUE?A' 
       WHEN C.TIPO_CLIENTE IS NULL THEN 'RESIDENCIAL' 
       ELSE 'NA'
       END SEGMENTO,
--       C.cod_suca,
--       C.des_suca,
       '' enlace,
       '' IP,
       C.CUENTA CODIGO_CLIENTE,
       C.NOMBRE nombre_cliente,
       C.CC_NIT NTDIDE,
       C.TIPO_DOC TIPDIDE,
       C.FECHA_DIGITACION FECHA_ASIGNACION,
       C.RENTA_MENSUAL PROMEDIO_FACTURACION,
       C.SALDO_ACTUAL SALDO_ACTUAL,
       C.DIRECCION DIRCLI,
       C.NUMERO_CONTRATO plan_facturacion,
       C.FV fv,
       g.fec_deteccion,
       g.dias_vigencia
from   cdr_acum_total_tmx_HFC a, NUMERACION_TELMEX_HFC b, suscriptores_tmx_HFC c, LISTADO_GRISES G, CDR_HISTORICO_TMX_HFC H
where  a.abonado_a between b.DESDE(+) and b.HASTA(+) and  
       a.abonado_a = c.telefono(+) and a.abonado_a=g.abonado(+)
       and a.tipo_trafico = h.tipo_trafico(+)
       AND A.ABONADO_A = H.ABONADO_A(+)
       and A.ABONADO_A NOT  IN (SELECT M.NUMERO FROM MAESTRA_BLANCOS M)
       and a.acum_dura_liqui>0 
       AND A.TIPO_TRAFICO IN (SELECT s.grupo FROM SERVICIOS_MONITOREO s WHERE s.monitoreo='SI');

--       and (c.des_cate = 'RESIDENCIAL' or c.des_cate = 'RESIDENCIALES')
--       AND (A.ACUM_DURA_REAL > H.CANT_MINUTOS OR A.ACUM_CANT_LLAM > H.CANT_LLAMADAS OR C.SAL_PEND > H.SALDO_PEND);

--      and substr(A.ABONADO_A,2,8) not in (SELECT dav_telef FROM davox) 
-- En esta parte se iba a incluior no tener en cuenta los abonados que tiene conevnios de VOZ Corporativa en Davox. 20/10/2006 pero era muy demorado                 
                  
r_consulta c_acum_CDR_completa%rowtype;


v_fec_gen_alarma            date;
v_cant_llamadas             number;
v_cant_minutos              number;
m_cant_llamadas             number;
m_cant_minutos              number;
v_saldo_pend                number;
v_fact_ven                  number;
v_tipo_comp                 number;
v_acum_dias                 number;
V_DIAS_VIGENCIA               NUMBER;
V_FECHA_DETECCION             DATE;

BEGIN


v_fec_gen_alarma:=sysdate;

Open c_acum_CDR_completa;

  Loop
  
    Fetch c_acum_CDR_completa into  r_consulta;
    exit when c_acum_CDR_completa%notfound;

-- Extraemos los umbrales
             
             BEGIN
           
                select k.cant_llamadas into v_cant_llamadas  from umbrales k
                where k.grupo=r_consulta.tipo_trafico
                AND TRIM(K.SEGMENTO) = TRIM(R_CONSULTA.SEGMENTO);

                select K.cant_minutos into v_cant_minutos  from umbrales k
                where k.grupo=r_consulta.tipo_trafico
                AND TRIM(K.SEGMENTO) = (R_CONSULTA.SEGMENTO);
                
 
            END;    
             
             
-- Incluimos en la tabla alarmas_new los abonados que superen los valores de cantidad de llamadas, minutos, saldo pendiente, categoria              
             
             IF r_consulta.fec_deteccion is null  OR  (SYSDATE-r_consulta.Fec_Deteccion) < r_consulta.Dias_Vigencia THEN
             
             if (((r_consulta.acum_cant_llam/ r_consulta.acum_dias > v_cant_llamadas) or (r_consulta.ACUM_DURA_REAL /r_consulta.acum_dias  > v_CANT_MINUTOS))) THEN 
             insert into alarmas_new_tmx_HFC (CODIGO_CLIENTE,
                                      enlace,
                                      ABONADO_A,
                                      ACUM_DURA_REAL,
                                      ACUM_DURA_LIQUI,
                                      ACUM_CANT_LLAM,
                                      avg_ab_b_dif,
                                      DESTINOS_DIF,
                                      PROM_MIN_DIARIO,
                                      PROM_LLAM_DIARIA,
                                      PROM_VALOR_DIARIO,
                                      PROM_MIN_DIARIO_HISTORICO,
                                      PROM_LLAM_DIARIA_HISTORICO,
                                      PORC_DESV_LLAM_RESP_HISTORICO,
                                      PORC_DESV_MIN_RESP_HISTORICO,
                                      MESES_DE_INSTALADO,
                                      MESES_DE_CONSUMO,
                                      TIPO_TRAFICO,
                                      ACUM_DIAS,
                                      OPERADOR,
                                      OPERADOR_NUESTRO,
                                      NOMBRE_CLIENTE,
                                      NTDIDE,
                                      TIPDIDE,
                                      FECHA_ASIGNACION,
                                      DIRECCION,
                                      SEGMENTO,
                                      PROMEDIO_FACTURACION,
                                      SALDO_ACTUAL,
                                      DES_SUBCATEGORIA,
                                      DESC_CATEGORIA,
                                      FV,
                                      POBLACION,
                                      DEPTO,
                                      FECHA_MIN_CONS,
                                      FECHA_MAX_CONS,
                                      FEC_GEN_ALARMA,
                                      IP,
                                      PLAN_FACTURACION
                                      )
                values (              r_consulta.CODIGO_CLIENTE,
                                      r_consulta.enlace,
                                      r_consulta.ABONADO_A,
                                      r_consulta.ACUM_DURA_REAL,
                                      r_consulta.ACUM_DURA_LIQUI,
                                      r_consulta.ACUM_CANT_LLAM,
                                      r_consulta.avg_ab_b_dif,
                                      r_consulta.destinos_dif,
                                      r_consulta.minutos_prom_dia,
                                      r_consulta.llamadas_prom_dia,
                                      round(r_consulta.acum_valor/r_consulta.acum_dias),
                                      R_CONSULTA.MINUTOS_PROM_DIA_HISTORICO,
                                      R_CONSULTA.LLAMADAS_PROM_DIA_HISTORICO,
                                      R_CONSULTA.PORC_DESV_LLAM_RESP_HISTORICO,
                                      R_CONSULTA.PORC_DESV_MIN_RESP_HISTORICO,
                                      R_CONSULTA.MESES_DE_INSTALADO,
                                      R_CONSULTA.MESES_DE_CONSUMO,
                                      r_consulta.TIPO_TRAFICO,
                                      r_consulta.ACUM_DIAS,
                                      r_consulta.OPERADOR,
                                      Decode(r_consulta.OPERADOR,'TELMEX','SI','TELMEX HFC', 'SI','TELEFONIA POR CABLE','SI'),
                                      r_consulta.NOMBRE_CLIENTE,
                                      r_consulta.NTDIDE,
                                      r_consulta.TIPDIDE,
                                      r_consulta.FECHA_ASIGNACION,
                                      r_consulta.DIRCLI,
                                      r_consulta.SEGMENTO,
                                      ROUND(TO_NUMBER(r_consulta.PROMEDIO_FACTURACION)),
                                      ROUND(TO_NUMBER(r_consulta.SALDO_ACTUAL)),
                                      NULL,
                                      NULL,
                                      r_consulta.fv,
                                      r_consulta.POBLACION,
                                      r_consulta.DEPTO,
                                      r_consulta.FECHA_MIN,
                                      r_consulta.FECHA_MAX,
                                      v_fec_gen_alarma,
                                      r_consulta.Ip,
                                      r_consulta.Plan_Facturacion
                                      );
             end if;
             END IF;
     commit;
       r_consulta:=null;   
     --  v_umbral:=0; v_diferencia:=0; v_porc_desv:=0; 
       
  end loop;
     
close c_acum_CDR_completa;


end;
/

