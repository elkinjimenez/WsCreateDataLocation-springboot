create procedure Distribucion_Spool_ESP is
  --CURSOR DE LA TABLA DEL SPOOL TEMP
  CURSOR spool is 
   SELECT * FROM SPOOL_FORMATO_TEMP_ESP;
  factura number(6);
BEGIN

   -- DISTRIBUIR
   FOR C IN SPOOL LOOP

       --Captura factura
       ------------------------------------------------------------------------------   
       IF substr(C.SERSUT_NUMSUT,1,4) = '1.1.' THEN
            Factura := Substr(C.SERSUT_NUMSUT,12,6);
       
           --Campos registros hoja principal
           ------------------------------------------------------------------------------       
           INSERT INTO SPOOL_HOJAPRINCIPAL_ESP VALUES 
           (
                Substr(C.SERSUT_NUMSUT,12,6),     --NUMSUT                         VARCHAR2(200),
                Trim(C.PERIODO_FACTURADO_INICIO), --PERIODOFACTURADOINICIO         VARCHAR2(200),
                Trim(C.PERIODO_FACTURADO_FIN),    --PERIODOFACTURADOFIN            VARCHAR2(200),
                Trim(C.FECHA_EXPEDICION),         --FECHAEXPEDICION                VARCHAR2(200),
                Trim(C.FECHA_VENCIMIENTO),        --FECHAVENCIMIENTO               VARCHAR2(200),
                Trim(C.Fecha_Corte_Novedades),    --FECHACORTENOVEDADES            VARCHAR2(200),
                Trim(C.Meses_Mora),               --MESESMORA                      NUMBER,
                ltrim(C.nombre_cliente),          --NOMBRECLIENTE                  VARCHAR2(200)
                Trim(C.NIT),                      --NIT                            VARCHAR2(200),
                ltrim(C.DIRECCION),               --DIRECCION                      NUMBER,
                Trim(C.CIUDAD),                   --CIUDAD                         NUMBER,
                Trim(C.CODCLI),                   --CODCLI                         NUMBER,
                Trim(C.Referencia_Para_Pago),     --REFERENCIAPAGO                 VARCHAR2(200),
                Trim(C.Lectura_Anterior),         --LECTURAANTERIOR                NUMBER,
                Trim(C.Lectura_Actual),           --LECTURAACTUAL                  NUMBER,
                Trim(C.Consumo_Actual),--CONSUMOACTUAL                  NUMBER,
                Trim(C.Promedio),--PROMEDIO                       NUMBER,
                Trim(C.Consumo_Mes_1),--CONSUMOMES1                    VARCHAR2(200),
                Trim(C.Consumo_Mes_2),--CONSUMOMES2                    VARCHAR2(200),
                Trim(C.Consumo_Mes_3),--CONSUMOMES3                    VARCHAR2(20),
                Trim(C.Consumo_Mes_4),--CONSUMOMES4                    VARCHAR2(20),
                Trim(C.Consumo_Mes_5),--CONSUMOMES5                    VARCHAR2(20),
                Trim(C.Consumo_Mes_6),--CONSUMOMES6                    VARCHAR2(20),
                Trim(C.Consumo_Mes_Actual),--CONSUMOMESACTUAL               VARCHAR2(20),
                Trim(C.Nombre_Mes_1),--NOMBREMES1                     VARCHAR2(5),
                Trim(C.Nombre_Mes_2),--NOMBREMES2                     VARCHAR2(5),
                Trim(C.Nombre_Mes_3),--NOMBREMES3                     VARCHAR2(5),
                Trim(C.Nombre_Mes_4),--NOMBREMES4                     VARCHAR2(5),
                Trim(C.Nombre_Mes_5),--NOMBREMES5                     VARCHAR2(5),
                Trim(C.Nombre_Mes_6),--NOMBREMES6                     VARCHAR2(5),
                Trim(C.Nombre_Mes_Actual),--NOMBREMESACTUAL                VARCHAR2(5),
                Ltrim(C.Mensaje),--MENSAJE                        VARCHAR2(300),
                REPLACE(REPLACE(REPLACE(C.Total_Conceptos_Tpblc,' ',''),'$',''),',',''),--TOTALCONCEPTOSTPBLC            NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Telmex_Sa,' ',''),'$',''),',',''),--TOTALTELMEXSA                  NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Conceptos,' ',''),'$',''),',',''),--TOTALCONCEPTOS                 NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Otros_Operadores,' ',''),'$',''),',',''),--TOTALOTROSOPERADORES           NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Impuestos,' ',''),'$',''),',',''),--NOMBREIMPUESTOLOCAL            NUMBER,
                C.Iva_Servicios_Impuesto_Local,--IVASERVICIOSIMPUESTOLOCAL      NUMBER,
                REPLACE(REPLACE(REPLACE(C.Iva_Telmex_Col,' ',''),'$',''),',',''),  --NUMBER,
                REPLACE(REPLACE(REPLACE(C.Iva_Telmex_Esp,' ',''),'$',''),',',''),--IVATELMEXESP                   NUMBER,
                REPLACE(REPLACE(REPLACE(C.Iva_Otros_Op,' ',''),'$',''),',',''),--IVAOTROSOP                     NUMBER,
                REPLACE(REPLACE(REPLACE(C.Contribucion,' ',''),'$',''),',',''),--CONTRIBUCION                   NUMBER,
                REPLACE(REPLACE(REPLACE(C.Reteiva,' ',''),'$',''),',',''),--RETEIVA                        NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Impuestos,' ',''),'$',''),',',''),--TOTALIMPUESTOS                 NUMBER,
                REPLACE(REPLACE(REPLACE(C.Gracias_Por_Su_Pago,' ',''),'$',''),',',''),--GRACIASPORPAGO                 NUMBER,
                REPLACE(REPLACE(REPLACE(C.Saldo_Anterior,' ',''),'$',''),',',''), --SALDOANTERIOR                  NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Conceptos_Telmex,' ',''),'$',''),',',''),--TOTALCONCEPTOSTELMEX           NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Conceptos_Otros_Op,' ',''),'$',''),',',''),--TOTALCONCEPTOSOTROSOP          NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Mora,' ',''),'$',''),',',''),--TOTALMORA                      NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Impu_Contr_Reten,' ',''),'$',''),',',''),--TOTALIMPUESTOSCONTRRETENCIONES NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Retenciones,' ',''),'$',''),',',''),--TOTALRETENCIONES               NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_Ajuste_Decena,' ',''),'$',''),',',''),--TOTALAJUSTEDECENA              NUMBER,
                REPLACE(REPLACE(REPLACE(C.Total_a_Pagar,' ',''),'$',''),',','')--TOTALPAGAR                     NUMBER
       );
           COMMIT;
       END IF;
       
       /*       
       --Campos registros hoja ESP
       ------------------------------------------------------------------------------
       IF substr(C.SERSUT_NUMSUT,2,5) = "2.1." THEN
                           
           INSERT INTO SPOOL_FORMATOANEX1_ESP VALUES 
           (
                Factura, --NUMSUT              NUMBER,
                --NUMEROITEM          NUMBER,
                --CODIGOENLACE        VARCHAR2(10),
                --DETALLE             VARCHAR2(20),
                --CANTIDAD            NUMBER,
                --NOLINEAS            NUMBER,
                --MINUTOSPLANELEGIDO  VARCHAR2(20),
                --VALORPLANELEGIDO    NUMBER,
                --MINUTOSADICIONALES  NUMBER,
                --CONSUMOSADICIONALES NUMBER,
                --CONTRIBUCION        NUMBER,
                --FECHADESDE          DATE,
                --FECHAHASTA          DATE,
                --TOTAL               NUMBER           
            );

       END IF;*/


   
   END LOOP;
    
  
  
  
  
END Distribucion_Spool_ESP;
/

