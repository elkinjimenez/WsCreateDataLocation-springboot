create PACKAGE BODY "PK_CONSULTA_FRAUDE" IS

  PROCEDURE PR_TERCER_PAIS_EMPRESAS(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_TERCER_PAIS_EMPRESAS
    **
    ** DESCRIPTION:    CONSULTA LOS FRAUDES DE TERCER PAIS DE EMPRESAS
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 19-NOV-09      GUSTAVO GOMEZ  CREACION                     2.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LOS FRAUDES DE TERCER PAIS DE EMPRESAS
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
SELECT DISTINCT case
                  when substr(R.CALLER_NUMBER, 1, 2) = '57' and
                       length(trim(R.CALLER_NUMBER)) = 12 then
                   substr(R.CALLER_NUMBER, 3, 10)
                  else
                   R.CALLER_NUMBER
                end AS TELEFONO,
                '' CLIENTE,
                '' CUENTA,
                '' FECHA,
                '' TRAFICO,
                '' DESTINO,
                'TERCER PAIS CORPORATIVO' AS TIPO_ALARMA,
                R.LLAMADAS,
                R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                R.MINUTOS MINUTOS,
                '' HORA_MIN,
                '' HORA_MAX,
                'GESTION_ITOC' GESTION,
                CASE
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SUSPENDER EN SS'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND C.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'INGRESAR NOVEDAD ONYX'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'NOVEDAD ONYX-SIP CENTRALIZADO'
                END AS ACCION,
                CASE
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SOFTSWITCH'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND C.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'ONYX'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'ONYX'
                END AS SISTEMA_SUSPENSION,
                'FRAUDE' SISTEMA_ORIGEN,
                TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
  FROM FRAUDE.TMP_CDR_HUAWEI C,
       (SELECT T.CALLER_NUMBER,
               COUNT(1) LLAMADAS,
               CEIL(SUM(T.DURATION / 60)) MINUTOS,
               ROUND(COUNT(DISTINCT T.CALLED_NUMBER) / COUNT(1) * 100) DISPERSION_ABONADOS
          FROM FRAUDE.TMP_CDR_HUAWEI T --_IP_TMP T
         WHERE T.TIPO_TRAFICO LIKE 'LDI%'
           AND T.DESTINO IN ('ALBANIA',
                             'BULGARIA',
                             'CUBA',
                             'ECUADOR',
                             'BOLIVIA',
                             'EL SALVADOR',
                             'FILIPINAS',
                             'GAMBIA',
                             'GUATEMALA',
                             'GUYANA',
                             'HAITI',
                             'HONDURAS',
                             'LIBIA',
                             'NICARAGUA',
                             'ZIMBABWE',
                             'JAMAICA',
                             'GUAYANA FRANCESA',
                             'MYANMAR',
                             'GUINEA ECUATORIAL',
                             'MONACO')
         GROUP BY T.CALLER_NUMBER, T.DESTINO) R
 WHERE C.CALLER_NUMBER = R.CALLER_NUMBER
   AND R.LLAMADAS >= 10
   AND R.DISPERSION_ABONADOS >= '50'
   AND R.MINUTOS / R.LLAMADAS >= 1
   AND C.CALLER_NUMBER NOT IN
       (SELECT M.NUMERO FROM FRAUDE.MAESTRA_BLANCOS M)
union all
SELECT 
DISTINCT case
                  when substr(R.CALLER_NUMBER, 1, 2) = '57' and
                       length(trim(R.CALLER_NUMBER))= 12 then
                   substr(R.CALLER_NUMBER, 3, 10)
                  else
                   R.CALLER_NUMBER
                end AS TELEFONO,
                '' CLIENTE,
                '' CUENTA,
                '' FECHA,
                '' TRAFICO,
                '' DESTINO,
                'TERCER PAIS CORPORATIVO' AS TIPO_ALARMA,
                R.LLAMADAS,
                R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                R.MINUTOS MINUTOS,
                '' HORA_MIN,
                '' HORA_MAX,
                'GESTION_ITOC' GESTION,
                CASE
                  WHEN r.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR r.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SUSPENDER EN SS'
                  WHEN r.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND r.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'INGRESAR NOVEDAD ONYX'
                  WHEN r.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'NOVEDAD ONYX-SIP CENTRALIZADO'
                END AS ACCION,
                CASE
                  WHEN R.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR R.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SOFTSWITCH'
                  WHEN R.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND R.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'ONYX'
                  WHEN R.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'ONYX'
                END AS SISTEMA_SUSPENSION,
                'FRAUDE' SISTEMA_ORIGEN,
                TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
FROM 
(
select t.caller_number,
       count(1) llamadas,
       round(sum(t.duration / 60), 0) minUTOs,
       round(sum(t.duration / 60) / count(1), 1) dura_prom,
       round(count(distinct t.called_number) / count(1), 2) DISPERSION_ABONADOS,
       T.INCOMING_TRUNK_GROUP_NUMBER
from tmp_cdr_huawei t
 where t.caller_number like ('1796%')
   and t.tipo_trafico in ('LDI-POR-TELMEX')
 group by t.caller_number,
          T.INCOMING_TRUNK_GROUP_NUMBER
ORDER BY t.caller_number
) R
UNION ALL
SELECT DISTINCT case
                  when substr(R.CALLER_NUMBER, 1, 2) = '57' and
                       length(trim(R.CALLER_NUMBER)) = 12 then
                   substr(R.CALLER_NUMBER, 3, 10)
                  else
                   R.CALLER_NUMBER
                end AS TELEFONO,
                '' CLIENTE,
                '' CUENTA,
                '' FECHA,
                '' TRAFICO,
                '' DESTINO,
                'TERCER PAIS CORPORATIVO' AS TIPO_ALARMA,
                R.LLAMADAS,
                R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                R.MINUTOS MINUTOS,
                '' HORA_MIN,
                '' HORA_MAX,
                'GESTION_ITOC' GESTION,
                CASE
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SUSPENDER EN SS'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND C.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'INGRESAR NOVEDAD ONYX'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'NOVEDAD ONYX-SIP CENTRALIZADO'
                END AS ACCION,
                CASE
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SOFTSWITCH'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND C.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'ONYX'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'ONYX'
                END AS SISTEMA_SUSPENSION,
                'FRAUDE' SISTEMA_ORIGEN,
                TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
  FROM FRAUDE.tmp_CDR_HUAWEI c, --_ip_tmp C,
       (SELECT T.CALLER_NUMBER,
               COUNT(1) LLAMADAS,
               CEIL(SUM(T.DURATION / 60)) MINUTOS,
               ROUND(COUNT(DISTINCT T.CALLED_NUMBER) / COUNT(1) * 100) DISPERSION_ABONADOS
          FROM tmp_CDR_HUAWEI T --_IP_TMP T
         WHERE T.TIPO_TRAFICO LIKE 'LDI%'
           AND T.DESTINO IN (' (GMSS)',
                             'AFGANISTAN',
                             'ALBANIA',
                             'ANDORRA',
                             'ANGOLA',
                             'ANTARTICA-ISLA DE NORFOLK',
                             'ARABIA SAUDITA',
                             'ARGELIA',
                             'ARMENIA',
                             'ASCENSION',
                             'AUSTRIA',
                             'AZERBAIYANA',
                             'BAHAMAS',
                             'BAHREIN',
                             'BANGLADESH',
                             'BELARUS',
                             'BELICE',
                             'BENIN',
                             'BHUTAN',
                             'BOSNIA Y HERZEGOVINA',
                             'BOTSWANA',
                             'BRUNEI DARUSSALAM',
                             'BULGARIA',
                             'BURKINA FASO',
                             'BURUNDI',
                             'CABO VERDE',
                             'CAMBOYA',
                             'CAMERUN',
                             'CENTROAFRICANA',
                             'CHAD',
                             'CHIPRE',
                             'CIUDAD DEL VATICANO',
                             'COMORAS',
                             'CONGO',
                             'COOK (ISLAS)',
                             'COTE DIVOIRE',
                             'CROACIA',
                             'DIEGO GARCIA',
                             'DINAMARCA',
                             'DJIBOUTI',
                             'EGIPTO',
                             'ENSAYO',
                             'ERITREA',
                             'ESLOVENIA',
                             'ESTONIA',
                             'ETIOPIA',
                             'FEROE (ISLAS)',
                             'FIJI',
                             'FILIPINAS',
                             'FINLANDIA',
                             'FRONTERIZO MARACAIBO',
                             'GABONESA',
                             'GAMBIA',
                             'GEORGIA',
                             'GHANA',
                             'GIBRALTAR',
                             'GRECIA',
                             'GROENLANDIA (DINAMARCA',
                             'GRUPO DE PAISES',
                             'GUADALUPE (FRANCIA)',
                             'GUAYANA FRANCESA',
                             'GUINEA',
                             'GUINEA ECUATORIAL',
                             'GUINEA-BISSAU',
                             'GUYANA',
                             'HONGKONG',
                             'HUNGRIA',
                             'INDIA',
                             'INDICATIVO DE RESERVA',
                             'INDONESIA',
                             'INMARSAT (OCEANO ATLAN',
                             'INMARSAT (OCEANO INDIC',
                             'INMARSAT (OCEANO PACIF',
                             'INMARSAT SNAC',
                             'IRAN',
                             'IRAQ',
                             'IRLANDA',
                             'ISLANDIA',
                             'JAMAICA',
                             'JAPON',
                             'JORDANIA',
                             'KAZAKSTAN - RUSIA',
                             'KENYA',
                             'KIRIBATI',
                             'KUWAIT',
                             'LA EX REPUBLICA YUGOSL',
                             'LAOS',
                             'LESOTHO',
                             'LETONIA',
                             'LIBANO',
                             'LIBERIA',
                             'LIBIA',
                             'LIECHTENSTEIN',
                             'LITUANIA',
                             'LUXEMBURGO',
                             'MACAU',
                             'MADAGASCAR',
                             'MALASIA',
                             'MALAWI',
                             'MALDIVAS',
                             'MALI',
                             'MALTA',
                             'MALVINAS',
                             'MARRUECOS',
                             'MARSHALL',
                             'MARTINICA',
                             'MAURICIO',
                             'MAURITANIA',
                             'MAYOTTE',
                             'MICRONESIA',
                             'MOLDOVA',
                             'MONACO',
                             'MONGOLIA',
                             'MOZAMBIQUE',
                             'MYANMAR',
                             'NAMIBIA',
                             'NAURU',
                             'NEPAL',
                             'NICARAGUA',
                             'NIGER',
                             'NIGERIA',
                             'NIUE',
                             'NORUEGA',
                             'NUEVA CALEDONIA (FRANC',
                             'NUEVA ZELANDIA',
                             'OMAN',
                             'PAISES BAJOS',
                             'PAKISTAN',
                             'PALAU',
                             'PAPUA NUEVA GUINEA',
                             'POLINESIA FRANCESA (FR',
                             'POLONIA',
                             'PREMIUM SERVICES',
                             'QATAR',
                             'REDES INTERNACIONALES',
                             'REPUBLICA ARABE SIRIA',
                             'REPUBLICA CHECA',
                             'REPUBLICA DEMOCRATICA',
                             'REPUBLICA ESLOVACA',
                             'REPUBLICA KIRGUISA',
                             'REPUBLICA POPULAR DEMO',
                             'RESERVA',
                             'RESERVADO',
                             'RESERVADO - (UPT)',
                             'RESERVADO (IPRS)',
                             'RESERVADO (ISCS)',
                             'RESERVADO NO COMERCIA',
                             'RESERVADO PARA EL FUTU',
                             'RESERVADO SERVICIO MOV',
                             'REUNION (FRANCES)',
                             'RUMANIA',
                             'RWANDESA',
                             'SALOMON (ISLAS)',
                             'SAMOA',
                             'SAMOA NORTEAMERICANAS',
                             'SAN MARINO',
                             'SAN PEDRO Y MIQUELON',
                             'SANTA ELENA',
                             'SANTO TOME Y PRINCIPE',
                             'SENEGAL',
                             'SERVICIO DE LLAM GRATU',
                             'SEYCHELLES',
                             'SIERRA LEONA',
                             'SINGAPUR',
                             'SOMALI',
                             'SRI LANKA',
                             'ST VINCENT AND GRENADINES',
                             'SUDAFRICANA',
                             'SUDAN',
                             'SUECIA',
                             'SURINAME',
                             'SWAZILANDIA',
                             'TAILANDIA',
                             'TAIWAN',
                             'TANZANIA',
                             'TAYIKISTAN',
                             'TIMOR ORIENTAL',
                             'TOGOLESA',
                             'TOKELAU',
                             'TONGA',
                             'TUNEZ',
                             'TURKMENISTAN',
                             'TURQUIA',
                             'TUVALU',
                             'UCRANIA',
                             'UGANDA',
                             'UZBEKISTAN',
                             'VANUATU',
                             'VIETNAM',
                             'WALLIS Y FUTUNA (FRANC',
                             'YEMEN',
                             'YUGOSLAVIA',
                             'ZAMBIA',
                             'ZIMBABWE',
                             'BARBADOS',
                              'ANGUILA',
                              'ANTIGUA AND BARBUDA',
                              'US VIRGIN ISLANDS',
                              'BRITISH VIRGIN ISLANDS',
                              'BERMUDA',
                              'CAYMAN ISLANDS',
                              'TURKS AND CAICOS ISLANDS',
                              'GRENADA',
                              'MONTSERRAT',
                              'SINT MAARTEN',
                              'SAINT LUCIA',
                              'COMMONWEALTH OF DOMINICA',
                              'SAINT KITTS AND NEVIS',
                              'REPUBLICA DOMINICANA',
                              'TRINIDAD Y TOBAGO',
                              'PUERTO RICO',
                              'NORTHERN MARIANA ISLANDS',
                              'GUAM',
                              'AMERICAN SAMOA'
)
         GROUP BY T.CALLER_NUMBER) R
 WHERE C.CALLER_NUMBER = R.CALLER_NUMBER
   AND R.LLAMADAS >= 15
      --   AND R.DISPERSION_ABONADOS <= '30'
      -- AND R.MINUTOS / R.LLAMADAS >= 8
   AND C.CALLER_NUMBER NOT IN
       (SELECT M.NUMERO FROM FRAUDE.MAESTRA_BLANCOS M)
UNION ALL
SELECT DISTINCT case
                  when substr(R.CALLER_NUMBER, 1, 2) = '57' and
                       length(trim(R.CALLER_NUMBER)) = 12 then
                   substr(R.CALLER_NUMBER, 3, 10)
                  else
                   R.CALLER_NUMBER
                end AS TELEFONO,
                '' CLIENTE,
                '' CUENTA,
                '' FECHA,
                '' TRAFICO,
                '' DESTINO,
                'TERCER PAIS CORPORATIVO' AS TIPO_ALARMA,
                R.LLAMADAS,
                R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                R.MINUTOS MINUTOS,
                '' HORA_MIN,
                '' HORA_MAX,
                'GESTION_ITOC' GESTION,
                CASE
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SUSPENDER EN SS'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND C.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'INGRESAR NOVEDAD ONYX'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'NOVEDAD ONYX-SIP CENTRALIZADO'
                END AS ACCION,
                CASE
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SOFTSWITCH'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND C.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'ONYX'
                  WHEN C.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'ONYX'
                END AS SISTEMA_SUSPENSION,
                'FRAUDE' SISTEMA_ORIGEN,
                TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
  FROM FRAUDE.tmp_CDR_HUAWEI c, --_ip_tmp C,
       (
       SELECT T.CALLER_NUMBER,
               COUNT(1) LLAMADAS,
               CEIL(SUM(T.DURATION / 60)) MINUTOS,
               ROUND(COUNT(DISTINCT T.CALLED_NUMBER) / COUNT(1) * 100) DISPERSION_ABONADOS
--               t.destino
          FROM tmp_CDR_HUAWEI T --TEMPORAL CORPORATIVO
         WHERE T.TIPO_TRAFICO LIKE 'LDI%' AND
(
   trim(t.called_number)like 	'%8818905___'	--	 (GMSS)	TOLL FRAUD	20/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%88193521____'	--	 (GMSS)	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%8818481____'	--	 (GMSS)	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%935466811__'	--	AFGANISTAN	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%93708______'	--	AFGANISTAN	TOLL FRAUD	20/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%93752289___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93777463___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93780009___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93780872___%'	--	AFGANISTAN	TOLL FRAUD	11/05/2012	CONFIRMADO
or trim(t.called_number)like 	'%93795903___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93797458___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%3554249____'	--	ALBANIA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%35566_______'	--	ALBANIA	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%1264536____'	--	ANGUILA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%12687802___'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%12687803515'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%12687803536'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%2135590000__'	--	ARGELIA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%37447994___'	--	ARMENIA	TOLL FRAUD	21/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%37497745___'	--	ARMENIA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%297640____'	--	ARUBA	TOLL FRAUD	20/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%2979953___'	--	ARUBA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%61296679111'	--	AUSTRALIA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%43810______%'	--	AUSTRIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'43820______%'	--	AUSTRIA	TOLL FRAUD	13/02/2012	CONFIRMADO
or trim(t.called_number)like 	'00_43820______%'	--	AUSTRIA	TOLL FRAUD	13/02/2012	CONFIRMADO
or trim(t.called_number)like 	'00___43820______%'	--	AUSTRIA	TOLL FRAUD	13/02/2012	CONFIRMADO
or trim(t.called_number)like 	'%43821______'	--	AUSTRIA	TOLL FRAUD	28/02/2013	POR PRECAUCION
or trim(t.called_number)like 	'%43828______'	--	AUSTRIA	TOLL FRAUD	28/02/2013	POR PRECAUCION
or trim(t.called_number)like 	'%43678901____'	--	AUSTRIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%9944001_____'	--	AZERBAIYANA	TOLL FRAUD	11/10/2012	CONFIRMADO
or trim(t.called_number)like 	'%9944002_____'	--	AZERBAIYANA	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%1246256____'	--	BARBADOS	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%1246859____'	--	BARBADOS	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%375239886___'	--	BELARUS	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%375297298___%'	--	BELARUS	TOLL FRAUD	14/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%375333______%'	--	BELARUS	TOLL FRAUD	24/10/2012	CONFIRMADO
or trim(t.called_number)like 	'%375602______'	--	BELARUS	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%375777______'	--	BELARUS	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%3752947____%'	--	BELARUS	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%22995964___'	--	BENIN	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%3876_______'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%387302_____'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%2677626_____'	--	BOTSWANA	TOLL FRAUD	25/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%22670102___'	--	BURKINA FASO	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%22670799___'	--	BURKINA FASO	TOLL FRAUD	25/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%257161_____'	--	BURUNDI	TOLL FRAUD	26/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%236877_____'	--	CENTROAFRICANA	TOLL FRAUD	26/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%23599______'	--	CHAD	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%56__197____%'	--	CHILE	TOLL FRAUD		CONFIRMADO
or trim(t.called_number)like 	'%562196____%'	--	CHILE	TOLL FRAUD	14/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%562197____%'	--	CHILE	TOLL FRAUD	19/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%5645197____  '	--	CHILE	TOLL FRAUD	20/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%56266675__%'	--	CHILE	TOLL FRAUD		NO-CONFIRMADO
or trim(t.called_number)like 	'%56322553___%'	--	CHILE	TOLL FRAUD	16/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%5673970060%'	--	CHILE	TOLL FRAUD	15/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%5699027____%'	--	CHILE	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%1767503____'	--	COMMONWEALTH OF DOMINICA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'00_24204428____%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___24204428____%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_242800______%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___242800______%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243809850___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243809900___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243890026___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243890822___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%22521709___'	--	COTE DIVOIRE	TOLL FRAUD	16/09/2014	CONFIRMADO
or trim(t.called_number)like 	'%385958______%'	--	CROACIA	TOLL FRAUD	23/07/2012	CONFIRMADO
or trim(t.called_number)like 	'00_5337899___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5337899___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_5347251___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5347251___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_5351231___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5351231___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_5345619___%'	--	CUBA	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5345619___%'	--	CUBA	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%2011555_____%'	--	EGIPTO	TOLL FRAUD	19/07/2012	CONFIRMADO
or trim(t.called_number)like 	'%5032488____'	--	EL SALVADOR	TOLL FRAUD	03/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%50325606___'	--	EL SALVADOR	TOLL FRAUD	03/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%503745_____'	--	EL SALVADOR	TOLL FRAUD	14/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%503777_____'	--	EL SALVADOR	TOLL FRAUD	28/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%50378545048'	--	EL SALVADOR	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%503797_____'	--	EL SALVADOR	TOLL FRAUD	18/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%50376865___'	--	EL SALVADOR	TOLL FRAUD	15/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%345182031__%'	--	ESPAÑA	TOLL FRAUD	26/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%3460100____%'	--	ESPAÑA	TOLL FRAUD	14/03/2012	CONFIRMADO
or trim(t.called_number)like 	'%3460110____%'	--	ESPAÑA	TOLL FRAUD	17/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%3464001____%'	--	ESPAÑA	TOLL FRAUD	21/07/2012	CONFIRMADO
or trim(t.called_number)like 	'%34902500874%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%349025029__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%349025030__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%349025031__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%34902056___%'	--	ESPAÑA	TOLL FRAUD	01/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%34902530___%'	--	ESPAÑA	TOLL FRAUD	11/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%34902917___%'	--	ESPAÑA	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%34902041___'	--	ESPAÑA	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%34902042___'	--	ESPAÑA	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%34902043___'	--	ESPAÑA	TOLL FRAUD	04/10/2013	CONFIRMADO
or trim(t.called_number)like 	'%37240______'	--	ESTONIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%37270______'	--	ESTONIA	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%37290_____'	--	ESTONIA	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%6392000____%'	--	FILIPINAS	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%3364001____%'	--	FRANCIA	TOLL FRAUD	26/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%241052_____'	--	GABONESA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%241053_____'	--	GABONESA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%220777____%'	--	GAMBIA	TOLL FRAUD	30/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%50230264986%'	--	GUATEMALA	TOLL FRAUD	30/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%22455______'	--	GUINEA	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%22478______'	--	GUINEA	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%5926386___'	--	GUYANA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%50928167___'	--	HAITI	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%5092817____%'	--	HAITI	TOLL FRAUD	01/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%50944911___'	--	HAITI	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%50937756___'	--	HAITI	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%5048737052%'	--	HONDURAS	TOLL FRAUD	29/12/2011	CONFIRMADO
or trim(t.called_number)like 	'%38288000___'	--	INDICATIVO DE RESERVA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%39319905____'	--	ITALIA	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%1345550____'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%1345925____'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%1345235____'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%7254476____%'	--	KASAKSTAN	TOLL FRAUD	20/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%72598281141%'	--	ISRAEL KASAKSTAN	TOLL FRAUD	17/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%72599429449%'	--	ISRAEL KASAKSTAN	TOLL FRAUD	17/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%187646____%'	--	JAMAICA	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%187684_____%'	--	JAMAICA	TOLL FRAUD	23/03/2012	CONFIRMADO
or trim(t.called_number)like 	'%38978_____%'	--	LA EX REPUBLICA YUGOSL	TOLL FRAUD	04/08/2014	NO-CONFIRMADO
or trim(t.called_number)like 	'%3712278____'	--	LETONIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%3712279____'	--	LETONIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%2315320___'	--	LIBERIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%23190201___'	--	LIBERIA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%423870____'	--	LIECHTENSTEIN	TOLL FRAUD	01/03/2013	CONFIRMADO
or trim(t.called_number)like 	'%423877____'	--	LIECHTENSTEIN	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'42390_____'	--	LIECHTENSTEIN	TOLL FRAUD	02/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00_42390_____'	--	LIECHTENSTEIN	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00___42390_____'	--	LIECHTENSTEIN	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%3707_______'	--	LITUANIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%3708_______'	--	LITUANIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%3709_______'	--	LITUANIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%35228489___'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%352691003___'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'9607______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'9609______'	--	MALDIVAS	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00___9607______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00___9609______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00_9607______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00_9609______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%21269228____'	--	MARRUECOS	TOLL FRAUD	04/08/2014	NO-CONFIRMADO
or trim(t.called_number)like 	'%212645591___'	--	MARRUECOS	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%37369878___'	--	MOLDOVA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%3739_______'	--	MOLDOVA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%37744______'	--	MONACO	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%37745______'	--	MONACO	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_6745599___%'	--	NAURU	TOLL FRAUD	15/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___6745599___%'	--	NAURU	TOLL FRAUD	15/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%5058884208%'	--	NICARAGUA	TOLL FRAUD	30/12/2011	CONFIRMADO
or trim(t.called_number)like 	'%50588919___%'	--	NICARAGUA	TOLL FRAUD	13/01/2012	CONFIRMADO
or trim(t.called_number)like 	'%227201_____'	--	NIGER	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%227203_____'	--	NIGER	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'51648_____'	--	PERU	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'00_51648_____'	--	PERU	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'00___51648_____'	--	PERU	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'51518_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_51518_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___51518_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'51528_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_51528_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___51528_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%4876856____%'	--	POLONIA	TOLL FRAUD	23/07/2012	CONFIRMADO
or trim(t.called_number)like 	'00_9743920____'	--	QATAR	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'00___9743920____'	--	QATAR	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%88233010___%'	--	REDES INTERNACIONALES	TOLL FRAUD	30/09/2012	CONFIRMADO
or trim(t.called_number)like 	'00_239220____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	24/08/2012	CONFIRMADO
or trim(t.called_number)like 	'00___239220____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	24/08/2012	CONFIRMADO
or trim(t.called_number)like 	'00_239990____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___239990____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_2393879___%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___2393879___%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'23222______%'	--	SIERRA LEONA	TOLL FRAUD	14/09/2012	CONFIRMADO
or trim(t.called_number)like 	'_____23222______%'	--	SIERRA LEONA	TOLL FRAUD	15/09/2012	CONFIRMADO
or trim(t.called_number)like 	'___23222______%'	--	SIERRA LEONA	TOLL FRAUD	15/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%252223____'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%25229722___'	--	SOMALI	TOLL FRAUD	16/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%25230______'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%25240______'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%252541____'	--	SOMALI	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%25270______'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%5977200___'	--	SURINAME	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%8869135_____%'	--	TAIWAN	TOLL FRAUD	12/03/2012	CONFIRMADO
or trim(t.called_number)like 	'00_670330____'	--	TIMOR ORIENTAL	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___670330____'	--	TIMOR ORIENTAL	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_21620999___%'	--	TUNEZ	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___21620999___%'	--	TUNEZ	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%44190489____'	--	UK	TOLL FRAUD	28/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%442034321288%'	--	UK	TOLL FRAUD	15/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%447023815___'	--	UK	TOLL FRAUD	16/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%44708_______'	--	UK	TOLL FRAUD	01/09/2014	CONFIRMADO
or trim(t.called_number)like 	'%4474065_____%'	--	UK	TOLL FRAUD		CONFIRMADO
or trim(t.called_number)like 	'%4474179_____%'	--	UK	TOLL FRAUD	23/03/2012	CONFIRMADO
or trim(t.called_number)like 	'%447589______%'	--	UK	TOLL FRAUD	13/01/2012	CONFIRMADO
or trim(t.called_number)like 	'%447822118___%'	--	UK	TOLL FRAUD	13/06/2014	CONFIRMADO
or trim(t.called_number)like 	'%447893362345%'	--	UK	TOLL FRAUD	16/09/2014	CONFIRMADO
or trim(t.called_number)like 	'%442075005000%'	--	UK	TOLL FRAUD	28/08/2013	CONFIRMADO
or trim(t.called_number)like 	'%441212792618%'	--	UK	TOLL FRAUD	29/08/2013	CONFIRMADO
or trim(t.called_number)like 	'%448714610___'	--	UK	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%13459254300%'	--	USA	TOLL FRAUD		CONFIRMADO
or trim(t.called_number)like 	'%17862422224%'	--	USA	REFILE	21/03/2014	CONFIRMADO
or trim(t.called_number)like 	'%18005551111%'	--	USA y TOLL FREE	TOLL FRAUD	04/10/2013	CONFIRMADO
or trim(t.called_number)like 	'%68172____'	--	WALLIS Y FUTUNA (FRANC	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%381608______'	--	YUGOSLAVIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%38166_______'	--	YUGOSLAVIA	TOLL FRAUD	28/08/2014	CONFIRMADO

       
)
        GROUP BY T.CALLER_NUMBER
       ) R
 WHERE C.CALLER_NUMBER = R.CALLER_NUMBER
union all
SELECT DISTINCT case
                  when substr(R.CALLER_NUMBER, 1, 2) = '57' and
                       (length(R.CALLER_NUMBER) = 12 or length(R.CALLER_NUMBER) = 10 )then
                   substr(R.CALLER_NUMBER, 3, 10)
                  else
                   R.CALLER_NUMBER
                end AS TELEFONO,
                   '' CLIENTE,
                   '' CUENTA,
                   '' FECHA,
                   '' TRAFICO,
                   '' DESTINO,
                   'TERCER PAIS CORPORATIVO' AS TIPO_ALARMA,
                   R.LLAMADAS,
                   R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                   R.MINUTOS MINUTOS,
                   '' HORA_MIN,
                   '' HORA_MAX,
                   'GESTION_ITOC' GESTION,
                   CASE
                     WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                          '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                      'SUSPENDER EN SS'
                     WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                          '2000' AND
                          C.INCOMING_TRUNK_GROUP_NUMBER <> '65535' THEN
                      'INGRESAR NOVEDAD ONYX'
                   END AS ACCION,
                   CASE
                     WHEN C.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                          '1999' OR C.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                      'SOFTSWITCH'
                     WHEN C.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                          '2000' AND
                          C.INCOMING_TRUNK_GROUP_NUMBER <> '65535' THEN
                      'ONYX'
                   END AS SISTEMA_SUSPENSION,
                   'FRAUDE' SISTEMA_ORIGEN,
                   TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
     FROM --cdr_fo_srt_no_exitosos c,     
       TMP_CDR_SRT_FO_NN C,
               (SELECT T.CALLER_NUMBER,
                  COUNT(1) LLAMADAS,
                  CEIL(SUM(T.DURATION / 60)) MINUTOS,
                  ROUND(COUNT(DISTINCT T.CALLED_NUMBER) / COUNT(1) * 100) DISPERSION_ABONADOS
           --               t.destino
             FROM --cdr_fo_srt_no_exitosos T
           TMP_CDR_SRT_FO_NN T -- TABLA TEMPORAL DE NO EXITOSOS
            WHERE T.TIPO_TRAFICO LIKE 'LDI%'
              AND
(
   trim(t.called_number)like 	'%8818905___'	--	 (GMSS)	TOLL FRAUD	20/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%88193521____'	--	 (GMSS)	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%8818481____'	--	 (GMSS)	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%935466811__'	--	AFGANISTAN	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%93708______'	--	AFGANISTAN	TOLL FRAUD	20/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%93752289___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93777463___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93780009___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93780872___%'	--	AFGANISTAN	TOLL FRAUD	11/05/2012	CONFIRMADO
or trim(t.called_number)like 	'%93795903___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%93797458___'	--	AFGANISTAN	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%3554249____'	--	ALBANIA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%35566_______'	--	ALBANIA	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%1264536____'	--	ANGUILA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%12687802___'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%12687803515'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%12687803536'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%2135590000__'	--	ARGELIA	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%37447994___'	--	ARMENIA	TOLL FRAUD	21/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%37497745___'	--	ARMENIA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%297640____'	--	ARUBA	TOLL FRAUD	20/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%2979953___'	--	ARUBA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%61296679111'	--	AUSTRALIA	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%43810______%'	--	AUSTRIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'43820______%'	--	AUSTRIA	TOLL FRAUD	13/02/2012	CONFIRMADO
or trim(t.called_number)like 	'00_43820______%'	--	AUSTRIA	TOLL FRAUD	13/02/2012	CONFIRMADO
or trim(t.called_number)like 	'00___43820______%'	--	AUSTRIA	TOLL FRAUD	13/02/2012	CONFIRMADO
or trim(t.called_number)like 	'%43821______'	--	AUSTRIA	TOLL FRAUD	28/02/2013	POR PRECAUCION
or trim(t.called_number)like 	'%43828______'	--	AUSTRIA	TOLL FRAUD	28/02/2013	POR PRECAUCION
or trim(t.called_number)like 	'%43678901____'	--	AUSTRIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%9944001_____'	--	AZERBAIYANA	TOLL FRAUD	11/10/2012	CONFIRMADO
or trim(t.called_number)like 	'%9944002_____'	--	AZERBAIYANA	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%1246256____'	--	BARBADOS	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%1246859____'	--	BARBADOS	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%375239886___'	--	BELARUS	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%375297298___%'	--	BELARUS	TOLL FRAUD	14/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%375333______%'	--	BELARUS	TOLL FRAUD	24/10/2012	CONFIRMADO
or trim(t.called_number)like 	'%375602______'	--	BELARUS	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%375777______'	--	BELARUS	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%3752947____%'	--	BELARUS	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%22995964___'	--	BENIN	TOLL FRAUD	22/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%3876_______'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%387302_____'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%2677626_____'	--	BOTSWANA	TOLL FRAUD	25/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%22670102___'	--	BURKINA FASO	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%22670799___'	--	BURKINA FASO	TOLL FRAUD	25/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%257161_____'	--	BURUNDI	TOLL FRAUD	26/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%236877_____'	--	CENTROAFRICANA	TOLL FRAUD	26/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%23599______'	--	CHAD	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%56__197____%'	--	CHILE	TOLL FRAUD		CONFIRMADO
or trim(t.called_number)like 	'%562196____%'	--	CHILE	TOLL FRAUD	14/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%562197____%'	--	CHILE	TOLL FRAUD	19/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%5645197____  '	--	CHILE	TOLL FRAUD	20/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%56266675__%'	--	CHILE	TOLL FRAUD		NO-CONFIRMADO
or trim(t.called_number)like 	'%56322553___%'	--	CHILE	TOLL FRAUD	16/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%5673970060%'	--	CHILE	TOLL FRAUD	15/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%5699027____%'	--	CHILE	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%1767503____'	--	COMMONWEALTH OF DOMINICA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'00_24204428____%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___24204428____%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_242800______%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___242800______%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243809850___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243809900___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243890026___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%243890822___'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%22521709___'	--	COTE DIVOIRE	TOLL FRAUD	16/09/2014	CONFIRMADO
or trim(t.called_number)like 	'%385958______%'	--	CROACIA	TOLL FRAUD	23/07/2012	CONFIRMADO
or trim(t.called_number)like 	'00_5337899___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5337899___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_5347251___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5347251___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_5351231___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5351231___%'	--	CUBA	TOLL FRAUD	02/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00_5345619___%'	--	CUBA	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___5345619___%'	--	CUBA	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%2011555_____%'	--	EGIPTO	TOLL FRAUD	19/07/2012	CONFIRMADO
or trim(t.called_number)like 	'%5032488____'	--	EL SALVADOR	TOLL FRAUD	03/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%50325606___'	--	EL SALVADOR	TOLL FRAUD	03/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%503745_____'	--	EL SALVADOR	TOLL FRAUD	14/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%503777_____'	--	EL SALVADOR	TOLL FRAUD	28/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%50378545048'	--	EL SALVADOR	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%503797_____'	--	EL SALVADOR	TOLL FRAUD	18/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%50376865___'	--	EL SALVADOR	TOLL FRAUD	15/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%345182031__%'	--	ESPAÑA	TOLL FRAUD	26/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%3460100____%'	--	ESPAÑA	TOLL FRAUD	14/03/2012	CONFIRMADO
or trim(t.called_number)like 	'%3460110____%'	--	ESPAÑA	TOLL FRAUD	17/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%3464001____%'	--	ESPAÑA	TOLL FRAUD	21/07/2012	CONFIRMADO
or trim(t.called_number)like 	'%34902500874%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%349025029__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%349025030__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%349025031__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%34902056___%'	--	ESPAÑA	TOLL FRAUD	01/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%34902530___%'	--	ESPAÑA	TOLL FRAUD	11/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%34902917___%'	--	ESPAÑA	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%34902041___'	--	ESPAÑA	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%34902042___'	--	ESPAÑA	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%34902043___'	--	ESPAÑA	TOLL FRAUD	04/10/2013	CONFIRMADO
or trim(t.called_number)like 	'%37240______'	--	ESTONIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%37270______'	--	ESTONIA	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%37290_____'	--	ESTONIA	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%6392000____%'	--	FILIPINAS	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%3364001____%'	--	FRANCIA	TOLL FRAUD	26/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%241052_____'	--	GABONESA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%241053_____'	--	GABONESA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%220777____%'	--	GAMBIA	TOLL FRAUD	30/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%50230264986%'	--	GUATEMALA	TOLL FRAUD	30/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%22455______'	--	GUINEA	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%22478______'	--	GUINEA	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%5926386___'	--	GUYANA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%50928167___'	--	HAITI	TOLL FRAUD	14/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%5092817____%'	--	HAITI	TOLL FRAUD	01/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%50944911___'	--	HAITI	TOLL FRAUD	27/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%50937756___'	--	HAITI	TOLL FRAUD	27/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%5048737052%'	--	HONDURAS	TOLL FRAUD	29/12/2011	CONFIRMADO
or trim(t.called_number)like 	'%38288000___'	--	INDICATIVO DE RESERVA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%39319905____'	--	ITALIA	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%1345550____'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%1345925____'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%1345235____'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014	CONFIRMADO
or trim(t.called_number)like 	'%7254476____%'	--	KASAKSTAN	TOLL FRAUD	20/01/2014	CONFIRMADO
or trim(t.called_number)like 	'%72598281141%'	--	ISRAEL KASAKSTAN	TOLL FRAUD	17/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%72599429449%'	--	ISRAEL KASAKSTAN	TOLL FRAUD	17/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%187646____%'	--	JAMAICA	TOLL FRAUD	04/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%187684_____%'	--	JAMAICA	TOLL FRAUD	23/03/2012	CONFIRMADO
or trim(t.called_number)like 	'%38978_____%'	--	LA EX REPUBLICA YUGOSL	TOLL FRAUD	04/08/2014	NO-CONFIRMADO
or trim(t.called_number)like 	'%3712278____'	--	LETONIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%3712279____'	--	LETONIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%2315320___'	--	LIBERIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%23190201___'	--	LIBERIA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%423870____'	--	LIECHTENSTEIN	TOLL FRAUD	01/03/2013	CONFIRMADO
or trim(t.called_number)like 	'%423877____'	--	LIECHTENSTEIN	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'42390_____'	--	LIECHTENSTEIN	TOLL FRAUD	02/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00_42390_____'	--	LIECHTENSTEIN	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00___42390_____'	--	LIECHTENSTEIN	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%3707_______'	--	LITUANIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%3708_______'	--	LITUANIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%3709_______'	--	LITUANIA	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%35228489___'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%352691003___'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'9607______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'9609______'	--	MALDIVAS	TOLL FRAUD	04/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00___9607______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00___9609______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00_9607______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'00_9609______'	--	MALDIVAS	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%21269228____'	--	MARRUECOS	TOLL FRAUD	04/08/2014	NO-CONFIRMADO
or trim(t.called_number)like 	'%212645591___'	--	MARRUECOS	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%37369878___'	--	MOLDOVA	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%3739_______'	--	MOLDOVA	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%37744______'	--	MONACO	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%37745______'	--	MONACO	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_6745599___%'	--	NAURU	TOLL FRAUD	15/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___6745599___%'	--	NAURU	TOLL FRAUD	15/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%5058884208%'	--	NICARAGUA	TOLL FRAUD	30/12/2011	CONFIRMADO
or trim(t.called_number)like 	'%50588919___%'	--	NICARAGUA	TOLL FRAUD	13/01/2012	CONFIRMADO
or trim(t.called_number)like 	'%227201_____'	--	NIGER	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%227203_____'	--	NIGER	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'51648_____'	--	PERU	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'00_51648_____'	--	PERU	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'00___51648_____'	--	PERU	TOLL FRAUD	16/01/2014	CONFIRMADO
or trim(t.called_number)like 	'51518_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_51518_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___51518_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'51528_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_51528_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___51528_____'	--	PERU	TOLL FRAUD	05/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%4876856____%'	--	POLONIA	TOLL FRAUD	23/07/2012	CONFIRMADO
or trim(t.called_number)like 	'00_9743920____'	--	QATAR	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'00___9743920____'	--	QATAR	TOLL FRAUD	17/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%88233010___%'	--	REDES INTERNACIONALES	TOLL FRAUD	30/09/2012	CONFIRMADO
or trim(t.called_number)like 	'00_239220____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	24/08/2012	CONFIRMADO
or trim(t.called_number)like 	'00___239220____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	24/08/2012	CONFIRMADO
or trim(t.called_number)like 	'00_239990____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___239990____'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_2393879___%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___2393879___%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'23222______%'	--	SIERRA LEONA	TOLL FRAUD	14/09/2012	CONFIRMADO
or trim(t.called_number)like 	'_____23222______%'	--	SIERRA LEONA	TOLL FRAUD	15/09/2012	CONFIRMADO
or trim(t.called_number)like 	'___23222______%'	--	SIERRA LEONA	TOLL FRAUD	15/09/2012	CONFIRMADO
or trim(t.called_number)like 	'%252223____'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%25229722___'	--	SOMALI	TOLL FRAUD	16/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%25230______'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%25240______'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%252541____'	--	SOMALI	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'%25270______'	--	SOMALI	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%5977200___'	--	SURINAME	TOLL FRAUD	26/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%8869135_____%'	--	TAIWAN	TOLL FRAUD	12/03/2012	CONFIRMADO
or trim(t.called_number)like 	'00_670330____'	--	TIMOR ORIENTAL	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00___670330____'	--	TIMOR ORIENTAL	TOLL FRAUD	28/08/2014	CONFIRMADO
or trim(t.called_number)like 	'00_21620999___%'	--	TUNEZ	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'00___21620999___%'	--	TUNEZ	TOLL FRAUD	13/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%44190489____'	--	UK	TOLL FRAUD	28/01/2015	CONFIRMADO
or trim(t.called_number)like 	'%442034321288%'	--	UK	TOLL FRAUD	15/08/2012	CONFIRMADO
or trim(t.called_number)like 	'%447023815___'	--	UK	TOLL FRAUD	16/10/2014	CONFIRMADO
or trim(t.called_number)like 	'%44708_______'	--	UK	TOLL FRAUD	01/09/2014	CONFIRMADO
or trim(t.called_number)like 	'%4474065_____%'	--	UK	TOLL FRAUD		CONFIRMADO
or trim(t.called_number)like 	'%4474179_____%'	--	UK	TOLL FRAUD	23/03/2012	CONFIRMADO
or trim(t.called_number)like 	'%447589______%'	--	UK	TOLL FRAUD	13/01/2012	CONFIRMADO
or trim(t.called_number)like 	'%447822118___%'	--	UK	TOLL FRAUD	13/06/2014	CONFIRMADO
or trim(t.called_number)like 	'%447893362345%'	--	UK	TOLL FRAUD	16/09/2014	CONFIRMADO
or trim(t.called_number)like 	'%442075005000%'	--	UK	TOLL FRAUD	28/08/2013	CONFIRMADO
or trim(t.called_number)like 	'%441212792618%'	--	UK	TOLL FRAUD	29/08/2013	CONFIRMADO
or trim(t.called_number)like 	'%448714610___'	--	UK	TOLL FRAUD	02/12/2014	CONFIRMADO
or trim(t.called_number)like 	'%13459254300%'	--	USA	TOLL FRAUD		CONFIRMADO
or trim(t.called_number)like 	'%17862422224%'	--	USA	REFILE	21/03/2014	CONFIRMADO
or trim(t.called_number)like 	'%18005551111%'	--	USA y TOLL FREE	TOLL FRAUD	04/10/2013	CONFIRMADO
or trim(t.called_number)like 	'%68172____'	--	WALLIS Y FUTUNA (FRANC	TOLL FRAUD	03/12/2012	CONFIRMADO
or trim(t.called_number)like 	'%381608______'	--	YUGOSLAVIA	TOLL FRAUD	28/02/2013	CONFIRMADO
or trim(t.called_number)like 	'%38166_______'	--	YUGOSLAVIA	TOLL FRAUD	28/08/2014	CONFIRMADO


)
                 
            GROUP BY T.CALLER_NUMBER) R
    WHERE C.CALLER_NUMBER = R.CALLER_NUMBER 
 ;
 
 
 
  
  END PR_TERCER_PAIS_EMPRESAS;

  PROCEDURE PR_TERCER_PAIS_HOGARES(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_TERCER_PAIS_HOGARES
    **
    ** DESCRIPTION:    CONSULTA LOS FRAUDES DE TERCER PAIS DE HOGARES
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 19-NOV-09      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LOS FRAUDES DE TERCER PAIS DE HOGARES
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
      SELECT DISTINCT R.ABON_ORIGEN AS TELEFONO,
                      S.NOMBRE CLIENTE,
                      S.CUENTA CUENTA,
                      '' FECHA,
                      'LDI_TERCEROS' TRAFICO,
                      '' DESTINO,
                      'TERCER PAIS RESIDENCIAL' AS TIPO_ALARMA,
                      R.LLAMADAS,
                      R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'SUSPENDER EN IW' AS ACCION,
                      'INTRAWAY' AS SISTEMA_SUSPENSION,
                      'FRAUDE' SISTEMA_ORIGEN,
                      TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
        FROM SUSCRIPTORES_TMX_HFC S,
             (SELECT T.ABON_ORIGEN,
                     COUNT(1) LLAMADAS,
                     CEIL(SUM(T.DURATION / 60)) MINUTOS,
                     COUNT(DISTINCT T.ABON_DESTINO) NUM_DIF,
                     ROUND(COUNT(DISTINCT T.ABON_DESTINO) / COUNT(1) * 100) DISPERSION_ABONADOS
              --MAX(T.START_DATE) FECHA_MAX
                FROM FRAUDE.TMP_CDR_TMXH_HFC_TRAFICO T
               WHERE T.TIPO_TRAFICO LIKE 'LDI%'
                 AND T.DESTINO IN
                     ('ALBANIA', 'BULGARIA', 'CUBA', 'ECUADOR', 'EL SALVADOR','BOLIVIA',
                'FILIPINAS', 'GAMBIA', 'GUATEMALA', 'GUYANA', 'HAITI',
                'HONDURAS', 'LIBIA', 'NICARAGUA', 'ZIMBABWE', 'JAMAICA','GUAYANA FRANCESA','MYANMAR','GUINEA ECUATORIAL')
--                 AND T.OUTGOING_TRUNK_GROUP_NUMBER NOT IN('40004', '40005', 'NULL')
               GROUP BY T.ABON_ORIGEN, T.DESTINO) R
       WHERE R.LLAMADAS >= 10
         AND R.DISPERSION_ABONADOS > '50'
         AND R.MINUTOS / R.LLAMADAS >= 1
         AND R.ABON_ORIGEN NOT IN
             (SELECT M.NUMERO FROM FRAUDE.MAESTRA_BLANCOS M)
         AND S.TELEFONO(+) = R.ABON_ORIGEN
union all
SELECT DISTINCT R.ABON_ORIGEN AS TELEFONO,
                      S.NOMBRE CLIENTE,
                      S.CUENTA CUENTA,
                      '' FECHA,
                      'LDI_TERCEROS' TRAFICO,
                      '' DESTINO,
                      'TERCER PAIS RESIDENCIAL' AS TIPO_ALARMA,
                      R.LLAMADAS,
                      R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'SUSPENDER EN IW' AS ACCION,
                      'INTRAWAY' AS SISTEMA_SUSPENSION,
                      'FRAUDE' SISTEMA_ORIGEN,
                      TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
        FROM SUSCRIPTORES_TMX_HFC S,
             (SELECT T.ABON_ORIGEN,
                     COUNT(1) LLAMADAS,
                     CEIL(SUM(T.DURATION / 60)) MINUTOS,
                     COUNT(DISTINCT T.ABON_DESTINO) NUM_DIF,
                     ROUND(COUNT(DISTINCT T.ABON_DESTINO) / COUNT(1) * 100) DISPERSION_ABONADOS
                  FROM FRAUDE.TMP_CDR_TMXH_HFC_TRAFICO T
               WHERE T.TIPO_TRAFICO LIKE 'LDI%'
                 AND T.DESTINO IN (' (GMSS)',
                             'AFGANISTAN',
                             'ALBANIA',
                             'ANDORRA',
                             'ANGOLA',
                             'ANTARTICA-ISLA DE NORFOLK',
                             'ARABIA SAUDITA',
                             'ARGELIA',
                             'ARMENIA',
                             'ASCENSION',
                             'AUSTRIA',
                             'AZERBAIYANA',
                             'BAHAMAS',
                             'BAHREIN',
                             'BANGLADESH',
                             'BELARUS',
                             'BELICE',
                             'BENIN',
                             'BHUTAN',
                             'BOSNIA Y HERZEGOVINA',
                             'BOTSWANA',
                             'BRUNEI DARUSSALAM',
                             'BULGARIA',
                             'BURKINA FASO',
                             'BURUNDI',
                             'CABO VERDE',
                             'CAMBOYA',
                             'CAMERUN',
                             'CENTROAFRICANA',
                             'CHAD',
                             'CHIPRE',
                             'CIUDAD DEL VATICANO',
                             'COMORAS',
                             'CONGO',
                             'COOK (ISLAS)',
                             'COTE DIVOIRE',
                             'CROACIA',
                             'DIEGO GARCIA',
                             'DINAMARCA',
                             'DJIBOUTI',
                             'EGIPTO',
                             'ENSAYO',
                             'ERITREA',
                             'ESLOVENIA',
                             'ESTONIA',
                             'ETIOPIA',
                             'FEROE (ISLAS)',
                             'FIJI',
                             'FILIPINAS',
                             'FINLANDIA',
                             'FRONTERIZO MARACAIBO',
                             'GABONESA',
                             'GAMBIA',
                             'GEORGIA',
                             'GHANA',
                             'GIBRALTAR',
                             'GRECIA',
                             'GROENLANDIA (DINAMARCA',
                             'GRUPO DE PAISES',
                             'GUADALUPE (FRANCIA)',
                             'GUAYANA FRANCESA',
                             'GUINEA',
                             'GUINEA ECUATORIAL',
                             'GUINEA-BISSAU',
                             'GUYANA',
                             'HONGKONG',
                             'HUNGRIA',
                             'INDIA',
                             'INDICATIVO DE RESERVA',
                             'INDONESIA',
                             'INMARSAT (OCEANO ATLAN',
                             'INMARSAT (OCEANO INDIC',
                             'INMARSAT (OCEANO PACIF',
                             'INMARSAT SNAC',
                             'IRAN',
                             'IRAQ',
                             'IRLANDA',
                             'ISLANDIA',
                             'JAMAICA',
                             'JAPON',
                             'JORDANIA',
                             'KAZAKSTAN - RUSIA',
                             'KENYA',
                             'KIRIBATI',
                             'KUWAIT',
                             'LA EX REPUBLICA YUGOSL',
                             'LAOS',
                             'LESOTHO',
                             'LETONIA',
                             'LIBANO',
                             'LIBERIA',
                             'LIBIA',
                             'LIECHTENSTEIN',
                             'LITUANIA',
                             'LUXEMBURGO',
                             'MACAU',
                             'MADAGASCAR',
                             'MALASIA',
                             'MALAWI',
                             'MALDIVAS',
                             'MALI',
                             'MALTA',
                             'MALVINAS',
                             'MARRUECOS',
                             'MARSHALL',
                             'MARTINICA',
                             'MAURICIO',
                             'MAURITANIA',
                             'MAYOTTE',
                             'MICRONESIA',
                             'MOLDOVA',
                             'MONACO',
                             'MONGOLIA',
                             'MOZAMBIQUE',
                             'MYANMAR',
                             'NAMIBIA',
                             'NAURU',
                             'NEPAL',
                             'NICARAGUA',
                             'NIGER',
                             'NIGERIA',
                             'NIUE',
                             'NORUEGA',
                             'NUEVA CALEDONIA (FRANC',
                             'NUEVA ZELANDIA',
                             'OMAN',
                             'PAISES BAJOS',
                             'PAKISTAN',
                             'PALAU',
                             'PAPUA NUEVA GUINEA',
                             'POLINESIA FRANCESA (FR',
                             'POLONIA',
                             'PREMIUM SERVICES',
                             'QATAR',
                             'REDES INTERNACIONALES',
                             'REPUBLICA ARABE SIRIA',
                             'REPUBLICA CHECA',
                             'REPUBLICA DEMOCRATICA',
                             'REPUBLICA ESLOVACA',
                             'REPUBLICA KIRGUISA',
                             'REPUBLICA POPULAR DEMO',
                             'RESERVA',
                             'RESERVADO',
                             'RESERVADO - (UPT)',
                             'RESERVADO (IPRS)',
                             'RESERVADO (ISCS)',
                             'RESERVADO NO COMERCIA',
                             'RESERVADO PARA EL FUTU',
                             'RESERVADO SERVICIO MOV',
                             'REUNION (FRANCES)',
                             'RUMANIA',
                             'RWANDESA',
                             'SALOMON (ISLAS)',
                             'SAMOA',
                             'SAMOA NORTEAMERICANAS',
                             'SAN MARINO',
                             'SAN PEDRO Y MIQUELON',
                             'SANTA ELENA',
                             'SANTO TOME Y PRINCIPE',
                             'SENEGAL',
                             'SERVICIO DE LLAM GRATU',
                             'SEYCHELLES',
                             'SIERRA LEONA',
                             'SINGAPUR',
                             'SOMALI',
                             'SRI LANKA',
                             'ST VINCENT AND GRENADINES',
                             'SUDAFRICANA',
                             'SUDAN',
                             'SUECIA',
                             'SURINAME',
                             'SWAZILANDIA',
                             'TAILANDIA',
                             'TAIWAN',
                             'TANZANIA',
                             'TAYIKISTAN',
                             'TIMOR ORIENTAL',
                             'TOGOLESA',
                             'TOKELAU',
                             'TONGA',
                             'TUNEZ',
                             'TURKMENISTAN',
                             'TURQUIA',
                             'TUVALU',
                             'UCRANIA',
                             'UGANDA',
                             'UZBEKISTAN',
                             'VANUATU',
                             'VIETNAM',
                             'WALLIS Y FUTUNA (FRANC',
                             'YEMEN',
                             'YUGOSLAVIA',
                             'ZAMBIA',
                             'ZIMBABWE',
                             'BARBADOS',
                              'ANGUILA',
                              'ANTIGUA AND BARBUDA',
                              'US VIRGIN ISLANDS',
                              'BRITISH VIRGIN ISLANDS',
                              'BERMUDA',
                              'CAYMAN ISLANDS',
                              'TURKS AND CAICOS ISLANDS',
                              'GRENADA',
                              'MONTSERRAT',
                              'SINT MAARTEN',
                              'SAINT LUCIA',
                              'COMMONWEALTH OF DOMINICA',
                              'SAINT KITTS AND NEVIS',
                              'REPUBLICA DOMINICANA',
                              'TRINIDAD Y TOBAGO',
                              'PUERTO RICO',
                              'NORTHERN MARIANA ISLANDS',
                              'GUAM',
                              'AMERICAN SAMOA'
)
         GROUP BY T.ABON_ORIGEN) R
       WHERE R.LLAMADAS >= 7
         AND S.TELEFONO(+) = R.ABON_ORIGEN
UNION ALL
SELECT DISTINCT R.ABON_ORIGEN AS TELEFONO,
                      S.NOMBRE CLIENTE,
                      S.CUENTA CUENTA,
                      '' FECHA,
                      'LDI_TERCEROS' TRAFICO,
                      '' DESTINO,
                      'TERCER PAIS RESIDENCIAL' AS TIPO_ALARMA,
                      R.LLAMADAS,
                      R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'SUSPENDER EN IW' AS ACCION,
                      'INTRAWAY' AS SISTEMA_SUSPENSION,
                      'FRAUDE' SISTEMA_ORIGEN,
                      TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
        FROM SUSCRIPTORES_TMX_HFC S,
             (SELECT T.ABON_ORIGEN,
                     COUNT(1) LLAMADAS,
                     CEIL(SUM(T.DURATION / 60)) MINUTOS,
                     COUNT(DISTINCT T.ABON_DESTINO) NUM_DIF,
                     ROUND(COUNT(DISTINCT T.ABON_DESTINO) / COUNT(1) * 100) DISPERSION_ABONADOS
               FROM tmp_cdr_srt_hfc T
               WHERE T.TIPO_TRAFICO LIKE 'LDI%'
               AND T.DESTINO IN (' (GMSS)',
                             'AFGANISTAN',
                             'ALBANIA',
                             'ANDORRA',
                             'ANGOLA',
                             'ANTARTICA-ISLA DE NORFOLK',
                             'ARABIA SAUDITA',
                             'ARGELIA',
                             'ARMENIA',
                             'ASCENSION',
                             'AUSTRIA',
                             'AZERBAIYANA',
                             'BAHAMAS',
                             'BAHREIN',
                             'BANGLADESH',
                             'BELARUS',
                             'BELICE',
                             'BENIN',
                             'BHUTAN',
                             'BOSNIA Y HERZEGOVINA',
                             'BOTSWANA',
                             'BRUNEI DARUSSALAM',
                             'BULGARIA',
                             'BURKINA FASO',
                             'BURUNDI',
                             'CABO VERDE',
                             'CAMBOYA',
                             'CAMERUN',
                             'CENTROAFRICANA',
                             'CHAD',
                             'CHIPRE',
                             'CIUDAD DEL VATICANO',
                             'COMORAS',
                             'CONGO',
                             'COOK (ISLAS)',
                             'COTE DIVOIRE',
                             'CROACIA',
                             'DIEGO GARCIA',
                             'DINAMARCA',
                             'DJIBOUTI',
                             'EGIPTO',
                             'ENSAYO',
                             'ERITREA',
                             'ESLOVENIA',
                             'ESTONIA',
                             'ETIOPIA',
                             'FEROE (ISLAS)',
                             'FIJI',
                             'FILIPINAS',
                             'FINLANDIA',
                             'FRONTERIZO MARACAIBO',
                             'GABONESA',
                             'GAMBIA',
                             'GEORGIA',
                             'GHANA',
                             'GIBRALTAR',
                             'GRECIA',
                             'GROENLANDIA (DINAMARCA',
                             'GRUPO DE PAISES',
                             'GUADALUPE (FRANCIA)',
                             'GUAYANA FRANCESA',
                             'GUINEA',
                             'GUINEA ECUATORIAL',
                             'GUINEA-BISSAU',
                             'GUYANA',
                             'HONGKONG',
                             'HUNGRIA',
                             'INDIA',
                             'INDICATIVO DE RESERVA',
                             'INDONESIA',
                             'INMARSAT (OCEANO ATLAN',
                             'INMARSAT (OCEANO INDIC',
                             'INMARSAT (OCEANO PACIF',
                             'INMARSAT SNAC',
                             'IRAN',
                             'IRAQ',
                             'IRLANDA',
                             'ISLANDIA',
                             'JAMAICA',
                             'JAPON',
                             'JORDANIA',
                             'KAZAKSTAN - RUSIA',
                             'KENYA',
                             'KIRIBATI',
                             'KUWAIT',
                             'LA EX REPUBLICA YUGOSL',
                             'LAOS',
                             'LESOTHO',
                             'LETONIA',
                             'LIBANO',
                             'LIBERIA',
                             'LIBIA',
                             'LIECHTENSTEIN',
                             'LITUANIA',
                             'LUXEMBURGO',
                             'MACAU',
                             'MADAGASCAR',
                             'MALASIA',
                             'MALAWI',
                             'MALDIVAS',
                             'MALI',
                             'MALTA',
                             'MALVINAS',
                             'MARRUECOS',
                             'MARSHALL',
                             'MARTINICA',
                             'MAURICIO',
                             'MAURITANIA',
                             'MAYOTTE',
                             'MICRONESIA',
                             'MOLDOVA',
                             'MONACO',
                             'MONGOLIA',
                             'MOZAMBIQUE',
                             'MYANMAR',
                             'NAMIBIA',
                             'NAURU',
                             'NEPAL',
                             'NICARAGUA',
                             'NIGER',
                             'NIGERIA',
                             'NIUE',
                             'NORUEGA',
                             'NUEVA CALEDONIA (FRANC',
                             'NUEVA ZELANDIA',
                             'OMAN',
                             'PAISES BAJOS',
                             'PAKISTAN',
                             'PALAU',
                             'PAPUA NUEVA GUINEA',
                             'POLINESIA FRANCESA (FR',
                             'POLONIA',
                             'PREMIUM SERVICES',
                             'QATAR',
                             'REDES INTERNACIONALES',
                             'REPUBLICA ARABE SIRIA',
                             'REPUBLICA CHECA',
                             'REPUBLICA DEMOCRATICA',
                             'REPUBLICA ESLOVACA',
                             'REPUBLICA KIRGUISA',
                             'REPUBLICA POPULAR DEMO',
                             'RESERVA',
                             'RESERVADO',
                             'RESERVADO - (UPT)',
                             'RESERVADO (IPRS)',
                             'RESERVADO (ISCS)',
                             'RESERVADO NO COMERCIA',
                             'RESERVADO PARA EL FUTU',
                             'RESERVADO SERVICIO MOV',
                             'REUNION (FRANCES)',
                             'RUMANIA',
                             'RWANDESA',
                             'SALOMON (ISLAS)',
                             'SAMOA',
                             'SAMOA NORTEAMERICANAS',
                             'SAN MARINO',
                             'SAN PEDRO Y MIQUELON',
                             'SANTA ELENA',
                             'SANTO TOME Y PRINCIPE',
                             'SENEGAL',
                             'SERVICIO DE LLAM GRATU',
                             'SEYCHELLES',
                             'SIERRA LEONA',
                             'SINGAPUR',
                             'SOMALI',
                             'SRI LANKA',
                             'ST VINCENT AND GRENADINES',
                             'SUDAFRICANA',
                             'SUDAN',
                             'SUECIA',
                             'SURINAME',
                             'SWAZILANDIA',
                             'TAILANDIA',
                             'TAIWAN',
                             'TANZANIA',
                             'TAYIKISTAN',
                             'TIMOR ORIENTAL',
                             'TOGOLESA',
                             'TOKELAU',
                             'TONGA',
                             'TUNEZ',
                             'TURKMENISTAN',
                             'TURQUIA',
                             'TUVALU',
                             'UCRANIA',
                             'UGANDA',
                             'UZBEKISTAN',
                             'VANUATU',
                             'VIETNAM',
                             'WALLIS Y FUTUNA (FRANC',
                             'YEMEN',
                             'YUGOSLAVIA',
                             'ZAMBIA',
                             'ZIMBABWE',
                             'BARBADOS',
                              'ANGUILA',
                              'ANTIGUA AND BARBUDA',
                              'US VIRGIN ISLANDS',
                              'BRITISH VIRGIN ISLANDS',
                              'BERMUDA',
                              'CAYMAN ISLANDS',
                              'TURKS AND CAICOS ISLANDS',
                              'GRENADA',
                              'MONTSERRAT',
                              'SINT MAARTEN',
                              'SAINT LUCIA',
                              'COMMONWEALTH OF DOMINICA',
                              'SAINT KITTS AND NEVIS',
                              'REPUBLICA DOMINICANA',
                              'TRINIDAD Y TOBAGO',
                              'PUERTO RICO',
                              'NORTHERN MARIANA ISLANDS',
                              'GUAM',
                              'AMERICAN SAMOA'
                              )
        GROUP BY T.ABON_ORIGEN) R
       WHERE S.TELEFONO(+) = R.ABON_ORIGEN
       AND R.LLAMADAS >='7'  
UNION ALL
              SELECT DISTINCT R.ABON_ORIGEN AS TELEFONO,
                      S.NOMBRE CLIENTE,
                      S.CUENTA CUENTA,
                      '' FECHA,
                      'LDI_TERCEROS' TRAFICO,
                      '' DESTINO,
                      'TERCER PAIS RESIDENCIAL' AS TIPO_ALARMA,
                      R.LLAMADAS,
                      R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'SUSPENDER EN IW' AS ACCION,
                      'INTRAWAY' AS SISTEMA_SUSPENSION,
                      'FRAUDE' SISTEMA_ORIGEN,
                      TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
        FROM SUSCRIPTORES_TMX_HFC S,
             (SELECT T.ABON_ORIGEN,
                     COUNT(1) LLAMADAS,
                     CEIL(SUM(T.DURATION / 60)) MINUTOS,
                     COUNT(DISTINCT T.ABON_DESTINO) NUM_DIF,
                     ROUND(COUNT(DISTINCT T.ABON_DESTINO) / COUNT(1) * 100) DISPERSION_ABONADOS
               FROM FRAUDE.TMP_CDR_TMXH_HFC_TRAFICO T --TECNICA
               WHERE T.TIPO_TRAFICO LIKE 'LDI%'
           AND
(
   trim(called_number)like 	'8818905___%'	--	 (GMSS)	TOLL FRAUD	20/08/2014
or trim(called_number)like 	'88193521____%'	--	 (GMSS)	TOLL FRAUD	41331
or trim(called_number)like 	'8818481____%'	--	 (GMSS)	TOLL FRAUD	41333
or trim(called_number)like 	'935466811__%'	--	AFGANISTAN	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'93708______%'	--	AFGANISTAN	TOLL FRAUD	20/08/2014
or trim(called_number)like 	'93752289___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93777463___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93780009___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93780872___%'	--	AFGANISTAN	TOLL FRAUD	41040
or trim(called_number)like 	'93795903___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93797458___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'3554249____%'	--	ALBANIA	TOLL FRAUD	41331
or trim(called_number)like 	'35566_______'	--	ALBANIA	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'1264536____%'	--	ANGUILA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'12687802___%'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'12687803515'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'12687803536'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'2135590000__%'	--	ARGELIA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'37447994___%'	--	ARMENIA	TOLL FRAUD	21/08/2014
or trim(called_number)like 	'37497745___%'	--	ARMENIA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'297640____%'	--	ARUBA	TOLL FRAUD	41182
or trim(called_number)like 	'2979953___%'	--	ARUBA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'61296679111%'	--	AUSTRALIA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'43810______'	--	AUSTRIA	TOLL FRAUD	41246
or trim(called_number)like 	'43820______%'	--	AUSTRIA	TOLL FRAUD	
or trim(called_number)like 	'43821______%'	--	AUSTRIA	TOLL FRAUD	41333
or trim(called_number)like 	'43828______%'	--	AUSTRIA	TOLL FRAUD	41333
or trim(called_number)like 	'43678901____%'	--	AUSTRIA	TOLL FRAUD	41333
or trim(called_number)like 	'9944001_____%'	--	AZERBAIYANA	TOLL FRAUD	41193
or trim(called_number)like 	'9944002_____%'	--	AZERBAIYANA	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'1246256____%'	--	BARBADOS	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'1246859____%'	--	BARBADOS	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'375239886___%'	--	BELARUS	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'375297298___%'	--	BELARUS	TOLL FRAUD	41166
or trim(called_number)like 	'375333______%'	--	BELARUS	TOLL FRAUD	41206
or trim(called_number)like 	'375602______%'	--	BELARUS	TOLL FRAUD	41333
or trim(called_number)like 	'375777______%'	--	BELARUS	TOLL FRAUD	41333
or trim(called_number)like 	'3752947____%'	--	BELARUS	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'22995964___%'	--	BENIN	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'3876_______%'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	41333
or trim(called_number)like 	'387302_____%'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'2677626_____%'	--	BOTSWANA	TOLL FRAUD	25/08/2014
or trim(called_number)like 	'22670102___%'	--	BURKINA FASO	TOLL FRAUD	41333
or trim(called_number)like 	'22670799___%'	--	BURKINA FASO	TOLL FRAUD	25/08/2014
or trim(called_number)like 	'257161_____%'	--	BURUNDI	TOLL FRAUD	26/08/2014
or trim(called_number)like 	'236877_____%'	--	CENTROAFRICANA	TOLL FRAUD	26/08/2014
or trim(called_number)like 	'23599______%'	--	CHAD	TOLL FRAUD	41333
or trim(called_number)like 	'56__197____%'	--	CHILE	TOLL FRAUD	
or trim(called_number)like 	'562196____%'	--	CHILE	TOLL FRAUD	41135
or trim(called_number)like 	'562197____%'	--	CHILE	TOLL FRAUD	41171
or trim(called_number)like 	'5645197____%'	--	CHILE	TOLL FRAUD	20/08/2014
or trim(called_number)like 	'56266675__%'	--	CHILE	TOLL FRAUD	
or trim(called_number)like 	'56322553___%'	--	CHILE	TOLL FRAUD	41168
or trim(called_number)like 	'5673970060'	--	CHILE	TOLL FRAUD	41136
or trim(called_number)like 	'5699027____'	--	CHILE	TOLL FRAUD	41246
or trim(called_number)like 	'1767503____%'	--	COMMONWEALTH OF DOMINICA	TOLL FRAUD	41331
or trim(called_number)like 	'24204428____%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'242800______%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243809850___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243809900___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243890026___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243890822___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'22521709___%'	--	COTE DIVOIRE	TOLL FRAUD	16/09/2014
or trim(called_number)like 	'385958______%'	--	CROACIA	TOLL FRAUD	41113
or trim(called_number)like 	'5337899___%'	--	CUBA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'5347251___%'	--	CUBA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'5351231___%'	--	CUBA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'5345619___%'	--	CUBA	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'2011555_____%'	--	EGIPTO	TOLL FRAUD	41109
or trim(called_number)like 	'5032488____%'	--	EL SALVADOR	TOLL FRAUD	03/12/2014
or trim(called_number)like 	'50325606___%'	--	EL SALVADOR	TOLL FRAUD	03/12/2014
or trim(called_number)like 	'503745_____%'	--	EL SALVADOR	TOLL FRAUD	14/01/2015
or trim(called_number)like 	'503777_____%'	--	EL SALVADOR	TOLL FRAUD	28/10/2014
or trim(called_number)like 	'50378545048%'	--	EL SALVADOR	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'503797_____%'	--	EL SALVADOR	TOLL FRAUD	18/11/2014
or trim(called_number)like 	'50376865___%'	--	EL SALVADOR	TOLL FRAUD	15/01/2015
or trim(called_number)like 	'345182031__%'	--	ESPAÑA	TOLL FRAUD	41178
or trim(called_number)like 	'3460100____%'	--	ESPAÑA	TOLL FRAUD	40982
or trim(called_number)like 	'3460110____%'	--	ESPAÑA	TOLL FRAUD	41138
or trim(called_number)like 	'3464001____%'	--	ESPAÑA	TOLL FRAUD	41111
or trim(called_number)like 	'34902500874%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'349025029__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'349025030__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'349025031__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'34902056___%'	--	ESPAÑA	TOLL FRAUD	41122
or trim(called_number)like 	'34902530___%'	--	ESPAÑA	TOLL FRAUD	41163
or trim(called_number)like 	'34902917___%'	--	ESPAÑA	TOLL FRAUD	41332
or trim(called_number)like 	'34902041___%'	--	ESPAÑA	TOLL FRAUD	41333
or trim(called_number)like 	'34902042___%'	--	ESPAÑA	TOLL FRAUD	41333
or trim(called_number)like 	'34902043___%'	--	ESPAÑA	TOLL FRAUD	04/10/2013
or trim(called_number)like 	'37240______%'	--	ESTONIA	TOLL FRAUD	41333
or trim(called_number)like 	'37270______'	--	ESTONIA	TOLL FRAUD	41247
or trim(called_number)like 	'37290_____%'	--	ESTONIA	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'6392000____%'	--	FILIPINAS	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'3364001____%'	--	FRANCIA	TOLL FRAUD	41178
or trim(called_number)like 	'241052_____%'	--	GABONESA	TOLL FRAUD	41331
or trim(called_number)like 	'241053_____%'	--	GABONESA	TOLL FRAUD	41331
or trim(called_number)like 	'220777____%'	--	GAMBIA	TOLL FRAUD	41182
or trim(called_number)like 	'50230264986%'	--	GUATEMALA	TOLL FRAUD	41182
or trim(called_number)like 	'22455______'	--	GUINEA	TOLL FRAUD	41247
or trim(called_number)like 	'22478______'	--	GUINEA	TOLL FRAUD	41247
or trim(called_number)like 	'5926386___%'	--	GUYANA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'50928167___%'	--	HAITI	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'5092817____%'	--	HAITI	TOLL FRAUD	41122
or trim(called_number)like 	'50944911___%'	--	HAITI	TOLL FRAUD	41332
or trim(called_number)like 	'50937756___%'	--	HAITI	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'5048737052%'	--	HONDURAS	TOLL FRAUD	40906
or trim(called_number)like 	'38288000___%'	--	INDICATIVO DE RESERVA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'39319905____%'	--	ITALIA	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'1345550____%'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014
or trim(called_number)like 	'1345925____%'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014
or trim(called_number)like 	'1345235____%'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014
or trim(called_number)like 	'7254476____%'	--	KASAKSTAN	TOLL FRAUD	20/01/2014
or trim(called_number)like 	'%72598281141%'	--	ISRAEL	TOLL FRAUD	41169
or trim(called_number)like 	'%72599429449%'	--	ISRAEL	TOLL FRAUD	41169
or trim(called_number)like 	'187646____%'	--	JAMAICA	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'187684_____%'	--	JAMAICA	TOLL FRAUD	40991
or trim(called_number)like 	'38978_____%'	--	LA EX REPUBLICA YUGOSL	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'3712278____%'	--	LETONIA	TOLL FRAUD	41333
or trim(called_number)like 	'3712279____%'	--	LETONIA	TOLL FRAUD	41333
or trim(called_number)like 	'2315320___%'	--	LIBERIA	TOLL FRAUD	41246
or trim(called_number)like 	'23190201___%'	--	LIBERIA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'423870____'	--	LIECHTENSTEIN	TOLL FRAUD	41334
or trim(called_number)like 	'423877____%'	--	LIECHTENSTEIN	TOLL FRAUD	41246
or trim(called_number)like 	'42390_____%'	--	LIECHTENSTEIN	TOLL FRAUD	41246
or trim(called_number)like 	'3707_______%'	--	LITUANIA	TOLL FRAUD	41246
or trim(called_number)like 	'3708_______%'	--	LITUANIA	TOLL FRAUD	41246
or trim(called_number)like 	'3709_______%'	--	LITUANIA	TOLL FRAUD	41246
or trim(called_number)like 	'35228489___%'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'352691003___%'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'9607______%'	--	MALDIVAS	TOLL FRAUD	41246
or trim(called_number)like 	'9609______%'	--	MALDIVAS	TOLL FRAUD	41246
or trim(called_number)like 	'21269228____%'	--	MARRUECOS	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'212645591___%'	--	MARRUECOS	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'37369878___%'	--	MOLDOVA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'3739_______%'	--	MOLDOVA	TOLL FRAUD	41331
or trim(called_number)like 	'37744______%'	--	MONACO	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'37745______%'	--	MONACO	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'6745599___%'	--	NAURU	TOLL FRAUD	15/01/2015
or trim(called_number)like 	'50588842080%'	--	NICARAGUA	TOLL FRAUD	40907
or trim(called_number)like 	'50588919___%'	--	NICARAGUA	TOLL FRAUD	40921
or trim(called_number)like 	'227201_____%'	--	NIGER	TOLL FRAUD	41331
or trim(called_number)like 	'227203_____%'	--	NIGER	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'51648_____%'	--	PERU	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'51518_____%'	--	PERU	TOLL FRAUD	05/08/2014
or trim(called_number)like 	'51528_____%'	--	PERU	TOLL FRAUD	05/08/2014
or trim(called_number)like 	'4876856____%'	--	POLONIA	TOLL FRAUD	41113
or trim(called_number)like 	'9743920____%'	--	QATAR	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'88233010___%'	--	REDES INTERNACIONALES	TOLL FRAUD	41182
or trim(called_number)like 	'239220____%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	41145
or trim(called_number)like 	'239990____%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'2393879___%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'23222______%'	--	SIERRA LEONA	TOLL FRAUD	41167
or trim(called_number)like 	'252223____%'	--	SOMALI	TOLL FRAUD	41246
or trim(called_number)like 	'25229722___%'	--	SOMALI	TOLL FRAUD	16/10/2014
or trim(called_number)like 	'25230______%'	--	SOMALI	TOLL FRAUD	41246
or trim(called_number)like 	'25240______%'	--	SOMALI	TOLL FRAUD	41246
or trim(called_number)like 	'252541____%'	--	SOMALI	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'25270______%'	--	SOMALI	TOLL FRAUD	03/12/2012
or trim(called_number)like 	'5977200___%'	--	SURINAME	TOLL FRAUD	26/02/2013
or trim(called_number)like 	'8869135_____%'	--	TAIWAN	TOLL FRAUD	16/03/2012
or trim(called_number)like 	'670330____'	--	TIMOR ORIENTAL	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'21620999___%'	--	TUNEZ	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'44190489____%'	--	UK	TOLL FRAUD	28/01/2015
or trim(called_number)like 	'442034321288'	--	UK	TOLL FRAUD	15/08/2012
or trim(called_number)like 	'447023815___%'	--	UK	TOLL FRAUD	16/10/2014
or trim(called_number)like 	'44708_______%'	--	UK	TOLL FRAUD	01/09/2014
or trim(called_number)like 	'4474065_____%'	--	UK	TOLL FRAUD	
or trim(called_number)like 	'4474179_____%'	--	UK	TOLL FRAUD	23/03/2012
or trim(called_number)like 	'447589______%'	--	UK	TOLL FRAUD	13/01/2012
or trim(called_number)like 	'447822118___%'	--	UK	TOLL FRAUD	13/06/2014
or trim(called_number)like 	'447893362345%'	--	UK	TOLL FRAUD	16/09/2014
or trim(called_number)like 	'442075005000%'	--	UK	TOLL FRAUD	28/08/2013
or trim(called_number)like 	'441212792618%'	--	UK	TOLL FRAUD	29/08/2013
or trim(called_number)like 	'448714610___%'	--	UK	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'13459254300%'	--	USA	TOLL FRAUD	
or trim(called_number)like 	'17862422224%'	--	USA	REFILE	21/03/2014
or trim(called_number)like 	'18005551111%'	--	USA y TOLL FREE	TOLL FRAUD	04/10/2013
or trim(called_number)like 	'68172____%'	--	WALLIS Y FUTUNA (FRANC	TOLL FRAUD	41246
or trim(called_number)like 	'381608______%'	--	YUGOSLAVIA	TOLL FRAUD	41333
or trim(called_number)like 	'38166_______'	--	YUGOSLAVIA	TOLL FRAUD	28/08/2014

   
)
    GROUP BY T.ABON_ORIGEN
       ) R       
      WHERE S.TELEFONO(+) = R.ABON_ORIGEN 
UNION ALL
SELECT DISTINCT R.ABON_ORIGEN AS TELEFONO,
                      S.NOMBRE CLIENTE,
                      S.CUENTA CUENTA,
                      '' FECHA,
                      'LDI_TERCEROS' TRAFICO,
                      '' DESTINO,
                      'TERCER PAIS RESIDENCIAL' AS TIPO_ALARMA,
                      R.LLAMADAS,
			                R.DISPERSION_ABONADOS NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'SUSPENDER EN IW' AS ACCION,
                      'INTRAWAY' AS SISTEMA_SUSPENSION,
                      'FRAUDE' SISTEMA_ORIGEN,
                      TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
        FROM SUSCRIPTORES_TMX_HFC S,
             (SELECT T.ABON_ORIGEN,
                     COUNT(1) LLAMADAS,
                     CEIL(SUM(T.DURATION / 60)) MINUTOS,
                     COUNT(DISTINCT T.ABON_DESTINO) NUM_DIF,
                     ROUND(COUNT(DISTINCT T.ABON_DESTINO) / COUNT(1) * 100) DISPERSION_ABONADOS
               FROM tmp_cdr_srt_hfc T --temporal SRT
               WHERE T.TIPO_TRAFICO LIKE 'LDI%'
           AND 
(
   trim(called_number)like 	'8818905___%'	--	 (GMSS)	TOLL FRAUD	20/08/2014
or trim(called_number)like 	'88193521____%'	--	 (GMSS)	TOLL FRAUD	41331
or trim(called_number)like 	'8818481____%'	--	 (GMSS)	TOLL FRAUD	41333
or trim(called_number)like 	'935466811__%'	--	AFGANISTAN	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'93708______%'	--	AFGANISTAN	TOLL FRAUD	20/08/2014
or trim(called_number)like 	'93752289___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93777463___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93780009___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93780872___%'	--	AFGANISTAN	TOLL FRAUD	41040
or trim(called_number)like 	'93795903___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'93797458___%'	--	AFGANISTAN	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'3554249____%'	--	ALBANIA	TOLL FRAUD	41331
or trim(called_number)like 	'35566_______'	--	ALBANIA	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'1264536____%'	--	ANGUILA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'12687802___%'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'12687803515'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'12687803536'	--	ANTIGUA AND BARBUDA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'2135590000__%'	--	ARGELIA	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'37447994___%'	--	ARMENIA	TOLL FRAUD	21/08/2014
or trim(called_number)like 	'37497745___%'	--	ARMENIA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'297640____%'	--	ARUBA	TOLL FRAUD	41182
or trim(called_number)like 	'2979953___%'	--	ARUBA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'61296679111%'	--	AUSTRALIA	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'43810______'	--	AUSTRIA	TOLL FRAUD	41246
or trim(called_number)like 	'43820______%'	--	AUSTRIA	TOLL FRAUD	
or trim(called_number)like 	'43821______%'	--	AUSTRIA	TOLL FRAUD	41333
or trim(called_number)like 	'43828______%'	--	AUSTRIA	TOLL FRAUD	41333
or trim(called_number)like 	'43678901____%'	--	AUSTRIA	TOLL FRAUD	41333
or trim(called_number)like 	'9944001_____%'	--	AZERBAIYANA	TOLL FRAUD	41193
or trim(called_number)like 	'9944002_____%'	--	AZERBAIYANA	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'1246256____%'	--	BARBADOS	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'1246859____%'	--	BARBADOS	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'375239886___%'	--	BELARUS	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'375297298___%'	--	BELARUS	TOLL FRAUD	41166
or trim(called_number)like 	'375333______%'	--	BELARUS	TOLL FRAUD	41206
or trim(called_number)like 	'375602______%'	--	BELARUS	TOLL FRAUD	41333
or trim(called_number)like 	'375777______%'	--	BELARUS	TOLL FRAUD	41333
or trim(called_number)like 	'3752947____%'	--	BELARUS	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'22995964___%'	--	BENIN	TOLL FRAUD	22/08/2014
or trim(called_number)like 	'3876_______%'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	41333
or trim(called_number)like 	'387302_____%'	--	BOSNIA Y HERZEGOVINA	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'2677626_____%'	--	BOTSWANA	TOLL FRAUD	25/08/2014
or trim(called_number)like 	'22670102___%'	--	BURKINA FASO	TOLL FRAUD	41333
or trim(called_number)like 	'22670799___%'	--	BURKINA FASO	TOLL FRAUD	25/08/2014
or trim(called_number)like 	'257161_____%'	--	BURUNDI	TOLL FRAUD	26/08/2014
or trim(called_number)like 	'236877_____%'	--	CENTROAFRICANA	TOLL FRAUD	26/08/2014
or trim(called_number)like 	'23599______%'	--	CHAD	TOLL FRAUD	41333
or trim(called_number)like 	'56__197____%'	--	CHILE	TOLL FRAUD	
or trim(called_number)like 	'562196____%'	--	CHILE	TOLL FRAUD	41135
or trim(called_number)like 	'562197____%'	--	CHILE	TOLL FRAUD	41171
or trim(called_number)like 	'5645197____%'	--	CHILE	TOLL FRAUD	20/08/2014
or trim(called_number)like 	'56266675__%'	--	CHILE	TOLL FRAUD	
or trim(called_number)like 	'56322553___%'	--	CHILE	TOLL FRAUD	41168
or trim(called_number)like 	'5673970060'	--	CHILE	TOLL FRAUD	41136
or trim(called_number)like 	'5699027____'	--	CHILE	TOLL FRAUD	41246
or trim(called_number)like 	'1767503____%'	--	COMMONWEALTH OF DOMINICA	TOLL FRAUD	41331
or trim(called_number)like 	'24204428____%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'242800______%'	--	CONGO - REPUBLICA DE	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243809850___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243809900___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243890026___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'243890822___%'	--	CONGO - REPUBLICA DEMOCRATICA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'22521709___%'	--	COTE DIVOIRE	TOLL FRAUD	16/09/2014
or trim(called_number)like 	'385958______%'	--	CROACIA	TOLL FRAUD	41113
or trim(called_number)like 	'5337899___%'	--	CUBA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'5347251___%'	--	CUBA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'5351231___%'	--	CUBA	TOLL FRAUD	02/01/2015
or trim(called_number)like 	'5345619___%'	--	CUBA	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'2011555_____%'	--	EGIPTO	TOLL FRAUD	41109
or trim(called_number)like 	'5032488____%'	--	EL SALVADOR	TOLL FRAUD	03/12/2014
or trim(called_number)like 	'50325606___%'	--	EL SALVADOR	TOLL FRAUD	03/12/2014
or trim(called_number)like 	'503745_____%'	--	EL SALVADOR	TOLL FRAUD	14/01/2015
or trim(called_number)like 	'503777_____%'	--	EL SALVADOR	TOLL FRAUD	28/10/2014
or trim(called_number)like 	'50378545048%'	--	EL SALVADOR	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'503797_____%'	--	EL SALVADOR	TOLL FRAUD	18/11/2014
or trim(called_number)like 	'50376865___%'	--	EL SALVADOR	TOLL FRAUD	15/01/2015
or trim(called_number)like 	'345182031__%'	--	ESPAÑA	TOLL FRAUD	41178
or trim(called_number)like 	'3460100____%'	--	ESPAÑA	TOLL FRAUD	40982
or trim(called_number)like 	'3460110____%'	--	ESPAÑA	TOLL FRAUD	41138
or trim(called_number)like 	'3464001____%'	--	ESPAÑA	TOLL FRAUD	41111
or trim(called_number)like 	'34902500874%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'349025029__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'349025030__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'349025031__%'	--	ESPAÑA	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'34902056___%'	--	ESPAÑA	TOLL FRAUD	41122
or trim(called_number)like 	'34902530___%'	--	ESPAÑA	TOLL FRAUD	41163
or trim(called_number)like 	'34902917___%'	--	ESPAÑA	TOLL FRAUD	41332
or trim(called_number)like 	'34902041___%'	--	ESPAÑA	TOLL FRAUD	41333
or trim(called_number)like 	'34902042___%'	--	ESPAÑA	TOLL FRAUD	41333
or trim(called_number)like 	'34902043___%'	--	ESPAÑA	TOLL FRAUD	04/10/2013
or trim(called_number)like 	'37240______%'	--	ESTONIA	TOLL FRAUD	41333
or trim(called_number)like 	'37270______'	--	ESTONIA	TOLL FRAUD	41247
or trim(called_number)like 	'37290_____%'	--	ESTONIA	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'6392000____%'	--	FILIPINAS	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'3364001____%'	--	FRANCIA	TOLL FRAUD	41178
or trim(called_number)like 	'241052_____%'	--	GABONESA	TOLL FRAUD	41331
or trim(called_number)like 	'241053_____%'	--	GABONESA	TOLL FRAUD	41331
or trim(called_number)like 	'220777____%'	--	GAMBIA	TOLL FRAUD	41182
or trim(called_number)like 	'50230264986%'	--	GUATEMALA	TOLL FRAUD	41182
or trim(called_number)like 	'22455______'	--	GUINEA	TOLL FRAUD	41247
or trim(called_number)like 	'22478______'	--	GUINEA	TOLL FRAUD	41247
or trim(called_number)like 	'5926386___%'	--	GUYANA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'50928167___%'	--	HAITI	TOLL FRAUD	14/10/2014
or trim(called_number)like 	'5092817____%'	--	HAITI	TOLL FRAUD	41122
or trim(called_number)like 	'50944911___%'	--	HAITI	TOLL FRAUD	41332
or trim(called_number)like 	'50937756___%'	--	HAITI	TOLL FRAUD	27/01/2015
or trim(called_number)like 	'5048737052%'	--	HONDURAS	TOLL FRAUD	40906
or trim(called_number)like 	'38288000___%'	--	INDICATIVO DE RESERVA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'39319905____%'	--	ITALIA	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'1345550____%'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014
or trim(called_number)like 	'1345925____%'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014
or trim(called_number)like 	'1345235____%'	--	CAYMAN ISLANDS	TOLL FRAUD	07/11/2014
or trim(called_number)like 	'7254476____%'	--	KASAKSTAN	TOLL FRAUD	20/01/2014
or trim(called_number)like 	'%72598281141%'	--	ISRAEL	TOLL FRAUD	41169
or trim(called_number)like 	'%72599429449%'	--	ISRAEL	TOLL FRAUD	41169
or trim(called_number)like 	'187646____%'	--	JAMAICA	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'187684_____%'	--	JAMAICA	TOLL FRAUD	40991
or trim(called_number)like 	'38978_____%'	--	LA EX REPUBLICA YUGOSL	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'3712278____%'	--	LETONIA	TOLL FRAUD	41333
or trim(called_number)like 	'3712279____%'	--	LETONIA	TOLL FRAUD	41333
or trim(called_number)like 	'2315320___%'	--	LIBERIA	TOLL FRAUD	41246
or trim(called_number)like 	'23190201___%'	--	LIBERIA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'423870____'	--	LIECHTENSTEIN	TOLL FRAUD	41334
or trim(called_number)like 	'423877____%'	--	LIECHTENSTEIN	TOLL FRAUD	41246
or trim(called_number)like 	'42390_____%'	--	LIECHTENSTEIN	TOLL FRAUD	41246
or trim(called_number)like 	'3707_______%'	--	LITUANIA	TOLL FRAUD	41246
or trim(called_number)like 	'3708_______%'	--	LITUANIA	TOLL FRAUD	41246
or trim(called_number)like 	'3709_______%'	--	LITUANIA	TOLL FRAUD	41246
or trim(called_number)like 	'35228489___%'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'352691003___%'	--	LUXEMBURGO	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'9607______%'	--	MALDIVAS	TOLL FRAUD	41246
or trim(called_number)like 	'9609______%'	--	MALDIVAS	TOLL FRAUD	41246
or trim(called_number)like 	'21269228____%'	--	MARRUECOS	TOLL FRAUD	04/08/2014
or trim(called_number)like 	'212645591___%'	--	MARRUECOS	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'37369878___%'	--	MOLDOVA	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'3739_______%'	--	MOLDOVA	TOLL FRAUD	41331
or trim(called_number)like 	'37744______%'	--	MONACO	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'37745______%'	--	MONACO	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'6745599___%'	--	NAURU	TOLL FRAUD	15/01/2015
or trim(called_number)like 	'50588842080%'	--	NICARAGUA	TOLL FRAUD	40907
or trim(called_number)like 	'50588919___%'	--	NICARAGUA	TOLL FRAUD	40921
or trim(called_number)like 	'227201_____%'	--	NIGER	TOLL FRAUD	41331
or trim(called_number)like 	'227203_____%'	--	NIGER	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'51648_____%'	--	PERU	TOLL FRAUD	16/01/2014
or trim(called_number)like 	'51518_____%'	--	PERU	TOLL FRAUD	05/08/2014
or trim(called_number)like 	'51528_____%'	--	PERU	TOLL FRAUD	05/08/2014
or trim(called_number)like 	'4876856____%'	--	POLONIA	TOLL FRAUD	41113
or trim(called_number)like 	'9743920____%'	--	QATAR	TOLL FRAUD	17/12/2014
or trim(called_number)like 	'88233010___%'	--	REDES INTERNACIONALES	TOLL FRAUD	41182
or trim(called_number)like 	'239220____%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	41145
or trim(called_number)like 	'239990____%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'2393879___%'	--	SANTO TOME Y PRINCIPE	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'23222______%'	--	SIERRA LEONA	TOLL FRAUD	41167
or trim(called_number)like 	'252223____%'	--	SOMALI	TOLL FRAUD	41246
or trim(called_number)like 	'25229722___%'	--	SOMALI	TOLL FRAUD	16/10/2014
or trim(called_number)like 	'25230______%'	--	SOMALI	TOLL FRAUD	41246
or trim(called_number)like 	'25240______%'	--	SOMALI	TOLL FRAUD	41246
or trim(called_number)like 	'252541____%'	--	SOMALI	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'25270______%'	--	SOMALI	TOLL FRAUD	03/12/2012
or trim(called_number)like 	'5977200___%'	--	SURINAME	TOLL FRAUD	26/02/2013
or trim(called_number)like 	'8869135_____%'	--	TAIWAN	TOLL FRAUD	16/03/2012
or trim(called_number)like 	'670330____'	--	TIMOR ORIENTAL	TOLL FRAUD	28/08/2014
or trim(called_number)like 	'21620999___%'	--	TUNEZ	TOLL FRAUD	13/01/2015
or trim(called_number)like 	'44190489____%'	--	UK	TOLL FRAUD	28/01/2015
or trim(called_number)like 	'442034321288'	--	UK	TOLL FRAUD	15/08/2012
or trim(called_number)like 	'447023815___%'	--	UK	TOLL FRAUD	16/10/2014
or trim(called_number)like 	'44708_______%'	--	UK	TOLL FRAUD	01/09/2014
or trim(called_number)like 	'4474065_____%'	--	UK	TOLL FRAUD	
or trim(called_number)like 	'4474179_____%'	--	UK	TOLL FRAUD	23/03/2012
or trim(called_number)like 	'447589______%'	--	UK	TOLL FRAUD	13/01/2012
or trim(called_number)like 	'447822118___%'	--	UK	TOLL FRAUD	13/06/2014
or trim(called_number)like 	'447893362345%'	--	UK	TOLL FRAUD	16/09/2014
or trim(called_number)like 	'442075005000%'	--	UK	TOLL FRAUD	28/08/2013
or trim(called_number)like 	'441212792618%'	--	UK	TOLL FRAUD	29/08/2013
or trim(called_number)like 	'448714610___%'	--	UK	TOLL FRAUD	02/12/2014
or trim(called_number)like 	'13459254300%'	--	USA	TOLL FRAUD	
or trim(called_number)like 	'17862422224%'	--	USA	REFILE	21/03/2014
or trim(called_number)like 	'18005551111%'	--	USA y TOLL FREE	TOLL FRAUD	04/10/2013
or trim(called_number)like 	'68172____%'	--	WALLIS Y FUTUNA (FRANC	TOLL FRAUD	41246
or trim(called_number)like 	'381608______%'	--	YUGOSLAVIA	TOLL FRAUD	41333
or trim(called_number)like 	'38166_______'	--	YUGOSLAVIA	TOLL FRAUD	28/08/2014
   
)
        GROUP BY T.ABON_ORIGEN) R
       WHERE S.TELEFONO(+) = R.ABON_ORIGEN
       ORDER BY 13, 14, 15, 1;
  
  END PR_TERCER_PAIS_HOGARES;

  PROCEDURE PR_TERCER_PAIS_FRAUDVIEW(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_TERCER_PAIS_FRAUDVIEW
    **
    ** DESCRIPTION:    CONSULTA LOS FRAUDES DE TERCER PAIS DE FRAUDVIEW
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 17-FEB-10      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LOS FRAUDES DE TERCER PAIS DE FRAUDVIEW
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
      SELECT DISTINCT R.TELEFONO AS TELEFONO,
                      S.NOMBRE CLIENTE,
                      S.CUENTA CUENTA,
                      '' FECHA,
                      'LDI' TRAFICO,
                      '' DESTINO,
                      (CASE
                        WHEN R.TIPO_ABONADO IN ('0', '5', '10') THEN
                         'TERCER_PAIS_RESIDENCIAL'
                        WHEN R.TIPO_ABONADO IN
                             ('1', '2', '3', '4', '6', '7', '8') THEN
                         'TERCER_PAIS_CORPORATIVO'
                      END) AS TIPO_ALARMA,
                      R.LLAMADAS,
                      R.DISPERSION NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'SUSPENDER EN RR' AS ACCION,
                      'RR' AS SISTEMA_SUSPENSION,
                      'FRAUD VIEW' SISTEMA_ORIGEN,
                      TO_CHAR(TO_DATE(R.FECHA_ALARMA || ' 09:00:00',
                                      'DD/MM/YYYY HH:MI:SS'),
                              'YYYYMMDD HH24') FECHA_ALARMA
        FROM SUSCRIPTORES_TMX_HFC S, ALARMAS_FV R
       WHERE R.TELEFONO NOT IN
             (SELECT M.NUMERO FROM FRAUDE.MAESTRA_BLANCOS M)
         AND S.TELEFONO = R.TELEFONO
      UNION ALL
      SELECT DISTINCT R.TELEFONO AS TELEFONO,
                      S.NOMBRE_CLIENTE CLIENTE,
                      S.CODIGO_CLIENTE CUENTA,
                      '' FECHA,
                      'LDI' TRAFICO,
                      '' DESTINO,
                      (CASE
                        WHEN R.TIPO_ABONADO IN ('0') THEN
                         'TERCER_PAIS_RESIDENCIAL'
                        WHEN R.TIPO_ABONADO IN
                             ('1', '2', '3', '4', '6', '7', '8', '5', '10') THEN
                         'TERCER_PAIS_CORPORATIVO'
                      END) AS TIPO_ALARMA,
                      R.LLAMADAS,
                      R.DISPERSION NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'INGRESAR NOVEDAD ONYX' AS ACCION,
                      'ONYX' AS SISTEMA_SUSPENSION,
                      'FRAUD VIEW' SISTEMA_ORIGEN,
                      TO_CHAR(TO_DATE(R.FECHA_ALARMA || ' 09:00:00',
                                      'DD/MM/YYYY HH:MI:SS'),
                              'YYYYMMDD HH24') FECHA_ALARMA
        FROM SUSCRIPTORES S, ALARMAS_FV R
       WHERE R.TELEFONO NOT IN
             (SELECT M.NUMERO FROM FRAUDE.MAESTRA_BLANCOS M)
         AND S.TELEFONO8 = R.TELEFONO
      UNION ALL
      SELECT DISTINCT R.TELEFONO AS TELEFONO,
                      '' CLIENTE,
                      T.CUENTA || P.CODIGO_CLIENTE CUENTA,
                      '' FECHA,
                      'LDI' TRAFICO,
                      '' DESTINO,
                      (CASE
                        WHEN R.TIPO_ABONADO IN ('0') THEN
                         'TERCER_PAIS_RESIDENCIAL'
                        WHEN R.TIPO_ABONADO IN
                             ('1', '2', '3', '4', '6', '7', '8') THEN
                         'TERCER_PAIS_CORPORATIVO'
                        WHEN R.TIPO_ABONADO IN ('5') AND
                             N.MUNICIPIO_SERVICIO IS NULL THEN
                         'TERCER_PAIS_CORPORATIVO'
                        WHEN R.TIPO_ABONADO IN ('10') AND
                             N.MUNICIPIO_SERVICIO IS NULL THEN
                         'TERCER_PAIS_CORPORATIVO'
                        WHEN R.TIPO_ABONADO IN ('10') AND
                             N.MUNICIPIO_SERVICIO IS NOT NULL THEN
                         'TERCER_PAIS_RESIDENCIAL'
                      END) AS TIPO_ALARMA,
                      R.LLAMADAS,
                      R.DISPERSION NUMEROS_DISTINTOS,
                      R.MINUTOS MINUTOS,
                      '' HORA_MIN,
                      '' HORA_MAX,
                      'GESTION_ITOC' GESTION,
                      'INGRESAR NOVEDAD ONYX' AS ACCION,
                      'ONYX' AS SISTEMA_SUSPENSION,
                      'FRAUD VIEW' SISTEMA_ORIGEN,
                      TO_CHAR(TO_DATE(R.FECHA_ALARMA || ' 09:00:00',
                                      'DD/MM/YYYY HH:MI:SS'),
                              'YYYYMMDD HH24') FECHA_ALARMA
        FROM ALARMAS_FV            R,
             SUSCRIPTORES          P,
             SUSCRIPTORES_TMX_HFC  T,
             NUMERACION_TELMEX_HFC N
       WHERE R.TELEFONO NOT IN
             (SELECT M.NUMERO FROM FRAUDE.MAESTRA_BLANCOS M)
         AND T.TELEFONO(+) = R.TELEFONO
         AND P.TELEFONO8(+) = R.TELEFONO
         AND T.CUENTA || P.CODIGO_CLIENTE IS NULL
         AND R.TELEFONO BETWEEN N.DESDE AND N.HASTA
       ORDER BY 13, 14, 15, 1;
  
  END PR_TERCER_PAIS_FRAUDVIEW;

  PROCEDURE PR_REORI_REVENTA_EMPRESAS(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_REORI_REVENTA_EMPRESAS
    **
    ** DESCRIPTION:    CONSULTA LOS FRAUDES DE REORIGINAMIENTO DE LLAMADAS DE EMPRESAS
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 19-NOV-09      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LOS FRAUDES DE REORIGINAMIENTO DE LLAMADAS DE EMPRESAS
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
      SELECT T.CALLER_NUMBER TELEFONO,
             W.NOMBRE_CLIENTE,
             S.NOMBRE,
             TO_CHAR(T.START_DATE, 'YYYYMMDD') FECHA,
             T.TIPO_TRAFICO TRAFICO,
             T.DESTINO,
             J.TIPO_ALARMA,
             COUNT(1) LLAMADAS,
             COUNT(DISTINCT T.CALLED_NUMBER) NUMEROS_DISTINTOS,
             ROUND(SUM(T.DURATION / 60), 0) MINUTOS,
             TO_CHAR(MIN(T.START_DATE), 'HH24MI') HORA_MIN,
             TO_CHAR(MAX(T.START_DATE), 'HH24MI') HORA_MAX,
             'GESTION_FRAUDE' GESTION,
             CASE
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR T.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SUSPENDER EN SS'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND T.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'INGRESAR NOVEDAD ONYX'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'NOVEDAD ONYX-SIP CENTRALIZADO'
                END AS ACCION,
                CASE
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR T.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SOFTSWITCH'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND T.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'ONYX'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'ONYX'
                END AS SISTEMA_SUSPENSION,
             'FRAUDE' SISTEMA_ORIGEN,
             TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
        FROM FRAUDE.CDR_HUAWEI_IP_TMP T,
             FRAUDE.SUSCRIPTORES_TMX_HFC S,
             FRAUDE.SUSCRIPTORES W,
             FRAUDE.MEJORES_ALARMAS J,
             (SELECT DISTINCT CALLER_NUMBER
                 FROM (SELECT M.CALLER_NUMBER,
                              M.TIPO_TRAFICO,
                              COUNT(DISTINCT DESTINO) DESTINOS,
                              COUNT(1) LLAMADAS,
                              ROUND(SUM(M.DURATION / 60), 0) MINUTOS,
                              COUNT(DISTINCT M.CALLED_NUMBER) NUMEROS_DISTINTOS
                         FROM FRAUDE.CDR_HUAWEI_IP_TMP M
                        WHERE TO_CHAR(M.START_DATE, 'YYYYMMDD HH24') >=
                              TO_CHAR(SYSDATE - (1 / 24) * 8, 'YYYYMMDD HH24')
                          AND M.TIPO_TRAFICO NOT IN
                              ('LOCAL+LE', 'CORPORATIVA')
                        GROUP BY M.CALLER_NUMBER, M.TIPO_TRAFICO)
               
                WHERE
               --DETECTAR REVENTA (MUCHOS DESTINOS SIN IMPORTAR DURACION NI TIPO DE TRAFICO O NUMEROS DISTINTOS)
                (DESTINOS > 5)
             OR
               --REVENTA O ALTO CONSUMOS MOVILES (MAS DE 5 LLAMADAS CON APROMEDIO DE LLAMADA MAYOR A 5 MINS)
                (TIPO_TRAFICO = 'MOVILES' AND LLAMADAS >= 10 AND
                (NUMEROS_DISTINTOS / LLAMADAS >= 0.66) /*AND NUMEROS_DISTINTOS >4* AND (MINUTOS/LLAMADAS) > 5*/
                )
             OR
               --REFILE O ALTO CONSUMO LDI
                (TIPO_TRAFICO IN ('LDI-POR-TELMEX', 'LDI-TERCEROS') AND
                LLAMADAS >= 4 AND (NUMEROS_DISTINTOS / LLAMADAS) >= 0.66 /*AND (MINUTOS/LLAMADAS)>3*/
                )
             OR
               --ALTO CONSUMO LDN
                (TIPO_TRAFICO IN ('LDN-POR-TELMEX', 'LDN-TERCEROS') AND
                LLAMADAS >= 5 AND (NUMEROS_DISTINTOS / LLAMADAS) >= 0.66 /*AND (MINUTOS/LLAMADAS)>4*/
                )
             OR
               --LLAMADAS DE LARGA DURACION
                (LLAMADAS <= 2 AND MINUTOS > 100)
               ) N
       WHERE T.TIPO_TRAFICO NOT IN ('LOCAL+LE', 'CORPORATIVA')
         AND TO_CHAR(T.START_DATE, 'YYYYMMDD HH24') >=
             TO_CHAR(SYSDATE - (1 / 24) * 8, 'YYYYMMDD HH24')
         AND T.CALLER_NUMBER = N.CALLER_NUMBER
         AND T.CALLER_NUMBER = S.TELEFONO(+)
         AND T.CALLER_NUMBER = W.TELEFONO8(+)
         AND T.CALLER_NUMBER = J.ABONADO_A(+)
       GROUP BY T.CALLER_NUMBER,
                W.NOMBRE_CLIENTE,
                S.NOMBRE,
                TO_CHAR(T.START_DATE, 'YYYYMMDD'),
                T.TIPO_TRAFICO,
                T.DESTINO,
                J.TIPO_ALARMA,
                CASE
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR T.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SUSPENDER EN SS'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND T.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'INGRESAR NOVEDAD ONYX'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'NOVEDAD ONYX-SIP CENTRALIZADO'
                END,
                CASE
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER BETWEEN '1000' AND
                       '1999' OR T.INCOMING_TRUNK_GROUP_NUMBER = '65535' THEN
                   'SOFTSWITCH'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND T.INCOMING_TRUNK_GROUP_NUMBER not in ('65535','5551','5552') THEN
                   'ONYX'
                  WHEN T.INCOMING_TRUNK_GROUP_NUMBER NOT BETWEEN '1000' AND
                       '2000' AND T.INCOMING_TRUNK_GROUP_NUMBER in ('5551','5552') THEN
                   'ONYX'
                END
       ORDER BY 13, 14, 15, 1;
  
  END PR_REORI_REVENTA_EMPRESAS;

  PROCEDURE PR_REORI_REVENTA_HOGARES(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_REORI_REVENTA_HOGARES
    **
    ** DESCRIPTION:    CONSULTA LOS FRAUDES DE REORIGINAMIENTO DE LLAMADAS DE HOGARES
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 19-NOV-09      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LOS FRAUDES DE REORIGINAMIENTO DE LLAMADAS DE HOGARES
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
      SELECT T.ABON_ORIGEN TELEFONO,
             S.NOMBRE CLIENTE,
             S.CUENTA CUENTA,
             '/20' || SUBSTR(T.START_DATE, 3, 2) ||
             SUBSTR(T.START_DATE, 5, 2) || SUBSTR(T.START_DATE, 7, 2) FECHA,
             T.TIPO_TRAFICO TRAFICO,
             T.DESTINO,
             '' TIPO_ALARMA, /*J.TIPO_ALARMA,*/
             COUNT(1) LLAMADAS,
             COUNT(DISTINCT T.ABON_DESTINO) NUMEROS_DISTINTOS,
             ROUND(SUM(T.DURATION / 60), 0) MINUTOS,
             MIN(SUBSTR(T.START_TIME, 1, 4)) HORA_MIN,
             MAX(SUBSTR(T.START_TIME, 1, 4)) HORA_MAX,
             'GESTION_FRAUDE' GESTION,
             'SUSPENDER EN RR' ACCION,
             'RR' SISTEMA_SUSPENSION,
             'FRAUDE' SISTEMA_ORIGEN,
             TO_CHAR(SYSDATE, 'YYYYMMDD HH24') FECHA_ALARMA
        FROM FRAUDE.CDR_TMX_HFC T,
             FRAUDE.SUSCRIPTORES_TMX_HFC S,
             (SELECT DISTINCT ABON_ORIGEN
                 FROM (SELECT M.ABON_ORIGEN,
                              M.TIPO_TRAFICO,
                              COUNT(DISTINCT DESTINO) DESTINOS,
                              COUNT(1) LLAMADAS,
                              SUM(M.DURATION / 60) MINUTOS,
                              COUNT(DISTINCT M.ABON_DESTINO) NUMEROS_DISTINTOS
                         FROM FRAUDE.CDR_TMX_HFC M
                        WHERE M.START_DATE >=
                              TO_CHAR(SYSDATE - (1 / 24) * 8, 'YYYYMMDD')
                          AND M.START_TIME >=
                              TO_CHAR(SYSDATE - (1 / 24) * 8, 'HH24') ||
                              '0000'
                          AND M.TIPO_TRAFICO IN
                              ('LDI-POR-TELMEX', 'LDI-TERCEROS',
                               'LDN-POR-TELMEX', 'LDN-TERCEROS', 'MOVILES')
                        GROUP BY M.ABON_ORIGEN, M.TIPO_TRAFICO)
                WHERE
               --DETECTAR REVENTA (MUCHOS DESTINOS SIN IMPORTAR DURACION NI TIPO DE TRAFICO O NUMEROS DISTINTOS)
                (DESTINOS > 5)
             OR
               --REVENTA O ALTO CONSUMOS MOVILES (MAS DE 8 LLAMADAS CON DISPERSION DE DESTINOS MAYOR A 66%)
                (TIPO_TRAFICO = 'MOVILES' AND LLAMADAS >= 8 AND
                NUMEROS_DISTINTOS / LLAMADAS >= 0.66 /*AND (MINUTOS/LLAMADAS) > 4*/
                )
             OR
               --REFILE O ALTO CONSUMO LDI
                (TIPO_TRAFICO IN ('LDI-POR-TELMEX', 'LDI-TERCEROS') AND
                LLAMADAS >= 4 AND (NUMEROS_DISTINTOS / LLAMADAS) >= 0.66 /*AND (MINUTOS/LLAMADAS)>3*/
                )
             OR
               --ALTO CONSUMO LDN
                (TIPO_TRAFICO IN ('LDN-POR-TELMEX', 'LDN-TERCEROS') AND
                LLAMADAS >= 5 AND (NUMEROS_DISTINTOS / LLAMADAS) >= 0.66 AND
                (MINUTOS / LLAMADAS) > 3)
             OR
               --LLAMADAS DE LARGA DURACION
                (LLAMADAS <= 2 AND MINUTOS > 100)
               ) N
       WHERE T.TIPO_TRAFICO IN
             ('LDI-POR-TELMEX', 'LDI-TERCEROS', 'LDN-POR-TELMEX',
              'LDN-TERCEROS', 'MOVILES')
         AND T.START_DATE >= TO_CHAR(SYSDATE - (1 / 24) * 8, 'YYYYMMDD')
         AND T.START_TIME >=
             TO_CHAR(SYSDATE - (1 / 24) * 8, 'HH24') || '0000'
         AND T.ABON_ORIGEN = N.ABON_ORIGEN
         AND T.ABON_ORIGEN = S.TELEFONO(+)
       GROUP BY T.ABON_ORIGEN,
                S.NOMBRE,
                S. CUENTA,
                '/20' || SUBSTR(T.START_DATE, 3, 2) ||
                SUBSTR(T.START_DATE, 5, 2) || SUBSTR(T.START_DATE, 7, 2),
                T.TIPO_TRAFICO,
                T.DESTINO
       ORDER BY 13, 14, 15, 1;
  
  END PR_REORI_REVENTA_HOGARES;

  PROCEDURE PR_MEJORES_ALARMAS_EMPRESAS(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_MEJORES_ALARMAS_EMPRESAS
    **
    ** DESCRIPTION:    CONSULTA LAS MEJORES ALARMAS DE EMPRESAS
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 13-ENE-10      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LAS MEJORES ALARMAS DE EMPRESAS
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
      SELECT CODIGO_CLIENTE,
             ENLACE,
             ABONADO_A,
             ACUM_DURA_REAL,
             ACUM_DURA_LIQUI,
             ACUM_CANT_LLAM,
             AVG_AB_B_DIF,
             PROM_MIN_DIARIO,
             PROM_VALOR_DIARIO,
             PROM_LLAM_DIARIA,
             TIPO_TRAFICO,
             ACUM_DIAS,
             OPERADOR,
             OPERADOR_NUESTRO,
             NOMBRE_CLIENTE,
             NTDIDE,
             TIPDIDE,
             FECHA_ASIGNACION,
             DIRECCION,
             SEGMENTO,
             PROMEDIO_FACTURACION,
             SALDO_ACTUAL,
             DES_SUBCATEGORIA,
             DESC_CATEGORIA,
             FV,
             POBLACION,
             DEPTO,
             FECHA_MIN_CONS,
             FECHA_MAX_CONS,
             TO_CHAR(FEC_GEN_ALARMA, 'YYYYMMDD HH24') FEC_GEN_ALARMA,
             IP,
             DESTINOS_DIF,
             PROM_MIN_DIARIO_HISTORICO,
             PROM_LLAM_DIARIA_HISTORICO,
             PORC_DESV_LLAM_RESP_HISTORICO,
             PORC_DESV_MIN_RESP_HISTORICO,
             MESES_DE_INSTALADO,
             MESES_DE_CONSUMO,
             PLAN_FACTURACION,
             LLAMADAS_HORA_LABORAL,
             LLAMADAS_HORA_NO_LABORAL,
             DISPERSION_ABONADOS,
             DISPERSION_CIUDADES,
             PORC_LLAMADAS_HORA_LABORAL,
             DURACION_PROMEDIO,
             TIPO_ALARMA,
             'GESTION_FRAUDE' GESTION,
             CASE
               WHEN OPERADOR_NUESTRO = 'SI' THEN
                'INGRESAR NOVEDAD ONYX'
               ELSE
                'SUSPENDER EN SS'
             END AS ACCION,
             CASE
               WHEN OPERADOR_NUESTRO = 'SI' THEN
                'ONYX'
               ELSE
                'SOFTSWITCH'
             END AS SISTEMA_SUSPENSION,
             'FRAUDE' SISTEMA_ORIGEN
        FROM MEJORES_ALARMAS;
  
  END PR_MEJORES_ALARMAS_EMPRESAS;

  PROCEDURE PR_MEJORES_ALARMAS_HOGARES(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_MEJORES_ALARMAS_HOGARES
    **
    ** DESCRIPTION:    CONSULTA LAS MEJORES ALARMAS DE HOGARES
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 13-ENE-10      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LAS MEJORES ALARMAS DE HOGARES
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
    -- CORPORATIVO
      SELECT CODIGO_CLIENTE,
             ENLACE,
             ABONADO_A,
             ACUM_DURA_REAL,
             ACUM_DURA_LIQUI,
             ACUM_CANT_LLAM,
             AVG_AB_B_DIF,
             PROM_MIN_DIARIO,
             PROM_VALOR_DIARIO,
             PROM_LLAM_DIARIA,
             TIPO_TRAFICO,
             ACUM_DIAS,
             OPERADOR,
             OPERADOR_NUESTRO,
             NOMBRE_CLIENTE,
             NTDIDE,
             TIPDIDE,
             FECHA_ASIGNACION,
             DIRECCION,
             SEGMENTO,
             PROMEDIO_FACTURACION,
             SALDO_ACTUAL,
             DES_SUBCATEGORIA,
             DESC_CATEGORIA,
             FV,
             POBLACION,
             DEPTO,
             FECHA_MIN_CONS,
             FECHA_MAX_CONS,
             TO_CHAR(FEC_GEN_ALARMA, 'YYYYMMDD HH24') FEC_GEN_ALARMA,
             IP,
             DESTINOS_DIF,
             PROM_MIN_DIARIO_HISTORICO,
             PROM_LLAM_DIARIA_HISTORICO,
             PORC_DESV_LLAM_RESP_HISTORICO,
             PORC_DESV_MIN_RESP_HISTORICO,
             MESES_DE_INSTALADO,
             MESES_DE_CONSUMO,
             PLAN_FACTURACION,
             LLAMADAS_HORA_LABORAL,
             LLAMADAS_HORA_NO_LABORAL,
             DISPERSION_ABONADOS,
             DISPERSION_CIUDADES,
             PORC_LLAMADAS_HORA_LABORAL,
             DURACION_PROMEDIO,
             TIPO_ALARMA,
             'GESTION_FRAUDE' GESTION,
             'SUSPENDER EN RR' ACCION,
             'RR' SISTEMA_SUSPENSION,
             'FRAUDE' SISTEMA_ORIGEN
        FROM MEJORES_ALARMAS_TMXH;
  
  END PR_MEJORES_ALARMAS_HOGARES;

  PROCEDURE PR_MALLA_FRAUDE_HOGARES(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_MALLA_FRAUDE_HOGARES
    **
    ** DESCRIPTION:    CONSULTA LAS ALARMAS DETERMINADAS POR LA MALLA DE FRAUDES
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 21-ENE-10      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA LAS MEJORES ALARMAS DE HOGARES
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
    -- CORPORATIVO
      SELECT TELEFONO,
             CUENTA,
             NOMBRE,
             DIRECCION,
             TEL_CASA,
             TEL_OFICINA,
             TERCER_TELEFONO,
             TIPO_DOC,
             CC_NIT,
             FECHA_DIGITACION,
             CIUDAD,
             SALDO_ACTUAL,
             RENTA_MENSUAL,
             CODIGO_VENDEDOR,
             DIAS_MORA,
             FECHA_ULTIMO_PAGO,
             VR_ULTIMO_PAGO,
             FRAUDE,
             DESTINO_COMUN,
             OBSERVACION_DESTINO,
             OT_NUEVA,
             GESTION,
             ACCION,
             SISTEMA_SUSPENSION,
             SISTEMA_ORIGEN,
             FECHA_ALARMA,
             FECHA_LLAMADA
        FROM MALLAS_FRAUDE;
  
  END PR_MALLA_FRAUDE_HOGARES;

  PROCEDURE PR_LOG_EMPRESAS(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_LOG_EMPRESAS
    **
    ** DESCRIPTION:    CONSULTA EL LOG DE CARGA DE ARCHIVOS DE EMPRESAS
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 25-NOV-09      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA EL LOG DE CARGA DE ARCHIVOS DE EMPRESAS
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
      SELECT T.NOMBRE_ARCHIVO, T.FECHA_CARGUE, 'CDR EMPRESAS' FUENTE
        FROM ARCHIVOS_CARGADOS_SS T;
  
  END PR_LOG_EMPRESAS;

  PROCEDURE PR_LOG_HOGARES(RESULTSET OUT T_CURSOR) AS
    /**************************************************************************************************
    ** OBJECTNAME:     PR_LOG_HOGARES
    **
    ** DESCRIPTION:    CONSULTA EL LOG DE CARGA DE ARCHIVOS DE HOGARES
    **
    ** PARAMETERS:
    **     INPUT                                      OUTPUT
    ** ----------------------------------------      ---------------------------------------------------
    **
    ** RETURN VALUES:
    **
    ** REVISION HISTORY:
    ** -----------------------------------------------------------------------------------------------------------------------------------
    **  DATE  NAME    DESCRIPTION      VERSION
    ** -----------------------------------------------------------------------------------------------------------------------------------
    ** 25-NOV-09      GUSTAVO GOMEZ  CREACION                     1.0
    **
    ***************************************************************************************************/
  BEGIN
    -------------------------------------------------------------------
    -- CONSULTA EL LOG DE CARGA DE ARCHIVOS DE HOGARES
    -------------------------------------------------------------------
    OPEN RESULTSET FOR
      SELECT S.NOMBRE_ARCHIVO, S.FECHA_CARGUE, 'CDR RESIDENCIAL' FUENTE
        FROM FILES_LOAD S
       WHERE S.NOMBRE_ARCHIVO NOT IN
             ('BACKUP', 'BAD', 'CDR_PYMES', 'EMBRATEL', 'JOBS', 'LOGS',
              'MEDIADOR', 'EMBRATEL_CORPORATIVO');
  
  END PR_LOG_HOGARES;

END PK_CONSULTA_FRAUDE;
/

