create view GENERA_ARCHIVO_CAMBIO_SIM as
select "SENTENCIA" from (
select
'SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING on
SET LINESIZE 6000
spool d:\CAMBIO_SIM\'||m.archivo||'.csv'||chr(59)||'
prompt CODDISTRI,CUSTCODE,NIT,CYG,NOMBRE,TRAMITA, DISTRIBUIDOR, FECHA_TRAMITE, MIN, CODIGO_USUARIO
Select CODDISTRI||'||chr(39)||','||chr(39)||'||
CUSTCODE||'||chr(39)||','||chr(39)||'||
NIT||'||chr(39)||','||chr(39)||'||
CYG||'||chr(39)||','||chr(39)||'||
NOMBRE||'||chr(39)||','||chr(39)||'||
TRAMITA||'||chr(39)||','||chr(39)||'||
DISTRIBUIDOR||'||chr(39)||','||chr(39)||'||
FECHA_TRAMITE||'||chr(39)||','||chr(39)||'||
MIN||'||chr(39)||','||chr(39)||'||
CODIGO_USUARIO
from CAMBIOS_SIM C
where TRIM(c.DISTRIBUIDOR) LIKE '||chr(39)||trim(M.DISTRIBUIDOR)||chr(37)||chr(39)||'
and c.fecha_reporte = to_char(sysdate-0,'||chr(39)||'YYYYMMDD'||chr(39)||')'||chr(59)||'
SPOOL OFF'||chr(59) as sentencia
from mail_DISTRIBUIDORES m
ORDER BY DISTRIBUIDOR asc
)
/

