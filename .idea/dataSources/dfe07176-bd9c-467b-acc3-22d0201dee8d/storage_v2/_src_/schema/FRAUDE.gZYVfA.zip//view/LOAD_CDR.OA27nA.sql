create view LOAD_CDR as
select "SENTENCIA" from (
select
'sqlldr  fraude/fraude@prufac control=d:\FRAUDE_TMX_COL\jobs\load_CDR.ctl data=d:\FRAUDE_TMX_COL\'||t.nombre_archivo||' bad=d:\FRAUDE_TMX_COL\bad\'||t.nombre_archivo||'.bad log=d:\FRAUDE_TMX_COL\logs\'||t.nombre_archivo||'.log errors=10000' 
as sentencia
from name_file t where t.flag_cargue = 'S'
)
/

