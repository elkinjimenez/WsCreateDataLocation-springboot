create view V_BAJAR_ALARMAS_FV as
select "SENTENCIA" from (
select
'get '||t.nombre_archivo||a.flag_cargue||'
' as sentencia
from nombres_arch_fv t, ARCHIVOS_CARGADOS_fv A
WHERE T.NOMBRE_ARCHIVO = A.NOMBRE_ARCHIVO(+)
AND A.FECHA_CARGUE IS NULL
ORDER BY t.nombre_archivo asc
)
/

