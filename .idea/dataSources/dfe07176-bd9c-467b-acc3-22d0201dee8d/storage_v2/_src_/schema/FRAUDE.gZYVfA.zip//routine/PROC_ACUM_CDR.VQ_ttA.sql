create PROCEDURE proc_acum_cdr
IS
-- falta agregar validacion para que no acumule periodos ya acumulados
CURSOR c_tmp_cdr IS
SELECT 	trim(t.Caller_number) as ABONADO_A,
 	to_char(t.start_date,'YYMMDD') as FECHA_INICIO,
 	ROUND(sum(TO_NUMBER(t.duration/60))) AS D_REAL,
 	ROUND(sum(TO_NUMBER(ceil(t.duration/60)))) AS D_LIQUI,
 	tipo_trafico, -- 
  COUNT(*) AS CANT_LLAMADAS, 
  count(distinct t.called_number) AS dif_ab_b,
  COUNT(DISTINCT T.DESTINO) AS DEST_DIF,
  '0' as valor,
  min(t.start_date) as fecha_min,
  max(t.end_date) as fecha_max
FROM tmp_CDR_HUAWEI t-- ****  OJOOO ****
where T.CALLED_NUMBER NOT LIKE '0194%'
       and T.CALLER_NUMBER NOT  IN (SELECT M.NUMERO FROM MAESTRA_BLANCOS M)
       AND tipo_trafico not in ('CORPORATIVA', '11')
--       and t.id_huawei_ip >= 152546749 --- Insertado para la carga inicial de los meses de MArzo a Mayo 15
group by Caller_number ,
 	to_char(t.start_date,'YYMMDD'),
	tipo_trafico -- ?????
order by Caller_number ,
       	 to_char(t.start_date,'YYMMDD'),
         tipo_trafico;-- ??????????????
         
CONTADOR NUMBER;
cnt_loop number;
CONTADOR_DIA NUMBER;
fecha_min date;
fecha_max date;


BEGIN
CONTADOR:=0;
CONTADOR_DIA:=0;
--CONTADOR_DIA_k:=0;
cnt_loop:=0;

-- INICIAMOS EL PROCESO DE ACUMULACION  
FOR v_tmp_cdr IN c_tmp_cdr
  LOOP
      cnt_loop:=Cnt_loop+1;
	-- SE INSERTA EN LA TABLA QUE ACUMULA POR DIA
	SELECT COUNT(*)
  INTO CONTADOR_DIA
  FROM cdr_ACUM_DIA
  WHERE ABONADO_a=V_TMP_cdr.ABONADO_A 
  AND tipo_trafico=V_TMP_cdr.tipo_trafico
  AND FECHA=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD');
  
  IF CONTADOR_DIA > 0 then
     UPDATE cdr_ACUM_DIA
     SET 	ACUM_DURA_REAL=ACUM_DURA_REAL+V_TMP_cdr.D_REAL,
			ACUM_DURA_LIQUI=ACUM_DURA_LIQUI+V_TMP_cdr.D_LIQUI,
			ACUM_CANT_LLAM=ACUM_CANT_LLAM+V_TMP_cdr.CANT_LLAMADAS,
			AVG_ab_b_dif=AVG_ab_b_dif+V_TMP_cdr.dif_ab_b,
			Destinos_Dif=Destinos_Dif+V_TMP_cdr.Dest_Dif,
      acum_valor=acum_valor+v_tmp_cdr.valor
 		WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico
            AND FECHA=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD');
	ELSE
  
      INSERT INTO cdr_ACUM_DIA (
      ABONADO_a,
      FECHA, 
      ACUM_DURA_REAL, 
      ACUM_DURA_LIQUI,
      tipo_trafico, 
      ACUM_CANT_LLAM, 
      AVG_ab_b_dif, 
      acum_valor,
      Destinos_Dif)
    	VALUES (
      V_TMP_cdr.ABONADO_A, 
      TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD'), 
      V_TMP_cdr.D_REAL, 
      V_TMP_cdr.D_LIQUI,
    	V_TMP_cdr.tipo_trafico, 
      V_TMP_cdr.CANT_LLAMADAS, 
      V_TMP_cdr.Dif_Ab_b, 
      v_tmp_cdr.valor,V_TMP_CDR.DEST_DIF);
  END IF;
    
  -- SE ACTUALIZA LA TABLA DE cdr_ACUM_TOTAL
	-- primero revisamos si el abonado no ha sido insertado de lo contrario es necesario hacerlo.
	SELECT COUNT(*)
	INTO CONTADOR
	FROM cdr_ACUM_TOTAL
	WHERE ABONADO_a=V_TMP_cdr.ABONADO_A AND tipo_trafico=V_TMP_cdr.tipo_trafico;


	IF CONTADOR>0 THEN
  
  	UPDATE 	cdr_ACUM_TOTAL
		SET acum_dias = acum_dias - 1
    WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico
            and fecha_max= TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD');
    
		UPDATE 	cdr_ACUM_TOTAL
		SET 	ACUM_DURA_REAL=ACUM_DURA_REAL+V_TMP_cdr.D_REAL,
			ACUM_DURA_LIQUI=ACUM_DURA_LIQUI+V_TMP_cdr.D_LIQUI,
			ACUM_CANT_LLAM=ACUM_CANT_LLAM+V_TMP_cdr.CANT_LLAMADAS,
			AVG_ab_b_dif=AVG_ab_b_dif+V_TMP_cdr.dif_ab_b,
      Destinos_Dif=Destinos_Dif+V_TMP_cdr.Dest_Dif,
      acum_valor=acum_valor+v_tmp_cdr.valor,
      fecha_max=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD')
		WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico;
            
    
    UPDATE 	cdr_ACUM_TOTAL
		SET acum_dias = acum_dias + 1
    WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico;
        
            
	ELSE
		INSERT INTO cdr_ACUM_TOTAL (
    ABONADO_a ,
    ACUM_DURA_REAL, 
    ACUM_DURA_LIQUI, 
    ACUM_CANT_LLAM , 
    tipo_trafico ,
    AVG_ab_b_dif, 
    ACUM_DIAS, 
    acum_valor ,
    Fecha_Min,
    DESTINOS_DIF
    )
		VALUES(
    V_TMP_cdr.ABONADO_A, 
    V_TMP_cdr.D_REAL,
    V_TMP_cdr.D_LIQUI,
    V_TMP_cdr.CANT_LLAMADAS, 
    V_TMP_cdr.tipo_trafico, 
    V_TMP_cdr.Dif_Ab_b,
    1, 
    v_tmp_cdr.valor,
    TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD'),
    v_tmp_cdr.DEST_DIF
    );
	END IF  ;
      IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
     
  -- SE ACTUALIZA LA TABLA DE cdr_HISTORICO
	-- primero revisamos si el abonado no ha sido insertado de lo contrario es necesario hacerlo.
	SELECT COUNT(*)
	INTO CONTADOR
	FROM cdr_HISTORICO
	WHERE ABONADO_a=V_TMP_cdr.ABONADO_A AND tipo_trafico=V_TMP_cdr.tipo_trafico;
  
  
	IF CONTADOR>0 THEN
  
    UPDATE 	cdr_historico
		SET acum_dias = acum_dias - 1
    WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico
            and fecha_max= TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD');
  
		UPDATE 	cdr_HISTORICO
		SET 	ACUM_DURA_REAL=ACUM_DURA_REAL+V_TMP_cdr.D_REAL,
			ACUM_DURA_LIQUI=ACUM_DURA_LIQUI+V_TMP_cdr.D_LIQUI,
			ACUM_CANT_LLAM=ACUM_CANT_LLAM+V_TMP_cdr.CANT_LLAMADAS,
			AVG_ab_b_dif=AVG_ab_b_dif+V_TMP_cdr.dif_ab_b,
      Destinos_Dif=Destinos_Dif+V_TMP_cdr.Dest_Dif,
      acum_valor=acum_valor+v_tmp_cdr.valor,
      fecha_max=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD')
		WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico;
    
    UPDATE 	cdr_historico
		SET acum_dias = acum_dias + 1
    WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico;
            
            
	ELSE
		INSERT INTO cdr_HISTORICO (
    ABONADO_a ,
    ACUM_DURA_REAL, 
    ACUM_DURA_LIQUI, 
    ACUM_CANT_LLAM , 
    tipo_trafico ,
    AVG_ab_b_dif, 
    ACUM_DIAS, 
    acum_valor ,
    Fecha_Min,
    DESTINOS_DIF
    )
		VALUES(V_TMP_cdr.ABONADO_A, 
    V_TMP_cdr.D_REAL,
    V_TMP_cdr.D_LIQUI,
    V_TMP_cdr.CANT_LLAMADAS, 
    V_TMP_cdr.tipo_trafico, 
    V_TMP_cdr.Dif_Ab_b,
    1,
    v_tmp_cdr.valor,
    TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD'),
    v_tmp_cdr.DEST_DIF
    );
	END IF  ;
  
    update cdr_ACUM_TOTAL
    set fecha_max = fecha_min
    where fecha_max is null;
  
    update cdr_historico
    set fecha_max = fecha_min
    where fecha_max is null;

  
      IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;    
    
    
  END LOOP;

  /*depura la tabla tmp_cdr*/
--   END LOOP;
  
  --delete from tmp_cdr;
  delete from cdr_ACUM_DIA;
  COMMIT;
  
END;
/

