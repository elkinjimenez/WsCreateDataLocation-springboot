create PACKAGE info_cliente_tmk IS

   -- Author  : ICM0613A
   -- Created : 12/05/2020 2:26:12 p. m.
   -- Purpose : Tener los procedimiento almacenados para realizar busquedas por numero de documento de cliente para ventas no presenciales

   PROCEDURE buscar_documento(p_cur_resultado OUT SYS_REFCURSOR,
                              p_nm_resp       OUT NUMBER,
                              p_vc_resp       OUT VARCHAR2);

   PROCEDURE insertarinfo(p_vc_num_cel         IN VARCHAR2,
                          p_vc_co_id           IN VARCHAR2,
                          p_vc_numero_doc      IN VARCHAR2,
                          p_vc_nombre          IN VARCHAR2,
                          p_vc_tel_contacto    IN VARCHAR2,
                          p_vc_direccion       IN VARCHAR2,
                          p_vc_ciudad          IN VARCHAR2,
                          p_vc_custcode        IN VARCHAR2,
                          p_vc_cod_plan        IN VARCHAR2,
                          p_vc_tipo_linea      IN VARCHAR2,
                          p_vc_fecha_act       IN VARCHAR2,
                          p_vc_saldo           IN VARCHAR2,
                          p_vc_fecha_mod_saldo IN VARCHAR2,
                          p_nm_resp            OUT NUMBER,
                          p_vc_resp            OUT VARCHAR2);
END info_cliente_tmk;
/

