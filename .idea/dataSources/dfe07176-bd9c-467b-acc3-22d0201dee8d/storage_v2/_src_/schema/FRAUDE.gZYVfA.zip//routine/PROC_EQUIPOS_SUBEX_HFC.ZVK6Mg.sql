create PROCEDURE proc_equipos_subex_hfc
IS
CURSOR c_tmp_datos IS
select distinct i.cuenta, trim(i.tipo) tipo_equipo, trim(i.mac) mac, trim(i.direccion_mac) direccion_mac
  from inventarios i
  where i.cuenta not in
(
'81804676',
'86344470',
'77608628',
'78617560',
'27277227',
'82929977',
'90395948',
'78085172',
'468744',
'70964069',
'35819523',
'91755108',
'91470872',
'4526851',
'25480591',
'35400928',
'81136285',
'91252254',
'5806211',
'78600327',
'81583205',
'32669244',
'75347260',
'83829572',
'86362977',
'80176803',
'36622660',
'78698479',
'18313049',
'82526369',
'29713435',
'10390516',
'18709790',
'12830071',
'84353366',
'86297454',
'88965959',
'88945993',
'87946653',
'82537432',
'94177730',
'79321204',
'18001032',
'80363237',
'72844210',
'4240800',
'47985700',
'53471439',
'45361664',
'64895808',
'78085859',
'72598733',
'87337101',
'42566000',
'55587109',
'92395516',
'85032092',
'41437377',
'53366308',
'88844477',
'25561945',
'43049881',
'34171769',
'89644827',
'85556223',
'4574927',
'91114983',
'91758250',
'48273502',
'73098535',
'87026589',
'91658641',
'25274002',
'94180270',
'88495262',
'45830494',
'75489880',
'85045839',
'91082156',
'27854694',
'56534506',
'80485527',
'80691801',
'48194880',
'85289569',
'58437013',
'35613439',
'87734349',
'53065504',
'24850257',
'78923893',
'57709529',
'88229000',
'93450161',
'78294105',
'74665423',
'84965490',
'94235108',
'62495387',
'91636555',
'90254483',
'34009381',
'47981501',
'35469972',
'86767233',
'61332326',
'55690432',
'83630517',
'53810156',
'86361755',
'25480583',
'92718022',
'91148460',
'66624230',
'85623676',
'56448228',
'83864835',
'73242752',
'12690400',
'71846844',
'54350665',
'29687910',
'56412265',
'35633338',
'41402827',
'35822501',
'72159858',
'27771013',
'57797656',
'91156141',
'25096629',
'80573363',
'79888764',
'66277807',
'66275215',
'72358039',
'48052179',
'60611050'
)
;



CONTADOR NUMBER;
cnt_loop number;

begin
update suscriptores_subex_hfc s
set s.tipo_equipo = ''
;

commit;

update suscriptores_subex_hfc s
set s.mac = '';
commit;

update suscriptores_subex_hfc s
set s.direccion_mac = '';
commit;



commit;
contador:= 0;
cnt_loop:= 0;



  FOR v_datos_sus IN c_tmp_datos
  LOOP
      cnt_loop:=Cnt_loop+1;
  SELECT COUNT(*)
  INTO CONTADOR
  FROM suscriptores_subex_hfc t
  WHERE t.cuenta = V_datos_sus.cuenta;
  --and t.telefono is null;

  IF CONTADOR >0  then

     UPDATE suscriptores_subex_hfc s
     SET  --tipo_servicios  = trim(tipo_servicios)  ||', '|| v_datos_sus.tipo_servicios,
       --servicios  = trim(servicios)  ||', '|| v_datos_sus.servicios
       tipo_equipo  =  v_datos_sus.tipo_equipo ||','|| trim(tipo_equipo)  ,
       Mac =   v_datos_sus.Mac ||','||  trim(Mac) ,
       direccion_mac = v_datos_sus.direccion_mac ||','||  trim(direccion_mac) 
     where s.cuenta = v_datos_sus.cuenta;


  end if;


 IF cnt_loop=200 THEN
         COMMIT;
         cnt_loop:=0;
      END IF;

  END LOOP;


  commit;


END;
/

