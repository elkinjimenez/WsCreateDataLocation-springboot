create view UNIFICADA_BIOMETRIA_EVIDENTE as
select r.documento, r.fecha, r.respuesta, 'BIOMETRIA' HERRAMIENTA from reportes_biometria r
  union
  select e.no_id_cliente, e.fecha_y_hora, e.resultado, E.PRODUCTO HERRAMIENTA from evidente_confronta e
  union
  select I.NUMERO_IDENTIFICACION, I.FECHA_Y_HORA_DE_CONSULTA, I.RESULTADO_CONFRONTACION, 'IDVISION' HERRAMIENTA from IDVISION I
/

