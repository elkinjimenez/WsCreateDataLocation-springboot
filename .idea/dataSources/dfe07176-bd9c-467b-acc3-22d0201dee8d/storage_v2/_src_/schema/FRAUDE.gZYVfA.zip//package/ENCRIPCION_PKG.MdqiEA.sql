create PACKAGE encripcion_pkg AS
   --**********************************************************************************************************
   --** OBJETIVO             : CONTIENE LAS UTILIDADES DE ENCRIPCION Y DESENCRIPCION
   --** ESQUEMA              : UTIL
   --** NOMBRE               : QB_ENCRIPCION / HEADER
   --** AUTOR                : JAIRO ANDRES RIVERA RODRIGUEZ
   --** FECHA MODIFICACION   : 24/AGOSTO/2011
   --**********************************************************************************************************

   --------------------------------------------------------------------------
   -------------------- FUNCION QUE CODIFICA UN TEXTO------------------------
   --------------------------------------------------------------------------
   FUNCTION fb_encriptar(txt_encrip VARCHAR2) RETURN RAW;

   --------------------------------------------------------------------------
   ------------------- FUNCION QUE DECODIFICA UN TEXTO-----------------------
   --------------------------------------------------------------------------

   FUNCTION fb_descencriptar(txt_desencrip VARCHAR2) RETURN VARCHAR2;

END encripcion_pkg;
/

