create PACKAGE pkg_automatizacion_process
  AS
-----------------------------------------------------------------------------------------------
--GENERADO POR      : TCS
--PROYECTO          : Automatizacion procesos
--FECHA CREACION    : 28 de Mayo de 2018
--DESCRIPCION       : Paquete de Procedimientos para la configuracion del proceso de biometría.
--AUTOR             : Sara Ortiz (sara.ortiz@tcs.com)
-----------------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------------------------
  -- OBJETIVO: Inserción en la tabla TMP_REPORTES_BIOMETRIA
  -- PARÁMETROS DE ENTRADA: VCLIENTE     IN    VARCHAR2,
  --            VSUCURSAL    IN    VARCHAR2,
  --            VNUIPSUCURSAL  IN    VARCHAR2,
  --            VNUT      IN    VARCHAR2,
  --            VFECHA      IN    DATE,
  --            VDOCUMENTO     IN     VARCHAR2,
  --            VRESPUESTA      IN     VARCHAR2,
  --            VUSERCOD    IN    VARCHAR2,
  --            VSUCURSALID    IN    VARCHAR2,
  --            VOPERATIONID  IN    VARCHAR2,
  --            VUSERIP      IN    VARCHAR2,
  --            VUSERMAC    IN    VARCHAR2
  -- PARÁMETROS DE SALIDA:  VCODIGORESULT:  codigo de respuesta
  --            VRESULTADOADOADO:  descripción
  -- OBJETOS QUE LO REFERENCIAN: Claro.Fraudx.DataAccess
  -- FECHA:                28/05/2018
  -- REALIZADO POR:               Sara Ortiz
  -------------------------------------------------------------------------------------------------------
  PROCEDURE SP_INSERT_TMP_BIOMETRIA
  (
      VCLIENTE     IN    VARCHAR2,
        VSUCURSAL    IN    VARCHAR2,
        VNUIPSUCURSAL  IN    VARCHAR2,
        VNUT      IN    VARCHAR2,
        VFECHA      IN    VARCHAR2,
      VDOCUMENTO     IN     VARCHAR2,
        VRESPUESTA      IN     VARCHAR2,
        VUSERCOD    IN    VARCHAR2,
        VSUCURSALID    IN    VARCHAR2,
        VOPERATIONID  IN    VARCHAR2,
        VUSERIP      IN    VARCHAR2,
        VUSERMAC    IN    VARCHAR2,
      VCODIGORESULT  OUT    NUMBER,
      VRESULTADO      OUT   VARCHAR
  );

  --------------------------------------------------------------------------------------------------------
  -- OBJETIVO: Inserción en la tabla REPORTES_BIOMETRIA
  -- PARÁMETROS DE SALIDA:  VCODIGORESULT:  código de respuesta
  --            VRESULTADOADOADO:  descripción
  -- OBJETOS QUE LO REFERENCIAN: Claro.Fraudx.DataAccess
  -- FECHA:                29/05/2018
  -- REALIZADO POR:               Sara Ortiz
  -------------------------------------------------------------------------------------------------------
  PROCEDURE SP_INSERT_REPORTES_BIOMETRIA
  (
    VCODIGORESULT    OUT NUMBER,
    VRESULTADO          OUT VARCHAR2
  );

  ----------------------------------------------------------------------------------------------------------
  -- OBJETIVO: Inserción en la tabla VENTAS_COMCEL_TMP2
  -- PARÁMETROS DE ENTRADA: VCOD_RAZON_ESTADO_ACTIVACION     IN    VARCHAR2,
  --            VCOD_RAZON_ESTADO_DESC         IN     VARCHAR2,
  --            VESTADO_CORRESPONDIENTE        IN     VARCHAR2,
  --            VCOD_AGENTE              IN    VARCHAR2,
  --            VCO_ID                IN    VARCHAR2,
  --            VCUSTOMER_ID            IN    VARCHAR2,
  --            VCUSTCODE              IN    VARCHAR2,
  --            VCUSTCODE_MTR            IN     VARCHAR2,
  --            VESTADO                IN    VARCHAR2,
  --            VCOD_RAZON_ESTADO          IN    VARCHAR2,
  --            VTELE_NUMB              IN    VARCHAR2,
  --            VCOD_PLAN_INICIAL          IN    VARCHAR2,
  --            VCOD_PLAN_ACTUAL          IN     VARCHAR2,
  --            VFECHA_ACTIVACION          IN    DATE,
  --            VFECHA_DESACTIVACION        IN     DATE,
  --            VTIPO_LINEA              IN     VARCHAR2,
  --            VIDENTIFICACION            IN    VARCHAR2,
  --            VTIPO_IDENTIFICACION        IN     VARCHAR2,
  --            VNOMBRE_CLIENTE            IN    VARCHAR2,
  --            VCIUDAD                IN    VARCHAR2,
  --            VTELEFONO1              IN    VARCHAR2,
  --            VTELEFONO2              IN    VARCHAR2,
  --            VMODELO_EQUIPO            IN    VARCHAR2,
  --            VIMEI                IN    VARCHAR2,
  --            VICCID                IN    VARCHAR2,
  --            VCUSTCODE_AGENTE          IN    VARCHAR2,
  --            VNAME_AGENTE            IN    VARCHAR2,
  --            VCIUDAD_AGENTE            IN    VARCHAR2,
  --             VDIRECCION_CLIENTE          IN    VARCHAR2
  -- PARÁMETROS DE SALIDA:  VCODIGORESULT:  codigo de respuesta
  --            VRESULTADOADO:  descripción
  -- OBJETOS QUE LO REFERENCIAN: Claro.Fraudx.DataAccess
  -- FECHA:                29/05/2018
  -- REALIZADO POR:               Sara Ortiz
  -------------------------------------------------------------------------------------------------------
  PROCEDURE SP_INSERT_TMP_VENTAS_MOVIL
  (
      VCOD_RAZON_ESTADO_ACTIVACION     IN    VARCHAR2,
      VCOD_RAZON_ESTADO_DESC        IN    VARCHAR2,
      VESTADO_CORRESPONDIENTE        IN    VARCHAR2,
      VCOD_AGENTE              IN    VARCHAR2,
      VCO_ID                IN    VARCHAR2,
      VCUSTOMER_ID             IN    VARCHAR2,
      VCUSTCODE              IN    VARCHAR2,
      VCUSTCODE_MTR            IN    VARCHAR2,
      VESTADO                IN    VARCHAR2,
      VCOD_RAZON_ESTADO            IN    VARCHAR2,
      VTELE_NUMB              IN    VARCHAR2,
      VCOD_PLAN_INICIAL          IN    VARCHAR2,
      VCOD_PLAN_ACTUAL          IN     VARCHAR2,
        VFECHA_ACTIVACION          IN    VARCHAR2,
        VFECHA_DESACTIVACION        IN     VARCHAR2,
       VTIPO_LINEA              IN     VARCHAR2,
      VIDENTIFICACION            IN    VARCHAR2,
      VTIPO_IDENTIFICACION        IN     VARCHAR2,
      VNOMBRE_CLIENTE            IN    VARCHAR2,
      VCIUDAD                IN    VARCHAR2,
       VTELEFONO1              IN    VARCHAR2,
        VTELEFONO2              IN    VARCHAR2,
      VMODELO_EQUIPO            IN    VARCHAR2,
        VIMEI                IN    VARCHAR2,
       VICCID                IN    VARCHAR2,
       VCUSTCODE_AGENTE          IN    VARCHAR2,
       VNAME_AGENTE            IN    VARCHAR2,
       VCIUDAD_AGENTE            IN    VARCHAR2,
       VDIRECCION_CLIENTE          IN    VARCHAR2,
      VCODIGORESULT              OUT   NUMBER,
      VRESULTADO                  OUT   VARCHAR2
  );

  ------------------------------------------------------------------------------------------------------------
  -- OBJETIVO: Inserción en la tabla REPOS_COMCEL2
  -- PARÁMETROS DE ENTRADA: VCODDISTRI       IN    VARCHAR2,
  --            VMINENTRA      IN    VARCHAR2,
  --            VTIPOSERVICIO     IN     VARCHAR2,
  --            VFECREGIS      IN    VARCHAR2,
  --            VEQUIPO        IN    VARCHAR2,
  --            VVR_EQUIPO      IN    VARCHAR2,
  --            VIVA_EQUIPO      IN    VARCHAR2,
  --            VIMEI_ANTERIOR    IN    VARCHAR2,
  --            VIMEI_NUEVO      IN    VARCHAR2,
  --            VTRAJO_EQUIPO    IN    VARCHAR2,
  --            VTIPO_ACTIVACION  IN    VARCHAR2,
  --            VCUSTCODE      IN    VARCHAR2,
  --            VCOD_USUARIO    IN    VARCHAR2,
  --            VNOMBRE        IN    VARCHAR2,
  --            VDOCUMENTO      IN    VARCHAR2,

  -- PARÁMETROS DE SALIDA:  VCODIGORESULT:  codigo de respuesta
  --            VRESULTADOADO:  descripción
  -- OBJETOS QUE LO REFERENCIAN: Claro.Fraudx.DataAccess
  -- FECHA:                30/05/2018
  -- REALIZADO POR:               Sara Ortiz
  -------------------------------------------------------------------------------------------------------
  PROCEDURE SP_INSERT_REPOS_COMCEL2
  (
      VCODDISTRI       IN    VARCHAR2,
      VMINENTRA      IN    VARCHAR2,
        VTIPOSERVICIO     IN     VARCHAR2,
        VFECREGIS      IN    VARCHAR2,
        VEQUIPO        IN    VARCHAR2,
        VVR_EQUIPO      IN    VARCHAR2,
        VIVA_EQUIPO      IN    VARCHAR2,
      VIMEI_ANTERIOR    IN    VARCHAR2,
        VIMEI_NUEVO      IN    VARCHAR2,
      VTRAJO_EQUIPO    IN    VARCHAR2,
      VTIPO_ACTIVACION  IN    VARCHAR2,
      VCUSTCODE      IN    VARCHAR2,
      VCOD_USUARIO    IN    VARCHAR2,
      VNOMBRE        IN    VARCHAR2,
      VDOCUMENTO      IN    VARCHAR2,
      VCODIGORESULT      OUT   NUMBER,
      VRESULTADO            OUT   VARCHAR2
  );

  ------------------------------------------------------------------------------------------------------------
  -- OBJETIVO: Inserción en la tabla VENTAS_DIGITADAS_FIJA
  -- PARÁMETROS DE ENTRADA: VCVACCT        IN    VARCHAR2,
  --            VCVAOÑ        IN    VARCHAR2,
  --            VCVAUSU        IN    VARCHAR2,
  --            VCVTITL        IN    VARCHAR2,
  --            VCVALNM        IN     VARCHAR2,
  --            VCVAFNM        IN    VARCHAR2
  --            VCVATID        IN    VARCHAR2,
  --            VCVANID        IN    VARCHAR2,
  --            VCVASER        IN    VARCHAR2,
  --            VCVATSE        IN    VARCHAR2,
  --            VCVARSE        IN    VARCHAR2,
  --            VCVACAM        IN    VARCHAR2,
  --            VCVARSC        IN    VARCHAR2,
  --            VCVARME        IN    VARCHAR2,
  --            VTIPO_DE_PRODUCTO  IN    VARCHAR2,
  --            VPRODGENERAL    IN    VARCHAR2,
  --            VPROD_VENTA_DIARIO  IN    VARCHAR2,
  --            VPAQUETE_PG      IN    VARCHAR2,
  --            VPAQUETE_PVD    IN    VARCHAR2,
  --            VCVADLR2      IN    VARCHAR2,
  --            VCVAASE        IN    VARCHAR2,
  --            VCVAYCO        IN    VARCHAR2,
  --            VCVAMCO        IN    VARCHAR2,
  --            VCVADCO        IN    VARCHAR2,
  --            VCVATVT        IN    VARCHAR2,
  --            VCVATYS        IN    VARCHAR2,
  --            VCVANCT        IN    VARCHAR2,
  --            VCVESCT        IN    VARCHAR2,
  --            VCVAD03        IN    VARCHAR2,
  --            VCVAINF1      IN    VARCHAR2,
  --            VCVAINF2      IN    VARCHAR2,
  --            VCVAINF3      IN    VARCHAR2,
  --            VCVAINF4      IN    VARCHAR2,
  --            VCVAGAS        IN    VARCHAR2,
  --            VCVDIVI        IN    VARCHAR2,
  --            VGV_DIVISION    IN    VARCHAR2,
  --            VCVAREA        IN    VARCHAR2,
  --            VGV_AREA      IN    VARCHAR2,
  --            VGV_GERENTE_AREA  IN    VARCHAR2,
  --            VCEDULA_GERENTE    IN    VARCHAR2,
  --            VGV_ID_ZONA      IN    VARCHAR2,
  --            VGV_ZONA      IN    VARCHAR2,
  --            VGV_JEFE_ZONA    IN    VARCHAR2,
  --            VCEDULA_JEFE    IN    VARCHAR2,
  --            VGV_ID_DISTRITO    IN    VARCHAR2,
  --            VGV_DISTRITO      IN    VARCHAR2,
  --            VGV_ESPECIALISTA    IN    VARCHAR2,
  --            VCEDULA_ESPECIALISTA  IN    VARCHAR2,
  --            VGV_SUPERVISOR      IN    VARCHAR2,
  --              VCEDULA_SUPERVISOR    IN    VARCHAR2,
  --            VGV_UND_GESTION      IN    VARCHAR2,
  --            VCOD_MOVIL        IN    VARCHAR2,
  --            VGV_DESCRIPCION      IN    VARCHAR2,
  --            VDESCP_2        IN    VARCHAR2,
  --            VGV_RED          IN    VARCHAR2,
  --            VCANAL          IN    VARCHAR2,
  --            VCANAL2          IN    VARCHAR2,
  --            VCATEGORIA        IN    VARCHAR2,
  --            VCVANOD          IN    VARCHAR2,
  --            VD_TIPO          IN    VARCHAR2,
  --            VCVACCD          IN    VARCHAR2,
  --            VCVACDE          IN    VARCHAR2,
  --            VID_DIVISION      IN    VARCHAR2,
  --            VD_DIVISION        IN    VARCHAR2,
  --            VID_AREA        IN    VARCHAR2,
  --            VD_AREA          IN    VARCHAR2,
  --            VD_ZONA          IN    VARCHAR2,
  --            VD_DISTRITO        IN     VARCHAR2,
  --            VD_UND_GESTION      IN    VARCHAR2,
  --            VCOD_POB        IN    VARCHAR2,
  --            VPOBLACION        IN    VARCHAR2,
  --            VESTRATO        IN    VARCHAR2,
  --            VCVAHOM          IN    VARCHAR2,
  --            VCVATNM          IN    VARCHAR2,
  --            VCVPRBF          IN    VARCHAR2,
  --            VCVCDGE          IN    VARCHAR2,
  --            VHOGARES        IN    VARCHAR2,
  --            VCANTSERV        IN    VARCHAR2,
  --            VVALREG          IN     VARCHAR2,
  --            VCVAAPT          IN    VARCHAR2,
  --            VMULTIPLAY        IN    VARCHAR2,
  --            VTV_ESPECIAL      IN    VARCHAR2,
  --            VNOM_ZONA        IN    VARCHAR2,
  --            VCVAAMV          IN    VARCHAR2
  -- PARÁMETROS DE SALIDA:  VCODIGORESULT:  codigo de respuesta
  --            VRESULTADOADO:  descripción
  -- OBJETOS QUE LO REFERENCIAN: Claro.Fraudx.DataAccess
  -- FECHA:                30/05/2018
  -- REALIZADO POR:               Sara Ortiz
  -------------------------------------------------------------------------------------------------------
  PROCEDURE SP_INSERT_DIGITADAS_FIJA
  (
    VCVACCT        IN    VARCHAR2,
      VCVAOÑ        IN    VARCHAR2,
      VCVAUSU        IN    VARCHAR2,
      VCVTITL        IN    VARCHAR2,
      VCVALNM        IN     VARCHAR2,
    VCVAFNM        IN    VARCHAR2,
    VCVATID        IN    VARCHAR2,
      VCVANID        IN    VARCHAR2,
      VCVASER        IN    VARCHAR2,
      VCVATSE        IN    VARCHAR2,
      VCVARSE        IN    VARCHAR2,
      VCVACAM        IN    VARCHAR2,
      VCVARSC        IN    VARCHAR2,
      VCVARME        IN    VARCHAR2,
      VTIPO_DE_PRODUCTO  IN    VARCHAR2,
      VPRODGENERAL    IN    VARCHAR2,
    VPROD_VENTA_DIARIO  IN    VARCHAR2,
    VPAQUETE_PG      IN    VARCHAR2,
    VPAQUETE_PVD    IN    VARCHAR2,
    VCVADLR2      IN    VARCHAR2,
    VCVAASE        IN    VARCHAR2,
    VCVAYCO        IN    VARCHAR2,
    VCVAMCO        IN    VARCHAR2,
    VCVADCO        IN    VARCHAR2,
    VCVATVT        IN    VARCHAR2,
    VCVATYS        IN    VARCHAR2,
    VCVANCT        IN    VARCHAR2,
    VCVESCT        IN    VARCHAR2,
      VCVAD03        IN    VARCHAR2,
    VCVAINF1      IN    VARCHAR2,
      VCVAINF2      IN    VARCHAR2,
      VCVAINF3      IN    VARCHAR2,
      VCVAINF4      IN    VARCHAR2,
      VCVAGAS        IN    VARCHAR2,
      VCVDIVI        IN    VARCHAR2,
      VGV_DIVISION    IN    VARCHAR2,
      VCVAREA        IN    VARCHAR2,
      VGV_AREA      IN    VARCHAR2,
      VGV_GERENTE_AREA  IN    VARCHAR2,
      VCEDULA_GERENTE    IN    VARCHAR2,
      VGV_ID_ZONA      IN    VARCHAR2,
      VGV_ZONA      IN    VARCHAR2,
      VGV_JEFE_ZONA    IN    VARCHAR2,
      VCEDULA_JEFE    IN    VARCHAR2,
    VGV_ID_DISTRITO    IN    VARCHAR2,
      VGV_DISTRITO      IN    VARCHAR2,
      VGV_ESPECIALISTA    IN    VARCHAR2,
      VCEDULA_ESPECIALISTA  IN    VARCHAR2,
      VGV_SUPERVISOR      IN    VARCHAR2,
      VCEDULA_SUPERVISOR    IN    VARCHAR2,
      VGV_UND_GESTION      IN    VARCHAR2,
      VCOD_MOVIL        IN    VARCHAR2,
      VGV_DESCRIPCION      IN    VARCHAR2,
      VDESCP_2        IN    VARCHAR2,
      VGV_RED          IN    VARCHAR2,
      VCANAL          IN    VARCHAR2,
    VCANAL2          IN    VARCHAR2,
    VCATEGORIA        IN    VARCHAR2,
      VCVANOD          IN    VARCHAR2,
    VD_TIPO          IN    VARCHAR2,
      VCVACCD          IN    VARCHAR2,
      VCVACDE          IN    VARCHAR2,
      VID_DIVISION      IN    VARCHAR2,
    VD_DIVISION        IN    VARCHAR2,
      VID_AREA        IN    VARCHAR2,
      VD_AREA          IN    VARCHAR2,
    VD_ZONA          IN    VARCHAR2,
      VD_DISTRITO        IN     VARCHAR2,
      VD_UND_GESTION      IN    VARCHAR2,
      VCOD_POB        IN    VARCHAR2,
      VPOBLACION        IN    VARCHAR2,
      VESTRATO        IN    VARCHAR2,
      VCVAHOM          IN    VARCHAR2,
    VCVATNM          IN    VARCHAR2,
      VCVPRBF          IN    VARCHAR2,
      VCVCDGE          IN    VARCHAR2,
    VHOGARES        IN    VARCHAR2,
    VCANTSERV        IN    VARCHAR2,
      VVALREG          IN     VARCHAR2,
      VCVAAPT          IN    VARCHAR2,
      VMULTIPLAY        IN    VARCHAR2,
      VTV_ESPECIAL      IN    VARCHAR2,
    VNOM_ZONA        IN    VARCHAR2,
      VCVAAMV          IN    VARCHAR2,
    VCODIGORESULT        OUT    NUMBER,
    VRESULTADO             OUT   VARCHAR2
  );

  ------------------------------------------------------------------------------------------------------------
  -- OBJETIVO: Inserción en la tabla VENTAS_TECNOLOGIA_FIJA
  -- PARÁMETROS DE ENTRADA: VSERIALPROVEEDOR  IN    VARCHAR2,
  --            VSERIALSAP      IN    VARCHAR2,
  --            VPROCESADOR      IN    VARCHAR2,
  --            VREFERENCIA      IN    VARCHAR2,
  --            VTIPO          IN    VARCHAR2,
  --            VREF         IN    VARCHAR2,
  --            VMARCA        IN    VARCHAR2,
  --            VPROVEEDOR      IN    VARCHAR2,
  --            VNIT        IN    VARCHAR2,
  --            VCODPROVEEDOR    IN    VARCHAR2,
  --            VPRECIOCOSTO    IN    VARCHAR2,
  --            VPRECIOVENTA    IN    VARCHAR2,
  --            VMATERIALSAP    IN    VARCHAR2,
  --            VTIPOENTREGA    IN    VARCHAR2,
  --            VSEGMENTO      IN    VARCHAR2,
  --            VFECHARECEPCION    IN    VARCHAR2,
  --            VDIASINVENTARIO    IN    VARCHAR2,
  --            VCAV        IN    VARCHAR2,
  --            VCENTROSAP      IN    VARCHAR2,
  --            BODEGASAP      IN    VARCHAR2,
  --            VBODMODULO      IN    VARCHAR2,
  --            VCIUDAD        IN    VARCHAR2,
  --            VDIV        IN    VARCHAR2,
  --            VCUENTA        IN    VARCHAR2,
  --            VOT          IN    VARCHAR2,
  --            VFECHACREACIONOTP  IN     DATE,
  --            VFECHACIERREOTP    IN    DATE,
  --            VESTADOOT      IN    VARCHAR2,
  --            VFECHAVENTA      IN    DATE,
  --            VDIA        IN    VARCHAR2,
  --            VMES        IN    VARCHAR2,
  --            VANIO        IN    VARCHAR2,
  --            VTIPOCLIENTE    IN    VARCHAR2,
  --            VESTRATO      IN    VARCHAR2,
  --            VCUOTAS        IN    VARCHAR2,
  --            VASESOR        IN    VARCHAR2,
  --            VESTADO        IN    VARCHAR2,
  --            VALIANZA      IN    VARCHAR2,
  --            VNOMBRECOMUNIDAD  IN    VARCHAR2,
  --            VRED        IN    VARCHAR2,
  --            VDIVISION      IN    VARCHAR2,
  --            VAREA        IN    VARCHAR2,
  --            VZONA        IN    VARCHAR2,
  --            VNOMBRE        IN    VARCHAR2,
  --            VGRUPO        IN    VARCHAR2,
  --            VCANAL        IN    VARCHAR2,
  --            VCANALDOS      IN    VARCHAR2,
  --            VGVDESCRIPCION    IN    VARCHAR2,
  --            VCATEGORIA      IN    VARCHAR2,
  --            VDOCUMENTO      IN    VARCHAR2
  -- PARÁMETROS DE SALIDA:  VCODIGORESULT:  codigo de respuesta
  --            VRESULTADOADO:  descripción
  -- OBJETOS QUE LO REFERENCIAN: Claro.Fraudx.DataAccess
  -- FECHA:                30/05/2018
  -- REALIZADO POR:               Sara Ortiz
  -------------------------------------------------------------------------------------------------------
  PROCEDURE SP_INSERT_TECNOLOGIA_FIJA
  (
    VSERIALPROVEEDOR  IN    VARCHAR2,
     VSERIALSAP      IN    VARCHAR2,
     VPROCESADOR      IN    VARCHAR2,
     VREFERENCIA      IN    VARCHAR2,
     VTIPO          IN    VARCHAR2,
     VREF         IN    VARCHAR2,
     VMARCA        IN    VARCHAR2,
     VPROVEEDOR      IN    VARCHAR2,
     VNIT        IN    VARCHAR2,
     VCODPROVEEDOR    IN    VARCHAR2,
     VPRECIOCOSTO    IN    VARCHAR2,
     VPRECIOVENTA    IN    VARCHAR2,
     VMATERIALSAP    IN    VARCHAR2,
     VTIPOENTREGA    IN    VARCHAR2,
     VSEGMENTO      IN    VARCHAR2,
     VFECHARECEPCION    IN    VARCHAR2,
     VDIASINVENTARIO    IN    VARCHAR2,
     VCAV        IN    VARCHAR2,
     VCENTROSAP      IN    VARCHAR2,
     VBODEGASAP      IN    VARCHAR2,
     VBODMODULO      IN    VARCHAR2,
     VCIUDAD        IN    VARCHAR2,
     VDIV        IN    VARCHAR2,
     VCUENTA        IN    VARCHAR2,
     VOT          IN    VARCHAR2,
    VFECHACREACIONOTP  IN     VARCHAR2,
    VFECHACIERREOTP    IN    VARCHAR2,
    VESTADOOT      IN    VARCHAR2,
    VFECHAVENTA      IN    VARCHAR2,
    VDIA        IN    VARCHAR2,
    VMES        IN    VARCHAR2,
      VANIO        IN    VARCHAR2,
    VTIPOCLIENTE    IN    VARCHAR2,
      VESTRATO      IN    VARCHAR2,
      VCUOTAS        IN    VARCHAR2,
      VASESOR        IN    VARCHAR2,
      VESTADO        IN    VARCHAR2,
      VALIANZA      IN    VARCHAR2,
      VNOMBRECOMUNIDAD  IN    VARCHAR2,
      VRED        IN    VARCHAR2,
      VDIVISION      IN    VARCHAR2,
      VAREA        IN    VARCHAR2,
      VZONA        IN    VARCHAR2,
      VNOMBRE        IN    VARCHAR2,
      VGRUPO        IN    VARCHAR2,
      VCANAL        IN    VARCHAR2,
      VCANALDOS      IN    VARCHAR2,
      VGVDESCRIPCION    IN    VARCHAR2,
    VCATEGORIA      IN    VARCHAR2,
    VDOCUMENTO      IN    VARCHAR2,
    VCODIGORESULT    OUT NUMBER,
    VRESULTADO          OUT VARCHAR2
  );
END;
/

