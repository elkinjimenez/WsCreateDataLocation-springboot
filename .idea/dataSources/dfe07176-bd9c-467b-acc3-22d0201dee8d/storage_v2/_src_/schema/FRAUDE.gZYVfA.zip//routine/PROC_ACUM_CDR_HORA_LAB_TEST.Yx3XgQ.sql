create PROCEDURE proc_acum_cdr_hora_lab_TEST
IS
-- falta agregar validacion para que no acumule periodos ya acumulados
CURSOR c_tmp_cdr IS
SELECT 
       COUNT(*) AS CANT_LLAMADAS,
       t.caller_number as abonado_a,
       t.tipo_trafico,
       to_char(t.start_date,'YYMMDD') as FECHA_INICIO,
       ROUND(sum(TO_NUMBER(t.duration/60))) AS D_REAL,
 	     ROUND(sum(TO_NUMBER(ceil(t.duration/60)))) AS D_LIQUI
FROM   cdr_huawei_ip_tmp T
WHERE  to_char(t.start_date,'HH24:MI') >= '07:00' and to_char(t.start_date,'HH24:MI') <= '20:00'
and  T.CALLED_NUMBER NOT LIKE '0194%'
       and T.CALLER_NUMBER NOT  IN (SELECT M.NUMERO FROM MAESTRA_BLANCOS M)
       AND tipo_trafico = ('LOCAL+LE')
--       and t.id_huawei_ip > 152546749--- Insertado para la carga inicial de los meses de Febrero y Marzo
group by Caller_number,
 	to_char(t.start_date,'YYMMDD'),
	tipo_trafico -- ?????
order by Caller_number ,
       	 to_char(t.start_date,'YYMMDD'),
         tipo_trafico;-- ??????????????
         
CONTADOR NUMBER;
cnt_loop number;
CONTADOR_DIA NUMBER;

BEGIN
CONTADOR:=0;
CONTADOR_DIA:=0;
--CONTADOR_DIA_k:=0;
cnt_loop:=0;

-- INICIAMOS EL PROCESO DE ACUMULACION  
FOR v_tmp_cdr IN c_tmp_cdr
  LOOP
      cnt_loop:=Cnt_loop+1;
	-- SE INSERTA EN LA TABLA QUE ACUMULA POR DIA
	SELECT COUNT(*)
  INTO CONTADOR_DIA
  FROM cdr_ACUM_DIA_laboral
  WHERE ABONADO_a=V_TMP_cdr.ABONADO_A 
  AND tipo_trafico=V_TMP_cdr.tipo_trafico
  AND FECHA=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD');
  
-- Insertamos la cantidad de llamadas diarias  
  
  IF CONTADOR_DIA > 0 then
     UPDATE cdr_ACUM_DIA_laboral
     SET 	
      ACUM_CANT_LLAM = ACUM_CANT_LLAM+V_TMP_cdr.CANT_LLAMADAS,
      ACUM_DURA_REAL=ACUM_DURA_REAL+V_TMP_cdr.D_REAL,
			ACUM_DURA_LIQUI=ACUM_DURA_LIQUI+V_TMP_cdr.D_LIQUI
 		WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico
            AND FECHA=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD');
	ELSE
      insert into cdr_acum_dia_laboral
      (ABONADO_a,
      FECHA,
      ACUM_DURA_REAL,
      ACUM_DURA_LIQUI,
      tipo_trafico,
      ACUM_CANT_LLAM
      )
    	VALUES (
      V_TMP_cdr.ABONADO_A,
      TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD'),
      V_TMP_cdr.D_REAL,
      V_TMP_cdr.D_LIQUI,
      v_TMP_cdr.tipo_trafico,
      V_TMP_cdr.CANT_LLAMADAS
      );
          
      
  END IF;

   IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
    
  -- SE ACTUALIZA LA TABLA DE cdr_ACUM_TOTAL
	-- primero revisamos si el abonado no ha sido insertado de lo contrario es necesario hacerlo.
	SELECT COUNT(*)
	INTO CONTADOR
	FROM cdr_ACUM_TOTAL_laboral
	WHERE ABONADO_a=V_TMP_cdr.ABONADO_A AND tipo_trafico=V_TMP_cdr.tipo_trafico;
	IF CONTADOR>0 THEN
		UPDATE 	cdr_ACUM_TOTAL_laboral
		SET 	ACUM_DURA_REAL=ACUM_DURA_REAL+V_TMP_cdr.D_REAL,
    			ACUM_DURA_LIQUI=ACUM_DURA_LIQUI+V_TMP_cdr.D_LIQUI,
          ACUM_CANT_LLAM=ACUM_CANT_LLAM+V_TMP_cdr.CANT_LLAMADAS,
          ACUM_DIAS=ACUM_DIAS+1,
          fecha_max=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD')
		WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico;
	ELSE

    INSERT INTO cdr_ACUM_TOTAL_laboral (
    ABONADO_a ,
    ACUM_DURA_REAL,
    ACUM_DURA_LIQUI,
    ACUM_CANT_LLAM ,
    tipo_trafico ,
    ACUM_DIAS,
    Fecha_Min
    )
		VALUES(
    V_TMP_cdr.ABONADO_A,
    V_TMP_cdr.D_REAL,
    V_TMP_cdr.D_LIQUI,
    V_TMP_cdr.CANT_LLAMADAS,
    V_TMP_cdr.tipo_trafico,
    1,
    TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD')
    );
    
	END IF  ;
      IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;

      
  -- SE ACTUALIZA LA TABLA DE cdr_HISTORICO
	-- primero revisamos si el abonado no ha sido insertado de lo contrario es necesario hacerlo.
	SELECT COUNT(*)
	INTO CONTADOR
	FROM cdr_HISTORICO_laboral
	WHERE ABONADO_a=V_TMP_cdr.ABONADO_A AND tipo_trafico=V_TMP_cdr.tipo_trafico;
	IF CONTADOR>0 THEN
		UPDATE 	cdr_HISTORICO_laboral
		SET 	ACUM_DURA_REAL=ACUM_DURA_REAL+V_TMP_cdr.D_REAL,
    			ACUM_DURA_LIQUI=ACUM_DURA_LIQUI+V_TMP_cdr.D_LIQUI,
          ACUM_CANT_LLAM=ACUM_CANT_LLAM+V_TMP_cdr.CANT_LLAMADAS,
          ACUM_DIAS=ACUM_DIAS+1,
          fecha_max=TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD')
		WHERE 	ABONADO_a=V_TMP_cdr.ABONADO_A 
            AND tipo_trafico=V_TMP_cdr.tipo_trafico;
	ELSE
		INSERT INTO cdr_HISTORICO_laboral (
    ABONADO_a ,
    ACUM_DURA_REAL,
    ACUM_DURA_LIQUI,
    ACUM_CANT_LLAM ,
    tipo_trafico ,
    ACUM_DIAS,
    Fecha_Min
    )
		VALUES(
    V_TMP_cdr.ABONADO_A,
    V_TMP_cdr.D_REAL,
    V_TMP_cdr.D_LIQUI,
    V_TMP_cdr.CANT_LLAMADAS,
    V_TMP_cdr.tipo_trafico,
    1,
    TO_DATE(V_TMP_CDR.FECHA_INICIO,'YYMMDD')
    );
	END IF  ;
      IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;    
      
  END LOOP;

  /*depura la tabla tmp_cdr*/
--   END LOOP;
  
  --delete from tmp_cdr;
  delete from cdr_ACUM_DIA_laboral;
  COMMIT;
  
END;
/

