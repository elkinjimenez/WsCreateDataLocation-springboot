create view GENERA_MAIL_EVIDENTE as
select "SENTENCIA" from (
select
'send-mailmessage -to '||  e.email || ' -from "prevencionfraude.co@claro.com.co" -cc "carlos.ramirez.r@claro.com.co", "alexander.retavisca@claro.com.co" -subject "INCUMPLIMIENTO POLITICA DE AUTENTICACION DE IDENTIDAD EQUIPOS FINANCIADOS" -Attachments "D:\INCUMPLIMIENTOS_EVIDENTE\REPORTE\'|| e.NOMBRE_ARCHIVO ||'.csv" -body "Cordial saludo,  apreciado distribuidor '||e.nombre_distribuidor||'. En el control a la política de AUTENTICACION DE IDENTIDAD se identifica un presunto incumplimiento a la misma. En esta  se indica que es obligatoria la validación de identidad aprobada en Venta de equipos a cuotas. En el archivo adjunto se detallan las ventas de equipos financiados que NO tienen una validación de identidad aprobada bien sea evidente, confronta o Biometria hasta antes de 5 dias de realizada la activacion. Por favor en un plazo maximo de 3 dias habiles informar a este mismo correo si existe una justificacion de no cumplimiento de la misma. Cordialmente Equipo de Prevencion Fraude CLARO." -smtpServer outlook.co.attla.corp
'as sentencia
from email_distr_biometria E
ORDER BY e.nombre_distribuidor asc
)
/

