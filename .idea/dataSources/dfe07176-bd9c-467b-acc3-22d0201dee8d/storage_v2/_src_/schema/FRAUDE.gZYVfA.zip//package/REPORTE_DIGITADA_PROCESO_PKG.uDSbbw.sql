create PACKAGE reporte_digitada_proceso_pkg IS

   PROCEDURE actualiza_dth(vc_resultado OUT VARCHAR2,
                           nm_error     OUT NUMBER);

   PROCEDURE validaventa_cruzada(vc_resultado OUT VARCHAR2,
                                 nm_error     OUT NUMBER);

   FUNCTION fn_valida_ciudad_riesgosa(vc_nodo IN VARCHAR2) RETURN VARCHAR2;

   PROCEDURE validardistribuidores(p_dia           IN NUMBER,
                                   p_cur_resultado OUT SYS_REFCURSOR,
                                   p_nm_resp       OUT NUMBER,
                                   p_vc_resp       OUT VARCHAR2);

   PROCEDURE ventassinvalidacion(p_dia           IN NUMBER,
                                 p_distribuidor  IN VARCHAR2,
                                 p_cur_resultado OUT SYS_REFCURSOR,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2);

   PROCEDURE buscarcorreodis_anterior(p_distribuidor IN VARCHAR2,
                                      p_correo       OUT VARCHAR2,
                                      p_archivo      OUT VARCHAR2,
                                      p_nm_resp      OUT NUMBER,
                                      p_vc_resp      OUT VARCHAR2);

   PROCEDURE buscarcorreodis(p_distribuidor IN VARCHAR2,
                             p_correo       OUT VARCHAR2,
                             p_archivo      OUT VARCHAR2,
                             p_nm_resp      OUT NUMBER,
                             p_vc_resp      OUT VARCHAR2);

   FUNCTION fn_paquete_pg(vc_cuenta IN VARCHAR2) RETURN VARCHAR2;

   PROCEDURE ventas_tmk_inbound(p_dia           IN NUMBER,
                                p_cur_resultado OUT SYS_REFCURSOR,
                                p_nm_resp       OUT NUMBER,
                                p_vc_resp       OUT VARCHAR2);

END reporte_digitada_proceso_pkg;
/

