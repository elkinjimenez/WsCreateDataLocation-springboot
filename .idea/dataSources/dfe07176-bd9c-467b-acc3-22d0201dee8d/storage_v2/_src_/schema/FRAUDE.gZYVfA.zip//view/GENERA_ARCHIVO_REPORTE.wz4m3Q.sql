create view GENERA_ARCHIVO_REPORTE as
select "SENTENCIA" from (
select
'SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING on
SET LINESIZE 500
spool d:\biometria\reporte\'||m.nombre_archivo||'.csv'||chr(59)||'
prompt cliente,sucursal,nuip_sucursal,nut,fecha,documento,respuesta,usercod,sucursalid,operationid,userip,usermac,estado,proceso
Select
cliente||'||chr(39)||','||chr(39)||'||
sucursal||'||chr(39)||','||chr(39)||'||
nuip_sucursal||'||chr(39)||','||chr(39)||'||
nut||'||chr(39)||','||chr(39)||'||
fecha||'||chr(39)||','||chr(39)||'||
documento||'||chr(39)||','||chr(39)||'||
respuesta||'||chr(39)||','||chr(39)||'||
usercod||'||chr(39)||','||chr(39)||'||
sucursalid||'||chr(39)||','||chr(39)||'||
operationid||'||chr(39)||','||chr(39)||'||
userip||'||chr(39)||','||chr(39)||'||
usermac||'||chr(39)||','||chr(39)||'||
estado||'||chr(39)||','||chr(39)||'||
proceso
from reportes_biometria r, datos_distribuidores d
where r.sucursalid = d.cod_distribuidor
and d.nit = '||chr(39)||trim(m.nit)||chr(39)||'
and to_date(r.fecha, '||chr(39)||'DD/MM/YYYY HH24:MI:SS'||chr(39)||') >= to_char(sysdate-30,'||chr(39)||'DD/MM/YYYY'||chr(39)||')
ORDER BY to_date(r.fecha, '||chr(39)||'DD/MM/YYYY HH24:MI:SS'||chr(39)||')'||chr(59)||'
SPOOL OFF'||chr(59) as sentencia
from EMAIL_DISTR_BIOMETRIA m
)
/

