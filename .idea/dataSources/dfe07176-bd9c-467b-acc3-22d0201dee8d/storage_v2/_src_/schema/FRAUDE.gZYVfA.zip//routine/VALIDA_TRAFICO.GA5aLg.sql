create function valida_trafico(vc_min varchar2) return number is
   Result number;
begin
  
select count('1')
into Result
 from repos_financiados_rev_trafico s
where s.min=vc_min
;
  return(Result);
end valida_trafico;
/

