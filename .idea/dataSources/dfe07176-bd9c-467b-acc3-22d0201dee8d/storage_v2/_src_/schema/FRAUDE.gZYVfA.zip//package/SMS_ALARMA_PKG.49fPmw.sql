create PACKAGE sms_alarma_pkg IS

   -- Author  : ICM0613A
   -- Created : 11/09/2019 5:54:50 p. m.
   -- Purpose : Paquete que procesa los mensajes de texto que se enviaran por alarma
   PROCEDURE inserta_repos(vc_mensajes OUT VARCHAR2,
                           nm_error    OUT NUMBER);

   PROCEDURE consulta_tramites(p_nm_dias       NUMBER,
                               p_cur_resultado OUT SYS_REFCURSOR,
                               p_nm_resp       OUT NUMBER,
                               p_vc_resp       OUT VARCHAR2);

   PROCEDURE consulta_kit_prepago(p_nm_dias       NUMBER,
                                  p_cur_resultado OUT SYS_REFCURSOR,
                                  p_nm_resp       OUT NUMBER,
                                  p_vc_resp       OUT VARCHAR2);

   PROCEDURE inserta_tramite(vc_tramite          VARCHAR2,
                             vc_fecha_tramite    VARCHAR2,
                             vc_contrato_tramite VARCHAR2,
                             vc_documento        VARCHAR2,
                             vc_tel_antiguo      VARCHAR2,
                             vc_contrato_antiguo VARCHAR2,
                             vc_observaciones    alarma_mensajes.observaciones%TYPE,
                             p_nm_resp           OUT NUMBER,
                             p_vc_resp           OUT VARCHAR2);

   PROCEDURE consulta_repos_financiadas(p_nm_dias       NUMBER,
                                        p_cur_resultado OUT SYS_REFCURSOR,
                                        p_nm_resp       OUT NUMBER,
                                        p_vc_resp       OUT VARCHAR2);
   --MODIFICACION 13/02/2020                                        
   PROCEDURE consulta_ventas_movil(p_nm_dias       NUMBER,
                                   p_cur_resultado OUT SYS_REFCURSOR,
                                   p_nm_resp       OUT NUMBER,
                                   p_vc_resp       OUT VARCHAR2);

   --MODIFICAICON 20/03/2020 ARCHIVOS POM 
   PROCEDURE consulta_tramites_pom(p_nm_dias       NUMBER,
                                   p_vc_tramite    VARCHAR2,
                                   p_cur_resultado OUT SYS_REFCURSOR,
                                   p_nm_resp       OUT NUMBER,
                                   p_vc_resp       OUT VARCHAR2);

   --MODIFICACION  03042020 SUSPENDER LOS QUE DIERON RESULTADO IVR INCORRECTO                               
   PROCEDURE consulta_alarma(p_vc_tipo    IN VARCHAR2,
                             cursoralarma OUT SYS_REFCURSOR,
                             p_nm_resp    OUT NUMBER,
                             p_vc_resp    OUT VARCHAR2);

   PROCEDURE actualiza_alarma_rta_pom(p_vc_consecutivo IN VARCHAR2,
                                      p_vc_custcode    IN VARCHAR2,
                                      p_nm_resp        OUT NUMBER,
                                      p_vc_resp        OUT VARCHAR2);

   --modificacion 04/09/2020 inclusion de vents de tecnologia 
   PROCEDURE inserta_tramite_sal(vc_tramite          VARCHAR2,
                                 vc_fecha_tramite    VARCHAR2,
                                 vc_contrato_tramite VARCHAR2,
                                 vc_documento        VARCHAR2,
                                 vc_tel_antiguo      VARCHAR2,
                                 vc_contrato_antiguo VARCHAR2,
                                 vc_observaciones    alarma_mensajes.observaciones%TYPE,
                                 p_nm_consecutivo    OUT NUMBER,
                                 p_nm_resp           OUT NUMBER,
                                 p_vc_resp           OUT VARCHAR2);

   PROCEDURE consulta_tecnologia(p_nm_dias       NUMBER,
                                 p_cur_resultado OUT SYS_REFCURSOR,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2);

   PROCEDURE radicacion_tecnologia_movil(p_vc_tipo        IN VARCHAR2,
                                         cursorradicacion OUT SYS_REFCURSOR,
                                         p_nm_resp        OUT NUMBER,
                                         p_vc_resp        OUT VARCHAR2);

   --18/10/2020 Insertar en tabla de whast app
   PROCEDURE inserta_tramite_whastapp(vc_documento        VARCHAR2,
                                      vc_custcode         VARCHAR2,
                                      vc_customer_id      VARCHAR2,
                                      vc_co_id            VARCHAR2,
                                      vc_fecha_activacion VARCHAR2,
                                      vc_min_venta        VARCHAR2,
                                      p_nm_resp           OUT NUMBER,
                                      p_vc_resp           OUT VARCHAR2);
END sms_alarma_pkg;
/

