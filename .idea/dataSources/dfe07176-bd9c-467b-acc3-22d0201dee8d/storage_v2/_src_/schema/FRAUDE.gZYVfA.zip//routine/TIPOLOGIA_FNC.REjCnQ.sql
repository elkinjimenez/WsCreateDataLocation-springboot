create function TIPOLOGIA_FNC(VC_NAME IN VARCHAR2) return varchar2 is
  Result varchar2(100);
begin
  select T.Codigo
   INTO ResulT
  from RFH_TIPOLOGIA_FRAUDE t
where UPPER(t.diagnostico) = UPPER(VC_NAME);

  return(Result);
exception
  when others then 
    return null;  
end TIPOLOGIA_FNC;
/

