create PACKAGE "PK_CONSULTA_FRAUDE" IS

  /**************************************************************************************************
  ** OBJECTNAME:     PK_CONSULTA_FRAUDE
  **
  ** DESCRIPTION:    PERMITE REALIZAR LA CONSULTA DE LAS DIFERENTES ALARMAS DE FRAUDE
  **
  ** REVISION HISTORY:
  ** -----------------------------------------------------------------------------------------------------------------------------------
  **  DATE  NAME    DESCRIPTION      VERSION
  ** -----------------------------------------------------------------------------------------------------------------------------------
  ** 19-NOV-09      GUSTAVO GOMEZ    CREACION                     1.0
  **
  ***************************************************************************************************/
  TYPE T_CURSOR IS REF CURSOR;

  PROCEDURE PR_TERCER_PAIS_EMPRESAS(RESULTSET OUT T_CURSOR);

  PROCEDURE PR_TERCER_PAIS_HOGARES(RESULTSET OUT T_CURSOR);
  
  PROCEDURE PR_TERCER_PAIS_FRAUDVIEW(RESULTSET OUT T_CURSOR);

  PROCEDURE PR_REORI_REVENTA_EMPRESAS(RESULTSET OUT T_CURSOR);

  PROCEDURE PR_REORI_REVENTA_HOGARES(RESULTSET OUT T_CURSOR);
  
  PROCEDURE PR_MEJORES_ALARMAS_EMPRESAS(RESULTSET OUT T_CURSOR);
  
  PROCEDURE PR_MEJORES_ALARMAS_HOGARES(RESULTSET OUT T_CURSOR);
  
  PROCEDURE PR_MALLA_FRAUDE_HOGARES(RESULTSET OUT T_CURSOR);
  
  PROCEDURE PR_LOG_EMPRESAS(RESULTSET OUT T_CURSOR);
  
  PROCEDURE PR_LOG_HOGARES(RESULTSET OUT T_CURSOR);  

END PK_CONSULTA_FRAUDE;
/

