create view GEN_ARC_EVIDENTE as
select "SENTENCIA" from (
select
'SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING on
SET LINESIZE 1500
spool d:\incumplimientos_evidente\reporte\'||m.nombre_archivo||'.csv'||chr(59)||'
prompt imei;edad_real_ascard;saldo_cuenta_ascard;custcode;min;fecha_venta;mes_venta;nombres;apellidos;tipo_documento;numero_documento;direccion;indicativo;telefono;ciudad_departamento;codigo_distribuidor;es_distribuidor;plan;valor_cfm;iva_cfm;equipo;iva_equipo;total_venta;modelo_equipo;cuotas;grupo_clientes;centro_costo;maestra;fecregis;rmin;resn;rtar;rdtc;estado;credito;spcode;tmcode;distribuidor1;user_poliedro;fecbscs;sim;valor_card;iva_card;trajo_iccid;occ;producto;fianza;id_vendedor;promocion;conexion_sap;modelo_equipo_anterior;imei_anterior;actividad;co_id;cod_razon_estado;cod_razon_estado_ini;tipo_linea;cod_agente;tipo_identificacion;permanencia_actual;permanencia_pendiente;genero;edad_mora;vlr_mora;codigos;nombre_dist;nombre_dist_agrupado;canal;estado2;region_final
Select
e.imei||'||chr(39)||';'||chr(39)||'||
e.edad_real_ascard||'||chr(39)||';'||chr(39)||'||
e.saldo_cuenta_ascard||'||chr(39)||';'||chr(39)||'||
e.custcode||'||chr(39)||';'||chr(39)||'||
e.min||'||chr(39)||';'||chr(39)||'||
e.fecha_venta||'||chr(39)||';'||chr(39)||'||
e.mes_venta||'||chr(39)||';'||chr(39)||'||
e.nombres||'||chr(39)||';'||chr(39)||'||
e.apellidos||'||chr(39)||';'||chr(39)||'||
e.tipo_documento||'||chr(39)||';'||chr(39)||'||
e.numero_documento||'||chr(39)||';'||chr(39)||'||
e.direccion||'||chr(39)||';'||chr(39)||'||
e.indicativo||'||chr(39)||';'||chr(39)||'||
e.telefono||'||chr(39)||';'||chr(39)||'||
e.ciudad_departamento||'||chr(39)||';'||chr(39)||'||
e.codigo_distribuidor||'||chr(39)||';'||chr(39)||'||
e.es_distribuidor||'||chr(39)||';'||chr(39)||'||
e.plan||'||chr(39)||';'||chr(39)||'||
e.valor_cfm||'||chr(39)||';'||chr(39)||'||
e.iva_cfm||'||chr(39)||';'||chr(39)||'||
e.equipo||'||chr(39)||';'||chr(39)||'||
e.iva_equipo||'||chr(39)||';'||chr(39)||'||
e.total_venta||'||chr(39)||';'||chr(39)||'||
e.modelo_equipo||'||chr(39)||';'||chr(39)||'||
e.cuotas||'||chr(39)||';'||chr(39)||'||
e.grupo_clientes||'||chr(39)||';'||chr(39)||'||
e.centro_costo||'||chr(39)||';'||chr(39)||'||
e.maestra||'||chr(39)||';'||chr(39)||'||
e.fecregis||'||chr(39)||';'||chr(39)||'||
e.rmin||'||chr(39)||';'||chr(39)||'||
e.resn||'||chr(39)||';'||chr(39)||'||
e.rtar||'||chr(39)||';'||chr(39)||'||
e.rdtc||'||chr(39)||';'||chr(39)||'||
e.estado||'||chr(39)||';'||chr(39)||'||
e.credito||'||chr(39)||';'||chr(39)||'||
e.spcode||'||chr(39)||';'||chr(39)||'||
e.tmcode||'||chr(39)||';'||chr(39)||'||
e.distribuidor1||'||chr(39)||';'||chr(39)||'||
e.user_poliedro||'||chr(39)||';'||chr(39)||'||
e.fecbscs||'||chr(39)||';'||chr(39)||'||
e.sim||'||chr(39)||';'||chr(39)||'||
e.valor_card||'||chr(39)||';'||chr(39)||'||
e.iva_card||'||chr(39)||';'||chr(39)||'||
e.trajo_iccid||'||chr(39)||';'||chr(39)||'||
e.occ||'||chr(39)||';'||chr(39)||'||
e.producto||'||chr(39)||';'||chr(39)||'||
e.fianza||'||chr(39)||';'||chr(39)||'||
e.id_vendedor||'||chr(39)||';'||chr(39)||'||
e.promocion||'||chr(39)||';'||chr(39)||'||
e.conexion_sap||'||chr(39)||';'||chr(39)||'||
e.modelo_equipo_anterior||'||chr(39)||';'||chr(39)||'||
e.imei_anterior||'||chr(39)||';'||chr(39)||'||
e.actividad||'||chr(39)||';'||chr(39)||'||
e.co_id||'||chr(39)||';'||chr(39)||'||
e.cod_razon_estado||'||chr(39)||';'||chr(39)||'||
e.cod_razon_estado_ini||'||chr(39)||';'||chr(39)||'||
e.tipo_linea||'||chr(39)||';'||chr(39)||'||
e.cod_agente||'||chr(39)||';'||chr(39)||'||
e.tipo_identificacion||'||chr(39)||';'||chr(39)||'||
e.permanencia_actual||'||chr(39)||';'||chr(39)||'||
e.permanencia_pendiente||'||chr(39)||';'||chr(39)||'||
e.genero||'||chr(39)||';'||chr(39)||'||
e.edad_mora||'||chr(39)||';'||chr(39)||'||
e.vlr_mora||'||chr(39)||';'||chr(39)||'||
e.codigos||'||chr(39)||';'||chr(39)||'||
e.nombre_dist||'||chr(39)||';'||chr(39)||'||
e.nombre_dist_agrupado||'||chr(39)||';'||chr(39)||'||
e.canal||'||chr(39)||';'||chr(39)||'||
e.estado2||'||chr(39)||';'||chr(39)||'||
e.region_final
from incumplimientos_IDENTIDAD e, datos_distribuidores d
where e.codigo_distribuidor = d.cod_distribuidor
and d.nit = '||chr(39)||trim(m.nit)||chr(39)||chr(59)||'
SPOOL OFF'||chr(59) as sentencia
from email_distr_biometria m
)
/

