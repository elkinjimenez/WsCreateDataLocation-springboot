create procedure PROC_mejores_alarmas_tmxh is

cursor  c_mejores_alarmas is
select B.*,
 ceil((b.avg_ab_b_dif/ b.acum_cant_llam)*100) as dispersion_abonados, 
 ceil((b.destinos_dif/b.acum_cant_llam)*100) as dispersion_ciudades, 
 ceil((b.llamadas_hora_laboral/b.acum_cant_llam)*100) as porc_llamadas_hora_laboral, 
 ceil(b.acum_dura_real/b.acum_cant_llam) as Duracion_promedio
from alarmas_new_tmxh b;

v_alarmas c_mejores_alarmas%rowtype;

-- estas variables se usan para calcular la diferencia 
-- con relacion a su promedio.

v_cant_meses      number;
v_saldo_pend      number;
v_dif_dest        number;
v_dif_ciu        number;
v_porc_desv_llam  number;
v_porc_desv_min   number;
v_cant_llam       number;
v_cant_min        number;
tipo_alarma       varchar(500);
v_min_larga_dura  number;
v_DISPERSION      number;
V_DURACION_PROMEDIO      number;
V_RELACION_LLAM_HORA_LABORAL number;
V_umbral_llamadas_reorigina  number;
V_umbral_dispersion_ciudades number;
-- v_ip_clientes_libres         varchar(20);
-- v_codcli_numer_libres        varchar(20);
-- v_cliente_num_libres         varchar(100);

Begin 

delete mejores_alarmas_tmxh;
commit;

-- Extraemos los umbrales

tipo_alarma := '';


Open c_mejores_alarmas;

loop

    Fetch c_mejores_alarmas into  v_alarmas;
    exit when c_mejores_alarmas%notfound;
    
    begin
    
          select k.cant_meses_consumo into v_cant_meses from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.saldo_pend into v_saldo_pend from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_abonadosb_dif into v_dif_dest from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_ciudades into v_dif_ciu  from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.porc_desv_llam_resp_histo into v_porc_desv_llam  from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.porc_desv_min_resp_histo into v_porc_desv_min from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.porc_desv_min_resp_histo          into v_porc_desv_min          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_llamadas          into v_cant_llam          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_minutos          into v_cant_min          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.min_para_larga_dura          into v_min_larga_dura          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select R.DISPERSION_ABONADOS          into   v_DISPERSION        from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;

          
          select R.DURACION_PROMEDIO          into  V_DURACION_PROMEDIO         from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;

          
          select R.RELACION_LLAMA_HORA_LABORAL          into  V_RELACION_LLAM_HORA_LABORAL      from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;
          
          select R.CANT_LLAMADAS          into  V_umbral_llamadas_reorigina      from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;
          
          select R.DISPERSION_CIUDADES          into  V_umbral_dispersion_ciudades    from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;
          
          end;

-- Validamos Reoriginamiento Local + LE
   
   IF V_ALARMAS.TIPO_TRAFICO = 'LOCAL+LE' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO LOCAL,';
          END IF;                   
  END IF;       
                                
-- Validamos Reoriginamiento NACIONAL TERCEROS

   IF V_ALARMAS.TIPO_TRAFICO = 'LDN-TERCEROS' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades >= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO NACIONAL POR TERCEROS,';
          END IF;                   
  END IF;       

-- Validamos Reoriginamiento NACIONAL POR TELMEX

   IF V_ALARMAS.TIPO_TRAFICO = 'LDN-POR-TELMEX' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades >= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL <= V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO NACIONAL POR TELMEX,';
          END IF;                   
  END IF;       

-- Validamos Reoriginamiento HACIA MOVILES

   IF V_ALARMAS.TIPO_TRAFICO = 'MOVILES' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
--            and V_ALARMAS.Dispersion_Ciudades >= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL <=V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO HACIA MOVILES,';
          END IF;                   
  END IF;   
   
-- Validamos TERCER PAIS POR TERCEROS

   IF V_ALARMAS.TIPO_TRAFICO = 'LDI-TERCEROS' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades <= V_umbral_dispersion_ciudades -- EN PORCENTAJE
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'TERCER PAIS POR TERCEROS,';
          END IF;                   
  END IF;       

-- Validamos TERCER PAIS POR TELMEX

   IF V_ALARMAS.TIPO_TRAFICO = 'LDI-POR-TELMEX' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades <= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'TERCER PAIS POR TELMEX,';
          END IF;                   
  END IF;       


-- Validamos NUMEROS LIBRES CON CONSUMOS
   IF V_ALARMAS.OPERADOR = 'TCB - TELEFONIA POR CABLE DE SANTAFE DE BOGOTA' THEN
           IF V_ALARMAS.nombre_cliente IS NULL THEN
              tipo_alarma := tipo_alarma||'LIBRES CON CONSUMO,';
           END IF; 
   END IF;     
   
-- Validamos perfil reventa

 IF V_ALARMAS.TIPO_TRAFICO = 'MOVILES' THEN
          if  v_alarmas.prom_llam_diaria >= 6
              AND  v_alarmas.avg_ab_b_dif >= v_dif_dest
              AND V_ALARMAS.PROM_MIN_DIARIO >=  v_cant_min
              AND  V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < 98
              THEN 
              tipo_alarma := tipo_alarma||'POSIBLE REVENTA MOVILES,';
          END IF;  
 END IF;       
 
  
  IF V_ALARMAS.OPERADOR_NUESTRO = 'SI' THEN
     tipo_alarma := tipo_alarma||'PROPIO,';
            if   (v_alarmas.Prom_Llam_Diaria) > v_cant_llam  AND  V_ALARMAS.ACUM_DURA_REAL >= V_CANT_MIN then 
                    tipo_alarma := tipo_alarma||'Muchas LLamadas,';
            if 2*v_alarmas.Saldo_Actual > v_saldo_pend then
            tipo_alarma:= tipo_alarma||'Riesgo de cartera, ';
            end if;
/*          if v_alarmas.avg_ab_b_dif > v_dif_dest and v_alarmas.Meses_De_CONSUMO < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.destinos_dif > v_dif_ciu and v_alarmas.Meses_De_CONSUMO < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
*/            if (v_alarmas.Porc_Desv_Llam_Resp_Historico > v_porc_desv_llam or 
               v_alarmas.Porc_Desv_Min_Resp_Historico > v_porc_desv_min) and 
               v_alarmas.Meses_De_CONSUMO >= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  (v_alarmas.Meses_De_Instalado <= 1 or  v_alarmas.meses_de_consumo <=1) and v_alarmas.avg_ab_b_dif > 3
                and v_alarmas.tipo_trafico <> 'LOCAL+LE' then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
          
          else 
            tipo_alarma := tipo_alarma||'Duracion,';
-- Se elimina para sacar solo alarmas de Fraude. Sep 07 2007   
            if  V_ALARMAS.PROM_MIN_DIARIO / V_ALARMAS.PROM_LLAM_DIARIA > v_min_larga_dura  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
            
          END IF;
                   
       END IF;    

         IF V_ALARMAS.OPERADOR_NUESTRO IS NULL THEN
     tipo_alarma := tipo_alarma||'TERCEROS,';
            if   (v_alarmas.Prom_Llam_Diaria) > v_cant_llam AND V_ALARMAS.ACUM_DURA_REAL >= V_CANT_MIN  then 
                    tipo_alarma := tipo_alarma||'Muchas LLamadas,';
            if v_alarmas.avg_ab_b_dif > v_dif_dest and v_alarmas.Meses_De_CONSUMO < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.destinos_dif > v_dif_ciu and v_alarmas.Meses_De_CONSUMO < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.Porc_Desv_Llam_Resp_Historico > v_porc_desv_llam or 
               v_alarmas.Porc_Desv_Min_Resp_Historico > v_porc_desv_min) and 
               v_alarmas.Meses_De_CONSUMO >= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  (v_alarmas.Meses_De_Instalado <= 1 or  v_alarmas.meses_de_consumo <=1)  and v_alarmas.avg_ab_b_dif > 3 then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
          
          else 
            tipo_alarma := tipo_alarma||'Duracion,';
-- Se elimina para sacar solo alarmas de Fraude. Sep 07 2007   
            if  V_ALARMAS.PROM_MIN_DIARIO / V_ALARMAS.PROM_LLAM_DIARIA > v_min_larga_dura  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
            
   END IF;
                   
       END IF;    
        
        if (tipo_alarma  IS NOT NULL 
             AND tipo_alarma NOT IN ('PROPIO,Muchas LLamadas,','PROPIO,Duracion,','TERCEROS,Muchas LLamadas,','TERCEROS,Duracion,')
             ) 
             THEN 
          
                insert into mejores_alarmas_tmxh
                ( CODIGO_CLIENTE,
                  ENLACE,
                  ABONADO_A,
                  ACUM_DURA_REAL,
                  ACUM_DURA_LIQUI,
                  ACUM_CANT_LLAM,
                  AVG_AB_B_DIF,
                  PROM_MIN_DIARIO,
                  PROM_VALOR_DIARIO,
                  PROM_LLAM_DIARIA,
                  TIPO_TRAFICO,
                  ACUM_DIAS,
                  OPERADOR,
                  OPERADOR_NUESTRO,
                  NOMBRE_CLIENTE,
                  NTDIDE,
                  TIPDIDE,
                  FECHA_ASIGNACION,
                  DIRECCION,
                  SEGMENTO,
                  PROMEDIO_FACTURACION,
                  SALDO_ACTUAL,
                  DES_SUBCATEGORIA,
                  DESC_CATEGORIA,
                  FV,
                  POBLACION,
                  DEPTO,
                  FECHA_MIN_CONS,
                  FECHA_MAX_CONS,
                  FEC_GEN_ALARMA,
                  IP,
                  DESTINOS_DIF,
                  PROM_MIN_DIARIO_HISTORICO,
                  PROM_LLAM_DIARIA_HISTORICO,
                  PORC_DESV_LLAM_RESP_HISTORICO,
                  PORC_DESV_MIN_RESP_HISTORICO,
                  MESES_DE_INSTALADO,
                  MESES_DE_CONSUMO,
                  PLAN_FACTURACION,
                  LLAMADAS_HORA_LABORAL,
                  LLAMADAS_HORA_NO_LABORAL,
                  DISPERSION_ABONADOS,
                  DISPERSION_CIUDADES,
                  PORC_LLAMADAS_HORA_LABORAL,
                  DURACION_PROMEDIO,
                  TIPO_ALARMA
                  )
                values (V_ALARMAS.CODIGO_CLIENTE,
                        V_ALARMAS.ENLACE,
                        V_ALARMAS.ABONADO_A,
                        V_ALARMAS.ACUM_DURA_REAL,
                        V_ALARMAS.ACUM_DURA_LIQUI,
                        V_ALARMAS.ACUM_CANT_LLAM,
                        V_ALARMAS.AVG_AB_B_DIF,
                        V_ALARMAS.PROM_MIN_DIARIO,
                        V_ALARMAS.PROM_VALOR_DIARIO,
                        V_ALARMAS.PROM_LLAM_DIARIA,
                        V_ALARMAS.TIPO_TRAFICO,
                        V_ALARMAS.ACUM_DIAS,
                        V_ALARMAS.OPERADOR,
                        V_ALARMAS.OPERADOR_NUESTRO,
                        V_ALARMAS.NOMBRE_CLIENTE,
                        V_ALARMAS.NTDIDE,
                        V_ALARMAS.TIPDIDE,
                        V_ALARMAS.FECHA_ASIGNACION,
                        V_ALARMAS.DIRECCION,
                        V_ALARMAS.SEGMENTO,
                        V_ALARMAS.PROMEDIO_FACTURACION,
                        V_ALARMAS.SALDO_ACTUAL,
                        V_ALARMAS.DES_SUBCATEGORIA,
                        V_ALARMAS.DESC_CATEGORIA,
                        V_ALARMAS.FV,
                        V_ALARMAS.POBLACION,
                        V_ALARMAS.DEPTO,
                        V_ALARMAS.FECHA_MIN_CONS,
                        V_ALARMAS.FECHA_MAX_CONS,
                        V_ALARMAS.FEC_GEN_ALARMA,
                        V_ALARMAS.IP,
                        V_ALARMAS.DESTINOS_DIF,
                        V_ALARMAS.PROM_MIN_DIARIO_HISTORICO,
                        V_ALARMAS.PROM_LLAM_DIARIA_HISTORICO,
                        V_ALARMAS.PORC_DESV_LLAM_RESP_HISTORICO,
                        V_ALARMAS.PORC_DESV_MIN_RESP_HISTORICO,
                        V_ALARMAS.MESES_DE_INSTALADO,
                        V_ALARMAS.MESES_DE_CONSUMO,
                        V_ALARMAS.PLAN_FACTURACION,
                        V_ALARMAS.LLAMADAS_HORA_LABORAL,
                        V_ALARMAS.LLAMADAS_HORA_NO_LABORAL,
                        V_ALARMAS.DISPERSION_ABONADOS,
                        V_ALARMAS.DISPERSION_CIUDADES,
                        V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL,
                        V_ALARMAS.DURACION_PROMEDIO,
                        tipo_alarma
                        );
         end if;   
       commit;
       v_alarmas:=null; 
       tipo_alarma:='';
              
end loop;

close c_mejores_alarmas;

end;


/

