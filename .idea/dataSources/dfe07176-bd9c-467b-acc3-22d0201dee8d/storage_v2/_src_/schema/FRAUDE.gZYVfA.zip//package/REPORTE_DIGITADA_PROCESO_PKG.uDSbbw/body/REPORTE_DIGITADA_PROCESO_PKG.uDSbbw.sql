create PACKAGE BODY reporte_digitada_proceso_pkg IS

   -- Private type declarations
   PROCEDURE actualiza_dth(vc_resultado OUT VARCHAR2,
                           nm_error     OUT NUMBER) IS
   
   BEGIN
      nm_error     := 0;
      vc_resultado := 'OK';
   
      UPDATE ventas_digitadas_fija_auto a
         SET a.dth = 'SI'
       WHERE a.dth IS NULL
         AND a.cvaarg = 'DTH'
         AND a.procesado IS NULL;
   
      UPDATE ventas_digitadas_fija_auto a
         SET a.dth = 'NO'
       WHERE a.dth IS NULL
         AND a.cvaarg <> 'DTH'
         AND a.procesado IS NULL;
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         vc_resultado := 'Error' || SQLERRM;
         nm_error     := SQLCODE;
   END actualiza_dth;

   PROCEDURE validaventa_cruzada(vc_resultado OUT VARCHAR2,
                                 nm_error     OUT NUMBER) IS
   
      CURSOR c IS
         SELECT a.*, a.rowid
           FROM ventas_digitadas_fija_auto a
          WHERE a.procesado IS NULL
            AND a.venta_cruzada IS NULL;
   
      nm_existe    NUMBER := 0;
      nm_existe_vf NUMBER := 0;
   
   BEGIN
      nm_error     := 0;
      vc_resultado := 'OK';
   
      FOR i IN c
      LOOP
         BEGIN
            --Buscar si es venta nueva, en la misma tabla
            SELECT COUNT(*)
              INTO nm_existe
              FROM ventas_digitadas_fija_auto a
             WHERE TRIM(a.cvacct) = TRIM(i.cvacct)
               AND a.venta_cruzada = 'NO';
            ---
            IF nm_existe > 0 THEN
               UPDATE ventas_digitadas_fija_auto a
                  SET a.venta_cruzada = 'SI'
                WHERE a.rowid = i.rowid
                  AND a.venta_cruzada IS NULL;
            ELSE
               --Buscar en Ventas Digitadas Fija en la tabla consolidada
               SELECT COUNT(*)
                 INTO nm_existe_vf
                 FROM ventas_digitadas_fija a
                WHERE TRIM(a.cvacct) = TRIM(i.cvacct)
                  AND a.cvayco <> i.cvayco
                  AND a.cvamco <> i.cvamco;
            
               IF nm_existe_vf > 0 THEN
                  UPDATE ventas_digitadas_fija_auto a
                     SET a.venta_cruzada = 'SI'
                   WHERE a.rowid = i.rowid
                     AND a.venta_cruzada IS NULL;
               ELSE
                  UPDATE ventas_digitadas_fija_auto a
                     SET a.venta_cruzada = 'NO'
                   WHERE a.rowid = i.rowid
                     AND a.venta_cruzada IS NULL;
               END IF;
            
            END IF;
         
            COMMIT;
         EXCEPTION
            WHEN OTHERS THEN
               vc_resultado := 'Error' || SQLERRM;
               nm_error     := SQLCODE;
         END;
      END LOOP;
   END validaventa_cruzada;

   FUNCTION fn_valida_ciudad_riesgosa(vc_nodo IN VARCHAR2) RETURN VARCHAR2 IS
      vc_resultado VARCHAR2(5);
      nm_cantidad  NUMBER := 0;
   
   BEGIN
      vc_resultado := 'OK';
   
      SELECT COUNT(*)
        INTO nm_cantidad
        FROM nodo_rr p
       WHERE p.comunidad = vc_nodo
         AND p.ciudad_riesgosa = 'SI';
   
      IF nm_cantidad > 0 THEN
         vc_resultado := 'SI';
      ELSE
         vc_resultado := 'NO';
      END IF;
      RETURN vc_resultado;
   EXCEPTION
      WHEN OTHERS THEN
         vc_resultado := 'NO';
         RETURN vc_resultado;
   END fn_valida_ciudad_riesgosa;

   PROCEDURE validardistribuidores(p_dia           IN NUMBER,
                                   p_cur_resultado OUT SYS_REFCURSOR,
                                   p_nm_resp       OUT NUMBER,
                                   p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT a.cvagvd, COUNT(*) cantidad
           FROM ventas_digitadas_fija_auto a
          WHERE a.cvaca1 = 'DISTRIBUIDORES'
            AND a.venta_cruzada = 'NO'
            AND a.incumplimiento = 'SI'
            AND to_date(a.fecha_dig, 'dd/mm/yyyy') >=
                to_date(to_char(SYSDATE - p_dia, 'dd/mm/yyyy'), 'dd/mm/yyyy')
          GROUP BY a.cvagvd
          ORDER BY cantidad DESC;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al buscar los distribuidores : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END validardistribuidores;

   PROCEDURE ventassinvalidacion(p_dia           IN NUMBER,
                                 p_distribuidor  IN VARCHAR2,
                                 p_cur_resultado OUT SYS_REFCURSOR,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT a.cvacct, a.cvatid, a.cvanid, a.fecha_dig, a.venta_cruzada,
                a.herramienta_aprobacion, a.incumplimiento, a.razon,
                a.ciudad_riesgosa, a.cvaccd, a.observacion, a.dth
           FROM ventas_digitadas_fija_auto a
          WHERE a.cvaca1 = 'DISTRIBUIDORES'
            AND a.venta_cruzada = 'NO'
            AND a.incumplimiento = 'SI'
            AND a.cvatyp NOT IN ('PY')
            AND to_date(a.fecha_dig, 'dd/mm/yyyy') >=
                to_date(to_char(SYSDATE - p_dia, 'dd/mm/yyyy'), 'dd/mm/yyyy')
            AND a.cvagvd = p_distribuidor;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al buscar los distribuidores : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END ventassinvalidacion;

   PROCEDURE buscarcorreodis_anterior(p_distribuidor IN VARCHAR2,
                                      p_correo       OUT VARCHAR2,
                                      p_archivo      OUT VARCHAR2,
                                      p_nm_resp      OUT NUMBER,
                                      p_vc_resp      OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      BEGIN
         SELECT REPLACE(REPLACE(a.mail, chr(35), ''), ',', ';'), a.archivo
           INTO p_correo, p_archivo
           FROM mail_agentes a
          WHERE upper(a.agente) = upper(p_distribuidor);
      EXCEPTION
         WHEN no_data_found THEN
            SELECT REPLACE(REPLACE(a.mail, chr(35), ''), ',', ''), a.archivo
              INTO p_correo, p_archivo
              FROM mail_agentes a
             WHERE upper(a.agente) LIKE
                   '%' || substr(upper(p_distribuidor), 0,
                                 instr(p_distribuidor, ' ')) || '%';
      END;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := -1203;
         p_vc_resp := 'Error al buscar correo del distribuidor : ' ||
                      SQLERRM;
         p_correo  := NULL;
         p_archivo := NULL;
   END buscarcorreodis_anterior;

   PROCEDURE buscarcorreodis(p_distribuidor IN VARCHAR2,
                             p_correo       OUT VARCHAR2,
                             p_archivo      OUT VARCHAR2,
                             p_nm_resp      OUT NUMBER,
                             p_vc_resp      OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      BEGIN
         SELECT a.mail, a.archivo
           INTO p_correo, p_archivo
           FROM mail_agentes a
          WHERE upper(a.agente) = upper(REPLACE(p_distribuidor, '-', ''));
      EXCEPTION
         WHEN no_data_found THEN
            SELECT a.mail, a.archivo
              INTO p_correo, p_archivo
              FROM mail_agentes a
             WHERE upper(a.agente) LIKE
                   '%' || TRIM(substr(upper(p_distribuidor), 0,
                                      instr(p_distribuidor, ' '))) || '%';
      END;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := -1203;
         p_vc_resp := 'Error al buscar correo del distribuidor : ' ||
                      SQLERRM;
         p_correo  := NULL;
         p_archivo := NULL;
   END buscarcorreodis;

   FUNCTION fn_paquete_pg(vc_cuenta IN VARCHAR2) RETURN VARCHAR2 IS
      vc_resultado VARCHAR2(100);
      nm_cantidad  NUMBER := 0;
      vc_voz       VARCHAR2(50);
      vc_internet  VARCHAR2(50);
      vc_tel       VARCHAR2(50);
   
   BEGIN
      vc_resultado := NULL;
   
      BEGIN
      
         SELECT decode(p.producto, 'TELEVISION', 'TV', 'TV')
           INTO vc_tel
           FROM ventas_digitadas_fija_auto p
          WHERE p.cvacct = vc_cuenta
            AND p.producto IN ('TELEVISION', '@DTH', 'DTH')
            AND rownum = 1;
      
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
      END;
      BEGIN
         SELECT decode(p.producto, 'INTERNET', '@', '@')
           INTO vc_internet
           FROM ventas_digitadas_fija_auto p
          WHERE p.cvacct = vc_cuenta
            AND p.producto IN ('INTERNET', '@DTH')
            AND rownum = 1;
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
      END;
      BEGIN
      
         SELECT decode(p.producto, 'TELEFONO', 'VOZ')
           INTO vc_voz
           FROM ventas_digitadas_fija_auto p
          WHERE p.cvacct = vc_cuenta
            AND p.producto = 'TELEFONO'
            AND rownum = 1;
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
      END;
      --TV+@+VOZ
      IF vc_tel IS NOT NULL THEN
         vc_resultado := vc_tel;
      END IF;
      IF vc_internet IS NOT NULL THEN
         vc_resultado := vc_resultado || '+' || vc_internet;
      END IF;
      IF vc_voz IS NOT NULL THEN
         vc_resultado := vc_resultado || '+' || vc_voz;
      END IF;
   
      RETURN vc_resultado; --substr(vc_resultado, 2, length(vc_resultado));
   EXCEPTION
      WHEN OTHERS THEN
         RETURN NULL;
   END fn_paquete_pg;

   PROCEDURE ventas_tmk_inbound(p_dia           IN NUMBER,
                                p_cur_resultado OUT SYS_REFCURSOR,
                                p_nm_resp       OUT NUMBER,
                                p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
      
         SELECT a.cvatid, a.cvanid
           FROM ventas_digitadas_fija_auto a
          WHERE 1 = 1
            AND a.incumplimiento = 'SI'
            AND a.cvamco IN ('3', '4')
            AND a.venta_cruzada = 'NO'
            AND a.cvaca2 NOT LIKE '%OUT%'
            AND a.cvanid IS NOT NULL;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al buscar cliente de ventas inbound : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END ventas_tmk_inbound;

END reporte_digitada_proceso_pkg;
/

