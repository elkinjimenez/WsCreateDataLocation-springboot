create PROCEDURE CONSULTA_ALARMA(cursorAlarma out SYS_REFCURSOR) AS
BEGIN
  OPEN cursorAlarma FOR
    SELECT distinct c.custcode CUSTCODE,
           c.CO_ID CO_ID,
           c.fecregis FECHA_REGISTRO,
           TO_CHAR(SYSDATE, 'dd/mm/yyyy') REPORTE,
           a.consecutivo
      FROM alarma_rta_pom a
      LEFT JOIN alarma_mensajes b
        ON a.consecutivo = b.consecutivo
      LEFT JOIN ventas_movil c
        ON b.documento = c.numero_doc
     WHERE c.Resultado_Biometria = 'NO'
       AND c.Resultado_OTP = 'NO'
       AND a.m_movil_no_confirma = '2';
END;
/

