create view V_EXTRAE_CDR_SRT_FO as
select "SENTENCIA" from (
select 'INSERT INTO TMP_CDR_SRT_FO (
  Select t.*,'||Chr(39)||Chr(39)||','||Chr(39)||Chr(39)||'  from cdr_car_mas_SRT t
  WHERE T.secuencia_cdr > '||Chr(39)||C.SERIAL_NUMBER||Chr(39)||');' as sentencia
from LOG_CARGUES_CDR_srt C
WHERE c.FECHA_CARGUE = (SELECT MAX(m.FECHA_CARGUE) FROM LOG_CARGUES_CDR_SRT m )
)
/

