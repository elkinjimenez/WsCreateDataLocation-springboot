create PROCEDURE proc_asesores_subex_hfc
IS
CURSOR c_tmp_datos IS

select *   from asesores a  ;

CONTADOR NUMBER;
cnt_loop number;

begin
--update  suscriptores_subex_hfc s
--set s.codIGO_vendedor = '';

/*commit;

update  suscriptores_subex_hfc s
set s.nombre_asesor = '';

commit;


update  suscriptores_subex_hfc s
set s.canal_venta = '';

commit;

update  suscriptores_subex_hfc s
set s.canal_venta1 = '';

commit;

update  suscriptores_subex_hfc s
set s.especialista = '';

commit;
*/
contador:= 0;
cnt_loop:= 0;



  FOR v_datos_sus IN c_tmp_datos
  LOOP
      cnt_loop:=Cnt_loop+1;
  
       UPDATE suscriptores_subex_hfc s
     SET  --s.codIGO_vendedor = v_datos_sus.COD_VENDEDOR,
          S.nombre_asesor = v_datos_sus.cvaase,
          canal_VENTA = v_datos_sus.CANAL,
          canal_VENTA1 = v_datos_sus.CANAL2,
          ESPECIALISTA = v_datos_sus.gv_ESPECIALISTA
     where s.codigo_vendedor = v_datos_sus.cvadlr
         and S.nombre_asesor is null ;

 

 IF cnt_loop=200 THEN
         COMMIT;
         cnt_loop:=0;
      END IF;

  END LOOP;


  commit;


END;
/

