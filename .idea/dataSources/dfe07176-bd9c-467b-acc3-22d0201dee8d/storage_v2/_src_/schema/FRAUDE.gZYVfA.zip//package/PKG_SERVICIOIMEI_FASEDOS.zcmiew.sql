create PACKAGE PKG_SERVICIOIMEI_FASEDOS
  AS

  -----------------------------------------------------------------------------------------------------
  -- OBJETIVO: Lista las macaras de biometria pertenecientes a los cliente  de claro
  -- PARÁMETROS DE SALIDA:
  --            pCodigo:  Codigo de respuestra del proceso de ejecucion del procedimiento
  --            pDescripcion: Descripcion de respuestra del proceso de ejecucion del procedimiento
  -- FECHA:                10/10/2018
  -- REALIZADO POR:        Hayder Garcia Jimnez
  ---------------------------------------------------------------------------------------------------

    PROCEDURE REQ27NET_MAC_BIOMETRICA
    (
       pCodigo OUT NUMBER,
       pDescripcion OUT VARCHAR2,
       Dataset OUT SYS_REFCURSOR
    );

  -----------------------------------------------------------------------------------------------------
  -- OBJETIVO: Permite actualizar el campo ENVIO de la tabla TBL_MAC_CARGADA_ENVIADO
  -- PARÁMETROS DE SALIDA:
  --            pCodigo:  Codigo de respuestra del proceso de ejecucion del procedimiento
  --            pDescripcion: Descripcion de respuestra del proceso de ejecucion del procedimiento
  -- FECHA:                11/10/2018
  -- REALIZADO POR:        Hayder Garcia Jimnez
  ---------------------------------------------------------------------------------------------------

PROCEDURE REQ27NET_CRUP_ENVIO
    (
       pValor1 IN VARCHAR2, 
       pValor2 IN VARCHAR2,
       pValor3 IN VARCHAR2,    
       pOpcion In VARCHAR2,              
       pCodigo OUT NUMBER,
       pDescripcion OUT VARCHAR2
    );
   END;
/

