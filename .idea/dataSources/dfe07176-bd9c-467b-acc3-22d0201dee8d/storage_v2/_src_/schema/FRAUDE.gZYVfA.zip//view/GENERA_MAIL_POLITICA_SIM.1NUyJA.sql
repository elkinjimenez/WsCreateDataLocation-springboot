create view GENERA_MAIL_POLITICA_SIM as
select "SENTENCIA" from (
select
'send-mailmessage -to '|| m.mail || ' -from "carlos.ramirez.r@claro.com.co" -cc "maria.lozanou@claro.com.co", "carlos.ramirez.r@claro.com.co" -subject "TRAMITES CAMBIO DE SIM CLIENTES CYG CIRCULAR 2016-GSDI01-S291994-2" -Attachments "D:\CAMBIO_SIM\2016-GSDI01-S291994-2 Cambio SIM 2.pdf" -body "Cordial saludo,  apreciado distribuidor '||m.distribuidor||'. El cambio de Sim Card, es un tramite que a simple vista parece no tener ningún riesgo.  A través de la SIM se tiene acceso, no solamente a el plan de Datos y/o voz, sino a un sinnúmero de Apps (bancarias y no bancarias) y servicios en los que el cliente maneja información confidencial. Al entregar una SIM activa a un tercero que se esta haciendo pasar por un cliente, estamos colocando en riesgo la información del cliente. Por esto es necesario, realizar correctamente las validaciones documentales y de identidad, asegurando que la persona que esta reclamando la SIM, sea quien dice ser y no un tercero en nombre de ella y cumplir con los requisitos documentales para el trámite de cambio de SIM. El realizar nuestro trabajo a conciencia nos evitara ser objeto de investigaciones y penalizaciones. Cordialmente Equipo de Prevencion Fraude CLARO." -smtpServer outlook.co.attla.corp
'as sentencia
from mail_distribuidores m
ORDER BY distribuidor asc
)
/

