create package body utilitario is

  FUNCTION split_fnc(p_vc_cadena    VARCHAR2,
                    p_nm_element   INTEGER,
                    p_vc_separator VARCHAR2) RETURN VARCHAR2 IS
    vc_cadena VARCHAR2(32767);
  BEGIN 
    vc_cadena := p_vc_cadena || p_vc_separator;
    FOR i IN 1 .. p_nm_element - 1 LOOP
      vc_cadena := substr(vc_cadena, instr(vc_cadena, p_vc_separator) + 1);
    END LOOP;
    RETURN substr(vc_cadena, 1, instr(vc_cadena, p_vc_separator) - 1);
  END split_fnc;
  
end utilitario;
/

