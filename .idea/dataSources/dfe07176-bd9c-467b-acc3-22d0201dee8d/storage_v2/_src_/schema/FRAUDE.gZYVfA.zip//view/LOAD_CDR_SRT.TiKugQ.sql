create view LOAD_CDR_SRT as
select "SENTENCIA" from (
select
'sqlldr  fraude/fraude@prufac.world control=D:\CDR_SRT\JOBS\HFC\load_CDR_por_trafico.ctl data=D:\CDR_SRT\JOBS\HFC\'||t.nombre_archivo||' bad=D:\CDR_SRT\JOBS\HFC\bad\'||t.nombre_archivo||'.bad log=D:\CDR_SRT\JOBS\HFC\logs\'||t.nombre_archivo||'.log errors=10000'
as sentencia
from name_file_SRT t where t.flag_cargue = 'S'
)
/

