create view V_BAJAR_CDR_SRT as
select "SENTENCIA" from (
select
'open cmartine:Claro2016@10.244.186.49:22
cd /opt/srt_mnt11/srtcol/SRT01/ENTRADAS/HWNC/INPDONE
lcd D:\cargues\
get '||s.nombre_archivo||'
close
'as sentencia
from log_cargues_ss s where s.flag_cargue = 'S'
ORDER BY nombre_archivo desc
)
/

