create PROCEDURE proc_TRASPONER
IS
CURSOR c_tmp_datos IS
select *
  from TMP_filas t
 ;



CONTADOR NUMBER;
cnt_loop number;

begin
delete TMP_traspuesta;
commit;


commit;
contador:= 0;
cnt_loop:= 0;



  FOR v_datos_sus IN c_tmp_datos
  LOOP
      cnt_loop:=Cnt_loop+1;
  SELECT COUNT(*)
  INTO CONTADOR
  FROM TMP_traspuesta t
  WHERE t.codigo_cliente_cuenta = V_datos_sus.codigo_cliente_cuenta
  ;

  IF CONTADOR >0  then

     UPDATE TMP_traspuesta s
     SET  datos  =  datos ||', '|| v_datos_sus.datos
      where s.codigo_cliente_cuenta = V_datos_sus.codigo_cliente_cuenta;

  ELSE
       INSERT INTO TMP_traspuesta (
                  codigo_cliente_cuenta,
                  datos
      )
      VALUES
      (
                  v_datos_sus.codigo_cliente_cuenta,
                  v_datos_sus.datos
      );

  end if;


 IF cnt_loop=200 THEN
         COMMIT;
         cnt_loop:=0;
      END IF;

  END LOOP;


  commit;


END;
/

