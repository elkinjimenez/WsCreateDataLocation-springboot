create view LOAD_CDR_POR_TRAFICO as
select "SENTENCIA" from (
select
'sqlldr  fraude/fraude@prufac.world control=d:\FRAUDE_TMX_COL\jobs\load_CDR_por_trafico.ctl data=d:\FRAUDE_TMX_COL\'||t.nombre_archivo||' bad=d:\FRAUDE_TMX_COL\bad\'||t.nombre_archivo||'.bad log=d:\FRAUDE_TMX_COL\logs\'||t.nombre_archivo||'.log errors=10000' 
as sentencia
from name_file t where t.flag_cargue = 'S'
)
/

