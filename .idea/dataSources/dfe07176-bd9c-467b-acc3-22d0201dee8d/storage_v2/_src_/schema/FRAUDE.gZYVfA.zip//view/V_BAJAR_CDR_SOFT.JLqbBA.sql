create view V_BAJAR_CDR_SOFT as
select "SENTENCIA" from (
select
'get '||substr(t.nombre_archivo,5,13)||a.flag_cargue||'
' as sentencia
from nombres_arch_ss t, ARCHIVOS_CARGADOS_SS A
WHERE T.NOMBRE_ARCHIVO = A.NOMBRE_ARCHIVO(+)
AND A.FECHA_CARGUE IS NULL
ORDER BY t.nombre_archivo asc
)
/

