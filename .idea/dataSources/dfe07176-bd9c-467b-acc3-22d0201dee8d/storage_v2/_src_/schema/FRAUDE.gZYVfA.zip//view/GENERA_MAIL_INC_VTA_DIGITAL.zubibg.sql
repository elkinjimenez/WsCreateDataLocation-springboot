create view GENERA_MAIL_INC_VTA_DIGITAL as
select "SENTENCIA" from (
select
'send-mailmessage -to '|| m.email || ' -from "carlos.ramirez.r@claro.com.co" -cc  "nayibe.salcedo@claro.com.co", "eduard.granados@claro.com.co", "controlcomercial@comcel.com.co" -subject "PRESUNTOS INCUMPLIMIENTOS VENTA DIGITAL - BIOMETRIA" -Attachments "D:\BIOMETRIA\REPORTE\'|| M.NOMBRE_ARCHIVO||'.csv" -body "Cordial saludo,  En el archivo adjunto se detallan las Biometrias autorizadas que NO se convirtieron en ventas digitales del distribuidor '||m.nombre_distribuidor||'. Esto ha obstaculizadola implementación del mecanismo denominado VENTA DIGITAL. Por favor asegurar el uso de Biometria y de venta Digital de acuerdo a las diferentes circulares emitidas por COMCEL. Agradecemos que exponga los motivos del presunto incumplimiento y/o proceda a dar cumplimiento a las directrices en la compañía, so pena de hacerse acreedor de las penalidades indicadas en el contrato de DISTRIBUCION. Por favor responder exclusivamente al e-mail controlcomercial@comcel.com.co. " -smtpServer outlook.co.attla.corp
'as sentencia
from EMAIL_DISTR_BIOMETRIA m
ORDER BY m.nombre_distribuidor asc
)
/

