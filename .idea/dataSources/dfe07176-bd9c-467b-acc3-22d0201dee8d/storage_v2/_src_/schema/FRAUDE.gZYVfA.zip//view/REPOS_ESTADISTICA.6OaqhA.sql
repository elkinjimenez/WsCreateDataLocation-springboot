create view REPOS_ESTADISTICA as
select r.cod_usuario,
       SUM(R.VR_EQUIPO) total_ventas,
       round((SUM(R.VR_EQUIPO) / count(*)), 0) promedio,
       count(*) cantidad_e
  from repos_diario_repo R
 where 1 = 1
   AND R.CODIGO_DISTRIBUIDOR LIKE 'C%'
   and r.documento not in (SELECT I.NRO_DOCUMENTO FROM GPC_VPC_VIP I)
   AND R.CODDISTRI NOT IN (SELECT COD_USUARIO FROM REPOS_USU_DOMICILIO)
   and r.biometria = 'NO'
   AND R.DOCUMENTO NOT LIKE '8%'
 GROUP BY r.cod_usuario
having count(*) > 5
 order by round((SUM(R.VR_EQUIPO) / count(*)), 0) desc, count(*) asc
/

