create PROCEDURE proc_act_vendedor_subex_hfc
IS
CURSOR c_tmp_datos IS

select distinct v.cvacct cuenta,
                trim(v.cvadlr) cod_vendedor,
                trim(v.cvaase) nombre_asesor,
                trim(v.canal) canal,
                trim(v.canal2) canal2,
                trim(v.gv_especialista) especialista
--                TRIM(v.d_und_gestion)
  from ventas_hfc v
 where cvayco || cvamco || cvadco =
       (select min(v1.cvayco || v1.cvamco || v1.cvadco)
          from ventas_hfc v1
         where v1.cvacct = v.cvacct
         group by v1.cvacct);

--CONTADOR NUMBER;
cnt_loop number;

begin

commit;


--contador:= 0;
cnt_loop:= 0;



  FOR v_datos_sus IN c_tmp_datos
  LOOP
      cnt_loop:=Cnt_loop+1;


     UPDATE suscriptores_subex_hfc s
     SET  s.codIGO_vendedor = v_datos_sus.COD_VENDEDOR
     where s.cuenta = v_datos_sus.cuenta
     and (trim(s.Codigo_Vendedor) in ('9999') or s.Codigo_Vendedor is null);


 IF cnt_loop=200 THEN
         COMMIT;
         cnt_loop:=0;
      END IF;

  END LOOP;


  commit;


END;
/

