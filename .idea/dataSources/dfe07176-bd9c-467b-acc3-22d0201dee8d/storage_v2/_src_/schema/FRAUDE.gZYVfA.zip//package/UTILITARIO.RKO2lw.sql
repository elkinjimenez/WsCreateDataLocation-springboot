create package utilitario is

  FUNCTION split_fnc(p_vc_cadena    VARCHAR2,
                    p_nm_element   INTEGER,
                    p_vc_separator VARCHAR2) RETURN VARCHAR2;

end utilitario;
/

