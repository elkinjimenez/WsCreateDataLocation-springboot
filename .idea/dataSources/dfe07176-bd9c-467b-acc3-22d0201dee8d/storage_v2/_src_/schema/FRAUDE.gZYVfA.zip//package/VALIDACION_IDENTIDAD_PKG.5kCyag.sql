create PACKAGE validacion_identidad_pkg IS

   -- Author  : CARLOS.RAMIREZ.R
   -- Created : 08/05/2019 02:07:51 p.m.
   -- Purpose : 

   FUNCTION fnc_cantidad_dias(vc_dias IN VARCHAR2) RETURN NUMBER;

   PROCEDURE valida_documento(vc_tipo_doc         IN VARCHAR2,
                              vc_nm_doc           IN VARCHAR2,
                              vc_fecha_tramite    IN VARCHAR2,
                              vc_valido           OUT VARCHAR2,
                              vc_herramienta      OUT VARCHAR2,
                              vc_fecha_validacion OUT VARCHAR2);

   PROCEDURE valida_biometria(vc_nm_doc           IN VARCHAR2,
                              vc_fecha_tramite    IN VARCHAR2,
                              vc_valido           OUT VARCHAR2,
                              vc_fecha_validacion OUT VARCHAR2,
                              vc_error            OUT VARCHAR2);

   PROCEDURE valida_evidente(vc_nm_doc           IN VARCHAR2,
                             vc_fecha_tramite    IN VARCHAR2,
                             vc_valido           OUT VARCHAR2,
                             vc_fecha_validacion OUT VARCHAR2,
                             vc_error            OUT VARCHAR2);

   PROCEDURE valida_idvision(vc_nm_doc           IN VARCHAR2,
                             vc_fecha_tramite    IN VARCHAR2,
                             vc_valido           OUT VARCHAR2,
                             vc_fecha_validacion OUT VARCHAR2,
                             vc_error            OUT VARCHAR2);

   PROCEDURE valida_biometria_movil(vc_nm_doc           IN VARCHAR2,
                                    vc_fecha_tramite    IN VARCHAR2,
                                    vc_valido           OUT VARCHAR2,
                                    vc_fecha_validacion OUT VARCHAR2,
                                    vc_error            OUT VARCHAR2);

   PROCEDURE valida_evidente_movil(vc_nm_doc           IN VARCHAR2,
                                   vc_fecha_tramite    IN VARCHAR2,
                                   vc_valido           OUT VARCHAR2,
                                   vc_fecha_validacion OUT VARCHAR2,
                                   vc_error            OUT VARCHAR2);

   PROCEDURE valida_idvision_movil(vc_nm_doc           IN VARCHAR2,
                                   vc_fecha_tramite    IN VARCHAR2,
                                   vc_valido           OUT VARCHAR2,
                                   vc_fecha_validacion OUT VARCHAR2,
                                   vc_error            OUT VARCHAR2);

   FUNCTION fn_valida_biometria_movil(vc_nm_doc        IN VARCHAR2,
                                      vc_fecha_tramite IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION fnc_idvision_consecutivo(vc_consecutivo IN VARCHAR2)
      RETURN VARCHAR;
END validacion_identidad_pkg;
/

