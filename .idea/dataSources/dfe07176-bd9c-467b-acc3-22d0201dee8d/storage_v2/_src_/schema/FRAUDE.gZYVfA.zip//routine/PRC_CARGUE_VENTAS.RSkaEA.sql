create PROCEDURE PRC_CARGUE_VENTAS (    P_CVAYCO IN VARCHAR2,
                                                   P_CVAMCO   IN VARCHAR2,
                                                   V_COD_ERROR OUT INT,
                                                   V_SMS_ERROR OUT VARCHAR2
                                                     ) AS
BEGIN
  
    IF P_CVAYCO IS NULL AND P_CVAMCO IS NULL THEN
        V_COD_ERROR:= 01;
        V_SMS_ERROR:=('Porfavor digitar P_CVAYCO y P_CVAMCO ');

       ELSE
         
        EXECUTE IMMEDIATE ('TRUNCATE TABLE TB_VENTAS_FIJA');

            INSERT INTO TB_VENTAS_FIJA  --Adicionar el esquema
                   (
                       cvacct,  cvatid,  cvanid,  cvafnm, cvapho,  cvabph,  cvatyp,  cvaccd,  cvacde,
                       cvadlr,  cvaase,  cvazon,  cvazng,  cvaca1,  cvaca2,  cvagvd,  cvade2,fecha_reporte,
                       fecha_dig,cvamco,dth,ciudad_riesgosa,venta_cruzada,incumplimiento,herramienta_aprobacion
                    )
         --EXTRACCION VENTAMES ACTUAL
         SELECT
               a.cvacct AS NRO_CUENTA,
               a.cvatid,
               a.cvanid,
               a.cvafnm || ' ' || a.cvalnm nombre,
               a.cvapho,
               a.cvabph,
               a.cvatyp,
               a.cvaccd,
               a.cvacde,
               a.cvadlr,
               a.cvaase,
               a.cvazon,
               a.cvazng,
               a.cvaca1,
               a.cvaca2,
               a.cvagvd,
               a.cvade2,
               a.fecha_reporte,
               a.fecha_dig,
               a.cvamco,
               a.dth,
               a.ciudad_riesgosa,
               a.venta_cruzada,
               a.incumplimiento,
               a.herramienta_aprobacion

           FROM  ventas_digitadas_fija_auto a 
                 WHERE a.venta_cruzada LIKE 'NO'
                 AND a.cvayco = P_CVAYCO
                 AND a.cvamco = P_CVAMCO
                 AND a.cvacct IS NOT NULL
                 AND a.herramienta_aprobacion LIKE 'NINGUNO'
                 ORDER BY a.fecha_digitacion;
            
            COMMIT;
                    V_COD_ERROR:= 02;
                    V_SMS_ERROR:=('Se genero el insert en la tabla TB_VENTAS_FIJA ');
    END IF;

END PRC_CARGUE_VENTAS;
/

