create PACKAGE ctr_portaciones_pkg IS

   -- Author  : ICM0613A
   -- Created : 11/09/2019 5:54:50 p. m.
   -- Purpose : Paquete que procesa los mensajes de texto que se enviaran por alarma
   PROCEDURE revisaPortacion (vc_min in ctr_camsim_sin_biometria.min%type,
                              vc_fecha_portacion in varchar2,
                              vc_resultado OUT VARCHAR2,
                              nm_error    OUT NUMBER);
END ctr_portaciones_pkg;
/

