create PROCEDURE hola_mundo
AS
BEGIN
htp.htmlopen; -- genera <HTML>
htp.headopen; -- genera <HEAD>
htp.title('Hola mundo'); -- genera <TITLE>Hola mundo</TITLE>
htp.headclose; -- genera </HEAD>
htp.bodyopen; -- genera <BODY>
htp.header(1, 'Hola mundo'); -- genera <H1>Hola mundo</H1>
htp.htmlclose; -- genera </HTML>
END;

/

