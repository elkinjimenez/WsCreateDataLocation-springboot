create PACKAGE bloquear_masivo_rr_pkg IS

   -- Author  : CARLOS.RAMIREZ.R
   -- Created : 06/02/2020 02:07:51 p.m.
   -- Purpose : 
   

  PROCEDURE pr_docs_bloquear    (
                                 p_cur_resultado OUT SYS_REFCURSOR,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2);

    PROCEDURE pr_eliminar    ( p_nm_doc in varchar2,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2);
END bloquear_masivo_rr_pkg;
/

