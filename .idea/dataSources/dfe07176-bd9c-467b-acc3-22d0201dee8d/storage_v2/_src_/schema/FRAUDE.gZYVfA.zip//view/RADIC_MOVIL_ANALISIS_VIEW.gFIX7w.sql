create view RADIC_MOVIL_ANALISIS_VIEW as
select s."CONSECUTIVO",s."CUSTCODE",s."COD_COMENTARIO",s."COD_DIAGNOSTICO",s."DESC_DIAGNOSTICO",s."NOMBRE_ANALISTA",s."FECHA_RADICACION",s."TIPO_DOC_CLIENTE",s."NUMERO_DOC_CLIENTE",s."NOMBRE_CLIENTE",s."TIPO_CLIENTE",s."CO_ID",s."ESTADO",s."FECHA_ACTIVACION",s."FECHA_DESACTIVACION",s."CAUSAL",s."TMCODE",s."TMCODE_DESC",s."DEALER",s."COD_DISTRI",s."COD_DISTRI_NIT",s."COD_DISTRI_NAME",s."OBSERVACION",s."ACTIVA_USER",s."ACTIVA_CIUDAD",s."ACTIVA_MIN",s."ACTIVA_USER_HABILITADO",s."ACTIVA_DOC_BLOQUEADO",s."FECHA_EJE_PROCESO",s."APLICA_BLOQUEO_USER",b.consecutivo cons, b.biometria, b.evidente, b.idvision, b.otp
from radic_movil_data s
left join radic_movil_validacion_iden b
on s.consecutivo= b.consecutivo
order by s.fecha_eje_proceso
/

