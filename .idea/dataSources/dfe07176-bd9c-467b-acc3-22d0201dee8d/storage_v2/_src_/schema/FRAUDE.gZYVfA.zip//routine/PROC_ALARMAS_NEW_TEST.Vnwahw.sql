create procedure Proc_alarmas_new_TEST
is

CURSOR c_acum_CDR_completa IS
select a.ABONADO_A,                      
       a.ACUM_DURA_REAL  ,               
       a.ACUM_DURA_LIQUI  ,              
       a.ACUM_CANT_LLAM    ,             
       a.ACUM_DIAS          ,
       a.acum_valor,
       A.FECHA_MIN,
       A.FECHA_MAX,
       a.tipo_trafico,
       a.avg_ab_b_dif,
       A.DESTINOS_DIF,
       ROUND(a.acum_cant_llam/a.acum_dias) AS llamadas_prom_dia,
       ROUND(H.ACUM_CANT_LLAM/H.acum_dias) as Llamadas_prom_dia_historico,
       ROUND(a.acum_dura_liqui/a.acum_dias) as Minutos_prom_dia,
       ROUND(H.acum_dura_liqui/h.acum_dias) as Minutos_prom_dia_historico,
       ROUND((ROUND(a.acum_cant_llam/a.acum_dias)-ROUND(H.ACUM_CANT_LLAM/H.acum_dias))/ROUND(H.ACUM_CANT_LLAM/H.acum_dias)*100) as PORC_DESV_LLAM_RESP_HISTORICO,
       ROUND((ROUND(a.acum_dura_liqui/a.acum_dias)-ROUND(H.acum_dura_liqui/H.acum_dias))/ROUND(H.acum_dura_liqui/H.acum_dias)*100) as PORC_DESV_MIN_RESP_HISTORICO,
       ROUND(TO_NUMBER(SYSDATE - TO_DATE(SUBSTR(C.FECHA_ASIGNACION,1,10),'DD/MM/YYYY'))/12) AS MESES_DE_INSTALADO,
       ROUND(TO_NUMBER(H.ACUM_DIAS/12)) AS MESES_DE_CONSUMO,
       b.COD_DANE,       
       b.POBLACION      ,
       b.DEPTO,          
       b.OPERADOR       ,
       c.segmento,
--       C.cod_suca,
--       C.des_suca,
       c.enlace,
       C.IP,
       C.CODIGO_CLIENTE,
       c.nombre_cliente,
       C.NTDIDE,
       C.TIPDIDE,
       C.FECHA_ASIGNACION,
       C.PROMEDIO_FACTURACION,
       C.SALDO_ACTUAL,
       C.DIRCLI,
       c.plan_facturacion,
       g.fec_deteccion,
       g.dias_vigencia
from   cdr_acum_total a, pnn_series b, suscriptores c, LISTADO_GRISES G, CDR_HISTORICO H
where  a.abonado_a between b.serie_ini(+) and b.serie_fin(+) and  
       a.abonado_a = c.telefono8(+) and a.abonado_a=g.abonado(+)
       and a.tipo_trafico = h.tipo_trafico(+)
       AND A.ABONADO_A = H.ABONADO_A(+)
       and A.ABONADO_A NOT  IN (SELECT M.NUMERO FROM MAESTRA_BLANCOS M)
       and a.acum_dura_liqui>0 
       AND A.TIPO_TRAFICO IN (SELECT s.grupo FROM SERVICIOS_MONITOREO s WHERE s.monitoreo='SI');
--       and (c.des_cate = 'RESIDENCIAL' or c.des_cate = 'RESIDENCIALES')
--       AND (A.ACUM_DURA_REAL > H.CANT_MINUTOS OR A.ACUM_CANT_LLAM > H.CANT_LLAMADAS OR C.SAL_PEND > H.SALDO_PEND);

--      and substr(A.ABONADO_A,2,8) not in (SELECT dav_telef FROM davox) 
-- En esta parte se iba a incluior no tener en cuenta los abonados que tiene conevnios de VOZ Corporativa en Davox. 20/10/2006 pero era muy demorado                 
                  
r_consulta c_acum_CDR_completa%rowtype;


v_fec_gen_alarma            date;
v_cant_llamadas             number;
v_cant_minutos              number;
m_cant_llamadas             number;
m_cant_minutos              number;
v_saldo_pend                number;
v_fact_ven                  number;
v_tipo_comp                 number;
v_acum_dias                 number;
V_DIAS_VIGENCIA               NUMBER;
V_FECHA_DETECCION             DATE;

BEGIN


v_fec_gen_alarma:=sysdate;

Open c_acum_CDR_completa;

  Loop
  
    Fetch c_acum_CDR_completa into  r_consulta;
    exit when c_acum_CDR_completa%notfound;

-- Extraemos los umbrales
             
             BEGIN
           
                select k.cant_llamadas into v_cant_llamadas  from umbrales k
                where k.grupo=r_consulta.tipo_trafico;

                select K.cant_minutos into v_cant_minutos  from umbrales k
                where k.grupo=r_consulta.tipo_trafico;
                
              END;    

             
             
-- Incluimos en la tabla alarmas_new los abonados que superen los valores de cantidad de llamadas, minutos, saldo pendiente, categoria              
             
             IF r_consulta.fec_deteccion is null  OR  (SYSDATE-r_consulta.Fec_Deteccion) < r_consulta.Dias_Vigencia THEN
             
             if (R_CONSULTA.SEGMENTO LIKE 'PYME%' and ((r_consulta.acum_cant_llam/ r_consulta.acum_dias > v_cant_llamadas) or (r_consulta.ACUM_DURA_REAL /r_consulta.acum_dias  > v_CANT_MINUTOS)))
              or (R_CONSULTA.OPERADOR NOT IN ('TELMEX', 'TCB - TELEFONIA POR CABLE DE SANTAFE DE BOGOTA','TELEFONIA POR CABLE') and ((r_consulta.acum_cant_llam/r_consulta.acum_dias > v_cant_llamadas) or (r_consulta.ACUM_DURA_REAL/r_consulta.acum_dias > v_CANT_MINUTOS)))
              OR (R_CONSULTA.SEGMENTO IS NULL and ((r_consulta.acum_cant_llam/r_consulta.acum_dias > v_cant_llamadas) or (r_consulta.ACUM_DURA_REAL/r_consulta.acum_dias > v_CANT_MINUTOS))) then                             
             insert into alarmas_new (CODIGO_CLIENTE,
                                      enlace,
                                      ABONADO_A,
                                      ACUM_DURA_REAL,
                                      ACUM_DURA_LIQUI,
                                      ACUM_CANT_LLAM,
                                      avg_ab_b_dif,
                                      DESTINOS_DIF,
                                      PROM_MIN_DIARIO,
                                      PROM_LLAM_DIARIA,
                                      PROM_VALOR_DIARIO,
                                      PROM_MIN_DIARIO_HISTORICO,
                                      PROM_LLAM_DIARIA_HISTORICO,
                                      PORC_DESV_LLAM_RESP_HISTORICO,
                                      PORC_DESV_MIN_RESP_HISTORICO,
                                      MESES_DE_INSTALADO,
                                      MESES_DE_CONSUMO,
                                      TIPO_TRAFICO,
                                      ACUM_DIAS,
                                      OPERADOR,
                                      OPERADOR_NUESTRO,
                                      NOMBRE_CLIENTE,
                                      NTDIDE,
                                      TIPDIDE,
                                      FECHA_ASIGNACION,
                                      DIRECCION,
                                      SEGMENTO,
                                      PROMEDIO_FACTURACION,
                                      SALDO_ACTUAL,
                                      DES_SUBCATEGORIA,
                                      DESC_CATEGORIA,
                                      FV,
                                      POBLACION,
                                      DEPTO,
                                      FECHA_MIN_CONS,
                                      FECHA_MAX_CONS,
                                      FEC_GEN_ALARMA,
                                      IP,
                                      PLAN_FACTURACION,
                                      llamadas_hora_laboral,
                                      llamadas_hora_no_laboral
                                      )
                values (              r_consulta.CODIGO_CLIENTE,
                                      r_consulta.enlace,
                                      r_consulta.ABONADO_A,
                                      r_consulta.ACUM_DURA_REAL,
                                      r_consulta.ACUM_DURA_LIQUI,
                                      r_consulta.ACUM_CANT_LLAM,
                                      r_consulta.avg_ab_b_dif,
                                      r_consulta.destinos_dif,
                                      r_consulta.minutos_prom_dia,
                                      r_consulta.llamadas_prom_dia,
                                      round(r_consulta.acum_valor/r_consulta.acum_dias),
                                      R_CONSULTA.MINUTOS_PROM_DIA_HISTORICO,
                                      R_CONSULTA.LLAMADAS_PROM_DIA_HISTORICO,
                                      R_CONSULTA.PORC_DESV_LLAM_RESP_HISTORICO,
                                      R_CONSULTA.PORC_DESV_MIN_RESP_HISTORICO,
                                      R_CONSULTA.MESES_DE_INSTALADO,
                                      R_CONSULTA.MESES_DE_CONSUMO,
                                      r_consulta.TIPO_TRAFICO,
                                      r_consulta.ACUM_DIAS,
                                      r_consulta.OPERADOR,
                                      Decode(r_consulta.OPERADOR,'TELMEX','SI','TCB - TELEFONIA POR CABLE DE SANTAFE DE BOGOTA', 'SI','TELEFONIA POR CABLE','SI'),
                                      r_consulta.NOMBRE_CLIENTE,
                                      r_consulta.NTDIDE,
                                      r_consulta.TIPDIDE,
                                      r_consulta.FECHA_ASIGNACION,
                                      r_consulta.DIRCLI,
                                      r_consulta.SEGMENTO,
                                      ROUND(TO_NUMBER(r_consulta.PROMEDIO_FACTURACION)),
                                      ROUND(TO_NUMBER(r_consulta.SALDO_ACTUAL)),
                                      NULL,
                                      NULL,
                                      NULL,
                                      r_consulta.POBLACION,
                                      r_consulta.DEPTO,
                                      r_consulta.FECHA_MIN,
                                      r_consulta.FECHA_MAX,
                                      v_fec_gen_alarma,
                                      r_consulta.Ip,
                                      r_consulta.Plan_Facturacion,
                                      null,
                                      null
                                      );
             end if;
             END IF;
     commit;
       r_consulta:=null;   
     --  v_umbral:=0; v_diferencia:=0; v_porc_desv:=0; 
       
  end loop;
     
close c_acum_CDR_completa;


end;


/

