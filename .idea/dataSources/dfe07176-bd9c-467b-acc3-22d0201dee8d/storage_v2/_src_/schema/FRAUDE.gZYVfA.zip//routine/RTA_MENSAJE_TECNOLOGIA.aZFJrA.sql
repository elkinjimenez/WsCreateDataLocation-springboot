create function rta_mensaje_tecnologia (VC_reserva IN VARCHAR2)
  return varchar2 is
  Result varchar2(100);
begin
 SELECT DISTINCT  b.mensaje
 into Result
  FROM ventas_tecnologia_estadocero a, rta_whatsapp b
 WHERE a.idreserver=VC_reserva
   AND a.enviar_whastapp = b.telefono
   AND to_date(substr(a.reservedate, 0, 10), 'dd/mm/yy') <=
       to_date(substr(b.fecha_cargue, 0, 10), 'dd/mm/yy')
   and rownum='1'
  ;
  return(Result);
exception
  when others then
    return null;
end rta_mensaje_tecnologia;
/

