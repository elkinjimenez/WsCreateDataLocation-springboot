create package body bloquear_masivo_rr_pkg is

  PROCEDURE pr_docs_bloquear    (
                                 p_cur_resultado OUT SYS_REFCURSOR,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2) is
  begin
  
  
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT a.documento, a.nombre, a.causal
           FROM rr_bloqueo_masivo a
          where  rownum <=100000;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al buscar docs a bloquear  : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
  end pr_docs_bloquear;
  
    PROCEDURE pr_eliminar    ( p_nm_doc in varchar2,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2) is
  begin
  
  
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
    delete  rr_bloqueo_masivo a
    where a.documento=p_nm_doc ;
    
    commit;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al buscar docs a bloquear  : ' ||
                            SQLERRM;

  end pr_eliminar;
 

end bloquear_masivo_rr_pkg;
/

