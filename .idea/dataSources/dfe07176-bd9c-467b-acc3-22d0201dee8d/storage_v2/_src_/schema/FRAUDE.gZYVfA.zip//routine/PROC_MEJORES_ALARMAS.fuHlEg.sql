create procedure PROC_mejores_alarmas is

cursor  c_mejores_alarmas is
select B.*,
 ceil((b.avg_ab_b_dif/ b.acum_cant_llam)*100) as dispersion_abonados, 
 ceil((b.destinos_dif/b.acum_cant_llam)*100) as dispersion_ciudades, 
 ceil(( (b.acum_cant_llam-b.llamadas_hora_laboral)/b.acum_cant_llam)*100) as porc_llamadas_hora_laboral, 
 ceil(b.acum_dura_real/b.acum_cant_llam) as Duracion_promedio
from alarmas_new b;

v_alarmas c_mejores_alarmas%rowtype;

-- estas variables se usan para calcular la diferencia 
-- con relacion a su promedio.

v_cant_meses      number;
v_saldo_pend      number;
v_dif_dest        number;
v_dif_ciu        number;
v_porc_desv_llam  number;
v_porc_desv_min   number;
v_cant_llam       number;
v_cant_min        number;
tipo_alarma       varchar(500);
v_min_larga_dura  number;
v_DISPERSION      number;
V_DURACION_PROMEDIO      number;
V_RELACION_LLAM_HORA_LABORAL number;
V_umbral_llamadas_reorigina  number;
V_umbral_dispersion_ciudades number;
-- v_ip_clientes_libres         varchar(20);
-- v_codcli_numer_libres        varchar(20);
-- v_cliente_num_libres         varchar(100);

Begin 

delete mejores_alarmas;
commit;

-- Extraemos los umbrales

tipo_alarma := '';


Open c_mejores_alarmas;

loop

    Fetch c_mejores_alarmas into  v_alarmas;
    exit when c_mejores_alarmas%notfound;
    
    begin
    
          select k.cant_meses_consumo into v_cant_meses from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.saldo_pend into v_saldo_pend from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_abonadosb_dif into v_dif_dest from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_ciudades into v_dif_ciu  from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.porc_desv_llam_resp_histo into v_porc_desv_llam  from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.porc_desv_min_resp_histo into v_porc_desv_min from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.porc_desv_min_resp_histo          into v_porc_desv_min          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_llamadas          into v_cant_llam          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.cant_minutos          into v_cant_min          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select k.min_para_larga_dura          into v_min_larga_dura          from umbrales k
          WHERE K.GRUPO = v_alarmas.Tipo_Trafico
          AND K.SEGMENTO = V_ALARMAS.SEGMENTO;
          
          select R.DISPERSION_ABONADOS          into   v_DISPERSION        from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;

          
          select R.DURACION_PROMEDIO          into  V_DURACION_PROMEDIO         from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;

          
          select R.RELACION_LLAMA_HORA_LABORAL          into  V_RELACION_LLAM_HORA_LABORAL      from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;
          
          select R.CANT_LLAMADAS          into  V_umbral_llamadas_reorigina      from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;
          
          select R.DISPERSION_CIUDADES          into  V_umbral_dispersion_ciudades    from umbrales_REORIGINAMIENTO R
          WHERE R.GRUPO = v_alarmas.Tipo_Trafico;
          
          end;

-- Validamos Reoriginamiento Local + LE
   
   IF V_ALARMAS.TIPO_TRAFICO = 'LOCAL+LE' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO LOCAL,';
          END IF;                   
  END IF;       
                                
-- Validamos Reoriginamiento NACIONAL TERCEROS

   IF V_ALARMAS.TIPO_TRAFICO = 'LDN-TERCEROS' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades >= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO NACIONAL POR TERCEROS,';
          END IF;                   
  END IF;       

-- Validamos Reoriginamiento NACIONAL POR TELMEX

   IF V_ALARMAS.TIPO_TRAFICO = 'LDN-POR-TELMEX' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades >= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL <= V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO NACIONAL POR TELMEX,';
          END IF;                   
  END IF;       

-- Validamos Reoriginamiento HACIA MOVILES

   IF V_ALARMAS.TIPO_TRAFICO = 'MOVILES' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
--            and V_ALARMAS.Dispersion_Ciudades >= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL <=V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'REORIGINAMIENTO HACIA MOVILES,';
          END IF;                   
  END IF;   
   
-- Validamos TERCER PAIS POR TERCEROS

   IF V_ALARMAS.TIPO_TRAFICO = 'LDI-TERCEROS' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades <= V_umbral_dispersion_ciudades -- EN PORCENTAJE
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'TERCER PAIS POR TERCEROS,';
          END IF;                   
  END IF;       

-- Validamos TERCER PAIS POR TELMEX

   IF V_ALARMAS.TIPO_TRAFICO = 'LDI-POR-TELMEX' THEN
          if  v_alarmas.prom_llam_diaria >= V_umbral_llamadas_reorigina
              AND  v_alarmas.dispersion_abonados >= v_DISPERSION
              AND V_ALARMAS.DURACION_PROMEDIO >=  V_DURACION_PROMEDIO
              and V_ALARMAS.Dispersion_Ciudades <= V_umbral_dispersion_ciudades
              AND V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < V_RELACION_LLAM_HORA_LABORAL
              THEN 
              tipo_alarma := tipo_alarma||'TERCER PAIS POR TELMEX,';
          END IF;                   
  END IF;       


-- Validamos NUMEROS LIBRES CON CONSUMOS
   IF V_ALARMAS.OPERADOR = 'TELMEX' THEN
           IF V_ALARMAS.ENLACE IS NULL THEN
              tipo_alarma := tipo_alarma||'LIBRES CON CONSUMO,';
           END IF; 
   END IF;     
   
-- Validamos perfil reventa

 IF V_ALARMAS.TIPO_TRAFICO = 'MOVILES' THEN
          if  v_alarmas.prom_llam_diaria >= 10
              AND  v_alarmas.avg_ab_b_dif >= v_dif_dest
              AND V_ALARMAS.PROM_MIN_DIARIO >=  v_cant_min
              AND  V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL < 98
              THEN 
              tipo_alarma := tipo_alarma||'POSIBLE REVENTA MOVILES,';
          END IF;  
 END IF;       
 
  
  IF V_ALARMAS.OPERADOR_NUESTRO = 'SI' THEN
     tipo_alarma := tipo_alarma||'PROPIO,';
            if   (v_alarmas.Prom_Llam_Diaria) > v_cant_llam and v_alarmas.acum_dura_real > v_cant_min then 
                    tipo_alarma := tipo_alarma||'Muchas LLamadas,';
            if v_alarmas.fv > 0 then
            if v_alarmas.Meses_De_Instalado > v_cant_meses and v_alarmas.Saldo_Actual/ v_alarmas.fv > v_saldo_pend
            and v_alarmas.saldo_actual > 1.5*v_alarmas.promedio_facturacion then
            tipo_alarma:= tipo_alarma||'Riesgo de cartera, ';
            end if;
            end if;
            if v_alarmas.avg_ab_b_dif > v_dif_dest and v_alarmas.Meses_De_Instalado < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.destinos_dif > v_dif_ciu and v_alarmas.Meses_De_Instalado < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.Porc_Desv_Llam_Resp_Historico > v_porc_desv_llam or 
               v_alarmas.Porc_Desv_Min_Resp_Historico > v_porc_desv_min) and 
               v_alarmas.Meses_De_Instalado >= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  (v_alarmas.Meses_De_Instalado <= 1 or  v_alarmas.meses_de_consumo <=1) and v_alarmas.avg_ab_b_dif > 3
                and v_alarmas.tipo_trafico <> 'LOCAL+LE' then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
          
          else 
            tipo_alarma := tipo_alarma||'Duracion,';
-- Se elimina para sacar solo alarmas de Fraude. Sep 07 2007   
            if  V_ALARMAS.PROM_MIN_DIARIO / V_ALARMAS.PROM_LLAM_DIARIA > v_min_larga_dura  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
            
   END IF;
                   
       END IF;    

         IF V_ALARMAS.OPERADOR_NUESTRO IS NULL THEN
     tipo_alarma := tipo_alarma||'TERCEROS,';
            if   (v_alarmas.Prom_Llam_Diaria) > v_cant_llam and v_alarmas.acum_dura_real > v_cant_min then 
                    tipo_alarma := tipo_alarma||'Muchas LLamadas,';
            if v_alarmas.avg_ab_b_dif > v_dif_dest and v_alarmas.Meses_De_CONSUMO < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.destinos_dif > v_dif_ciu and v_alarmas.Meses_De_CONSUMO < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.Porc_Desv_Llam_Resp_Historico > v_porc_desv_llam or 
               v_alarmas.Porc_Desv_Min_Resp_Historico > v_porc_desv_min) and 
               v_alarmas.Meses_De_CONSUMO >= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  (v_alarmas.Meses_De_Instalado <= 1 or  v_alarmas.meses_de_consumo <=1)  and v_alarmas.avg_ab_b_dif > 3 then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
          
          else 
            tipo_alarma := tipo_alarma||'Duracion,';
-- Se elimina para sacar solo alarmas de Fraude. Sep 07 2007   
            if  V_ALARMAS.PROM_MIN_DIARIO / V_ALARMAS.PROM_LLAM_DIARIA > v_min_larga_dura  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
            
   END IF;
                   
       END IF;    

       
           
/*           if v_alarmas.cant_meses_consumo > v_cant_meses and v_alarmas.saldo_pend > v_saldo_pend then
            tipo_alarma:= tipo_alarma||'Riesgo de cartera, ';
            end if;
            if v_alarmas.prom_cant_ab_b > v_dif_dest and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.prom_cant_ciudades > v_dif_ciu and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.porc_desv_llamd_resp_histo > v_porc_desv_llam or v_alarmas.porc_desv_min_resp_histo > v_porc_desv_min) and v_alarmas.cant_meses_consumo <= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  v_alarmas.cant_meses_consumo = 1  and v_alarmas.prom_cant_ab_b > 3 then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            -- Se agrego en SEp 04 2007 este parametro para que alarmara lineas que no tienen ninguna llamada antes del periodo de monitoreo          
 
            if  v_alarmas.dias_consumo < 1  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            
          end if;  

                    
        END IF;
        
        if v_alarmas.operador_nuestro = 'NO' THEN
          tipo_alarma := 'OTRO OPERADOR,';
          if   (v_alarmas.acum_cant_llam / v_alarmas.acum_dias) > v_cant_llam then
            tipo_alarma := tipo_alarma||'Muchas LLamadas,';
            if v_alarmas.cant_meses_consumo > v_cant_meses and v_alarmas.saldo_pend > v_saldo_pend then
            tipo_alarma:= tipo_alarma||'Riesgo de cartera, ';
            end if;
            if v_alarmas.prom_cant_ab_b > v_dif_dest and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.prom_cant_ciudades > v_dif_ciu and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.porc_desv_llamd_resp_histo > v_porc_desv_llam or v_alarmas.porc_desv_min_resp_histo > v_porc_desv_min) and v_alarmas.cant_meses_consumo <= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  v_alarmas.cant_meses_consumo = 1 and v_alarmas.cant_meses_consumo = 1  and v_alarmas.prom_cant_ab_b > 3 then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            -- Se agrego en SEp 04 2007 este parametro para que alarmara lineas que no tienen ninguna llamada antes del periodo de monitoreo          
 
            if  v_alarmas.dias_consumo < 1  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
           
           else 
            tipo_alarma := tipo_alarma||'Duracion,';
/* Se elimina para sacar solo alarmas de Fraude. Sep 07 2007             
            if  (v_alarmas.acum_dura_real/ v_alarmas.acum_cant_llam) > v_min_larga_dura  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
*/
 /*           if v_alarmas.cant_meses_consumo > v_cant_meses and v_alarmas.saldo_pend > v_saldo_pend then
            tipo_alarma:= tipo_alarma||'Riesgo de cartera, ';
            end if;
            if v_alarmas.prom_cant_ab_b > v_dif_dest and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.prom_cant_ciudades > v_dif_ciu and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.porc_desv_llamd_resp_histo > v_porc_desv_llam or v_alarmas.porc_desv_min_resp_histo > v_porc_desv_min) and v_alarmas.cant_meses_consumo <= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  v_alarmas.cant_meses_consumo = 1  and v_alarmas.prom_cant_ab_b > 3 then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            -- Se agrego en SEp 04 2007 este parametro para que alarmara lineas que no tienen ninguna llamada antes del periodo de monitoreo          
 
            if  v_alarmas.dias_consumo < 1  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            
          end if;   
                     
        END IF;
        
        if v_alarmas.desc_categoria like ('COMERCIAL%') or v_alarmas.desc_categoria like ('NO%RESIDEN%') THEN
          tipo_alarma := 'COMERCIAL,';
          if   (v_alarmas.acum_cant_llam / v_alarmas.acum_dias) > v_cant_llam then
            tipo_alarma := tipo_alarma||'Muchas LLamadas,';
/* Se elimina para sacar solo alarmas de Fraude. Sep 07 2007           
            if v_alarmas.cant_meses_consumo > v_cant_meses and v_alarmas.saldo_pend > v_saldo_pend then
            tipo_alarma:= tipo_alarma||'Riesgo de cartera, ';
            end if;
*/
 /*           if v_alarmas.prom_cant_ab_b > v_dif_dest and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.prom_cant_ciudades > v_dif_ciu and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.porc_desv_llamd_resp_histo > v_porc_desv_llam or v_alarmas.porc_desv_min_resp_histo > v_porc_desv_min) and v_alarmas.cant_meses_consumo <= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  v_alarmas.cant_meses_consumo = 1  and v_alarmas.prom_cant_ab_b > 3  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            if  (v_alarmas.acum_dura_real/ v_alarmas.acum_dias)/ v_alarmas.acum_cant_llam > v_min_larga_dura and v_alarmas.cant_meses_consumo <=2  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
            -- Se agrego en SEp 04 2007 este parametro para que alarmara lineas que no tienen ninguna llamada antes del periodo de monitoreo          
 
            if  v_alarmas.dias_consumo < 1  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            
            else 
            tipo_alarma := tipo_alarma||'Duracion,';
            if  (v_alarmas.acum_dura_real/ v_alarmas.acum_cant_llam) > v_min_larga_dura  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
            if v_alarmas.cant_meses_consumo > v_cant_meses and v_alarmas.saldo_pend > v_saldo_pend then
            tipo_alarma:= tipo_alarma||'Riesgo de cartera, ';
            end if;
            if v_alarmas.prom_cant_ab_b > v_dif_dest and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.prom_cant_ciudades > v_dif_ciu and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.porc_desv_llamd_resp_histo > v_porc_desv_llam or v_alarmas.porc_desv_min_resp_histo > v_porc_desv_min) and v_alarmas.cant_meses_consumo <= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  v_alarmas.cant_meses_consumo = 1  and v_alarmas.prom_cant_ab_b > 3 then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            -- Se agrego en SEp 04 2007 este parametro para que alarmara lineas que no tienen ninguna llamada antes del periodo de monitoreo          
 
            if  v_alarmas.dias_consumo < 1  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            
          end if;
                 
        END IF;
        
        if v_alarmas.desc_categoria like ('TELESERVICIOS%') THEN
          tipo_alarma := 'TELESERVICIOS,';
          if   (v_alarmas.acum_cant_llam / v_alarmas.acum_dias) > v_cant_llam then
            tipo_alarma := tipo_alarma||'Muchas LLamadas,';
           
            if v_alarmas.prom_cant_ab_b > v_dif_dest and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchos abonados destino, ';
            end if;
            if v_alarmas.prom_cant_ciudades > v_dif_ciu and v_alarmas.cant_meses_consumo < v_cant_meses then
            tipo_alarma:= tipo_alarma||'Muchas ciudades destino, ';
            end if;
            if (v_alarmas.porc_desv_llamd_resp_histo > v_porc_desv_llam or v_alarmas.porc_desv_min_resp_histo > v_porc_desv_min) and v_alarmas.cant_meses_consumo <= v_cant_meses then
            tipo_alarma:= tipo_alarma||'Incremento a mas del doble en llamadas o minutos, ';
            end if;
            if  v_alarmas.cant_meses_consumo = 1  and v_alarmas.prom_cant_ab_b > 3  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            -- Se agrego en SEp 04 2007 este parametro para que alarmara lineas que no tienen ninguna llamada antes del periodo de monitoreo          
 
            if  v_alarmas.dias_consumo < 1  then
            tipo_alarma:= tipo_alarma||'Sin Historico, ';
            end if;
            if  (v_alarmas.acum_dura_real/ v_alarmas.acum_dias)/ v_alarmas.acum_cant_llam > v_min_larga_dura and v_alarmas.cant_meses_consumo <=2  then
            tipo_alarma:= tipo_alarma||'Larga duracion, ';
            end if;
                      
            
          end if;
                 
        END IF;
 */   
        
        if (tipo_alarma  IS NOT NULL 
             AND tipo_alarma NOT IN ('PROPIO,Muchas LLamadas,','PROPIO,Duracion,','TERCEROS,Muchas LLamadas,','TERCEROS,Duracion,')
             ) 
             THEN 
          
                insert into mejores_alarmas
                ( CODIGO_CLIENTE,
                  ENLACE,
                  ABONADO_A,
                  ACUM_DURA_REAL,
                  ACUM_DURA_LIQUI,
                  ACUM_CANT_LLAM,
                  AVG_AB_B_DIF,
                  PROM_MIN_DIARIO,
                  PROM_VALOR_DIARIO,
                  PROM_LLAM_DIARIA,
                  TIPO_TRAFICO,
                  ACUM_DIAS,
                  OPERADOR,
                  OPERADOR_NUESTRO,
                  NOMBRE_CLIENTE,
                  NTDIDE,
                  TIPDIDE,
                  FECHA_ASIGNACION,
                  DIRECCION,
                  SEGMENTO,
                  PROMEDIO_FACTURACION,
                  SALDO_ACTUAL,
                  DES_SUBCATEGORIA,
                  DESC_CATEGORIA,
                  FV,
                  POBLACION,
                  DEPTO,
                  FECHA_MIN_CONS,
                  FECHA_MAX_CONS,
                  FEC_GEN_ALARMA,
                  IP,
                  DESTINOS_DIF,
                  PROM_MIN_DIARIO_HISTORICO,
                  PROM_LLAM_DIARIA_HISTORICO,
                  PORC_DESV_LLAM_RESP_HISTORICO,
                  PORC_DESV_MIN_RESP_HISTORICO,
                  MESES_DE_INSTALADO,
                  MESES_DE_CONSUMO,
                  PLAN_FACTURACION,
                  LLAMADAS_HORA_LABORAL,
                  LLAMADAS_HORA_NO_LABORAL,
                  DISPERSION_ABONADOS,
                  DISPERSION_CIUDADES,
                  PORC_LLAMADAS_HORA_LABORAL,
                  DURACION_PROMEDIO,
                  TIPO_ALARMA
                  )
                values (V_ALARMAS.CODIGO_CLIENTE,
                        V_ALARMAS.ENLACE,
                        V_ALARMAS.ABONADO_A,
                        V_ALARMAS.ACUM_DURA_REAL,
                        V_ALARMAS.ACUM_DURA_LIQUI,
                        V_ALARMAS.ACUM_CANT_LLAM,
                        V_ALARMAS.AVG_AB_B_DIF,
                        V_ALARMAS.PROM_MIN_DIARIO,
                        V_ALARMAS.PROM_VALOR_DIARIO,
                        V_ALARMAS.PROM_LLAM_DIARIA,
                        V_ALARMAS.TIPO_TRAFICO,
                        V_ALARMAS.ACUM_DIAS,
                        V_ALARMAS.OPERADOR,
                        V_ALARMAS.OPERADOR_NUESTRO,
                        V_ALARMAS.NOMBRE_CLIENTE,
                        V_ALARMAS.NTDIDE,
                        V_ALARMAS.TIPDIDE,
                        V_ALARMAS.FECHA_ASIGNACION,
                        V_ALARMAS.DIRECCION,
                        V_ALARMAS.SEGMENTO,
                        V_ALARMAS.PROMEDIO_FACTURACION,
                        V_ALARMAS.SALDO_ACTUAL,
                        V_ALARMAS.DES_SUBCATEGORIA,
                        V_ALARMAS.DESC_CATEGORIA,
                        V_ALARMAS.FV,
                        V_ALARMAS.POBLACION,
                        V_ALARMAS.DEPTO,
                        V_ALARMAS.FECHA_MIN_CONS,
                        V_ALARMAS.FECHA_MAX_CONS,
                        V_ALARMAS.FEC_GEN_ALARMA,
                        V_ALARMAS.IP,
                        V_ALARMAS.DESTINOS_DIF,
                        V_ALARMAS.PROM_MIN_DIARIO_HISTORICO,
                        V_ALARMAS.PROM_LLAM_DIARIA_HISTORICO,
                        V_ALARMAS.PORC_DESV_LLAM_RESP_HISTORICO,
                        V_ALARMAS.PORC_DESV_MIN_RESP_HISTORICO,
                        V_ALARMAS.MESES_DE_INSTALADO,
                        V_ALARMAS.MESES_DE_CONSUMO,
                        V_ALARMAS.PLAN_FACTURACION,
                        V_ALARMAS.LLAMADAS_HORA_LABORAL,
                        V_ALARMAS.LLAMADAS_HORA_NO_LABORAL,
                        V_ALARMAS.DISPERSION_ABONADOS,
                        V_ALARMAS.DISPERSION_CIUDADES,
                        V_ALARMAS.PORC_LLAMADAS_HORA_LABORAL,
                        V_ALARMAS.DURACION_PROMEDIO,
                        tipo_alarma
                        );
         end if;   
       commit;
       v_alarmas:=null; 
       tipo_alarma:='';
              
end loop;

close c_mejores_alarmas;

end PROC_mejores_alarmas;


    
/*    
-- Incluimos en la tabla alarmas_new los promedios de cantidad de abonados_b,v_alarmas. cantidad de ciudades yabonados que superen los valores de cantidad de llamadas y cant_meses
             
                insert into califica abonados (abonado_a,acum_dura_real,acum_dura_liqui,
                acum_cant_llam,cod_serv,prom_min_diario,prom_valor_diario,prom_llam_diaria,usuario, acum_dias, acum_valor, operador_nuestro,nombre,subcategoria,fecha_serv,fv,saldo_pend,desc_dpto,
                desc_localidad,desc_categoria,direccion,saldo_favor,estado_serv,estado_finan, cons_por_dia,fecha_min_cons,fecha_max_cons, POBLACION, OPERADOR,
                Minutos_prom_dia_historico,Llamadas_prom_dia_historico, porc_desv,fec_gen_alarma,prom_cant_ab_b,prom_cant_ciudades,prom_cant_meses_consumo, prom_llamadas_dia_historico)
                values (c_alarmas.abonado_a,c_alarmas.acum_dura_real,c_alarmas.acum_dura_liqui,
                c_alarmas.acum_cant_llam,c_alarmas.cod_serv,c_alarmas.prom_min_diario,c_alarmas.prom_valor_diario,c_alarmas.prom_llam_diaria,c_alarmas.usuario,c_alarmas.acum_dias,c_alarmas.acum_valor,c_alarmas.operador_nuestro,c_alarmas.nombre,c_alarmas.subcategoria,c_alarmas.fecha_serv,c_alarmas.fv,c_alarmas.saldo_pend,c_alarmas.desc_dpto,
                c_alarmas.desc_localidad,c_alarmas.desc_categoria,c_alarmas.direccion,c_alarmas.saldo_favor,c_alarmas.estado_serv,c_alarmas.estado_finan, c_alarmas.cons_por_dia,c_alarmas.fecha_min_cons,c_alarmas.fecha_max_cons, c_alarmas.POBLACION, c_alarmas.OPERADOR,
                r_consulta.,Llamadas_prom_dia_historico, porc_desv,fec_gen_alarma,prom_cant_ab_b,prom_cant_ciudades,prom_cant_meses_consumo, prom_llamadas_dia_historico);
             end if;
--         end if;
     commit;
       c_alarmas:=null;   
     --  v_umbral:=0; v_diferencia:=0; v_porc_desv:=0; 
       
  end loop;



v_fec_gen_alarma            date;
v_cant_llamadas             number;
v_cant_minutos              number;
v_saldo_pend                number;
v_fact_ven                  number;
v_tipo_comp                 number;
 
cursor c_alarmas is
select * from alarmas_new

v_historico_alarmas historico_consumo_alarmas%rowtype;
v_calificacion_dest prom_comp_cabinas.calificacion%type;
v_calificacion_ciu prom_comp_cabinas.calificacion%type;
--v_calificacion_min prom_comp_cabinas.calificacion%type;
v_calificacion_hist_min prom_comp_cabinas.calificacion%type;
v_calificacion_hist_llam prom_comp_cabinas.calificacion%type;
v_calificacion_hist_ciu prom_comp_cabinas.calificacion%type;
v_calificacion_hist_dest prom_comp_cabinas.calificacion%type;

-- estas variables se usan para determinar el promedio de 
-- llamadas, destinos, ciudades
v_cant_meses       number;
v_prom_llam        number;
v_prom_dest        number;
v_prom_ciu         number;
v_prom_dura        number;
-- estas variables se usan para calcular el porcentaje de desviacion
-- con relacion a su promedio.
v_porc_ciu         number;
v_porc_dest        number;
v_porc_llam        number;
v_porc_dura        number;
-- estas variables se usan para calcular la diferencia 
-- con relacion a su promedio.
v_dif_ciu         number;
v_dif_dest        number;
v_dif_llam        number;
v_dif_dura        number;
cnt_loop number;
 
begin
  cnt_loop:=0;
  -- Borramos la tabla de Calificacion de Abonados
  delete califica_abonados_new;
  commit;

     
  --TRUNCATE TABLE CALIFICACION_ABONADOS;
  -- recorremos la tabla de alarmas
  FOR v_alarmas IN c_alarmas
  LOOP
      cnt_loop:=Cnt_loop+1;
      -- en el primer registro del cursor de historico de alarmas
      -- esta el ultimo mes
      
      open c_historico_alarmas(v_alarmas.abonado_a);
      fetch c_historico_alarmas into v_historico_alarmas;
      
      -- verificamos el numero de destinos y asignamos calificacion
     Begin
      select prom_comp_cabinas.calificacion, prom_comp_cabinas.porc_desv  
      into v_calificacion_dest , v_porc_dest
      from prom_comp_cabinas
      where prom_comp_cabinas.cod_par=1 
      and v_historico_alarmas.cant_destdifer>prom_comp_cabinas.valor ;
       EXCEPTION WHEN NO_DATA_FOUND THEN
               v_calificacion_dest:=0;
     end;
       -- verificamos el numero de ciudades y asignamos calificacion
     begin
      select prom_comp_cabinas.calificacion, prom_comp_cabinas.porc_desv   
      into v_calificacion_ciu , v_porc_ciu
      from prom_comp_cabinas
      where prom_comp_cabinas.cod_par=2 
      and v_historico_alarmas.cant_ciuddifer>prom_comp_cabinas.valor ;
      EXCEPTION WHEN NO_DATA_FOUND THEN
               v_calificacion_ciu:=0;
     end;
     
     -- sacamos la calificacion que deberian tener los historicos.
     begin
      select prom_comp_cabinas.calificacion,prom_comp_cabinas.porc_desv
      into v_calificacion_hist_min, v_porc_dura 
      from prom_comp_cabinas
      where prom_comp_cabinas.cod_par=3;
      EXCEPTION WHEN NO_DATA_FOUND THEN
               v_calificacion_hist_min:=0;
     end;
  
    begin
      select prom_comp_cabinas.calificacion,prom_comp_cabinas.porc_desv
      into v_calificacion_hist_llam, v_porc_llam
      from prom_comp_cabinas
      where prom_comp_cabinas.cod_par=4;
      EXCEPTION WHEN NO_DATA_FOUND THEN
               v_calificacion_hist_llam:=0;
     end;
     
    begin
      select prom_comp_cabinas.calificacion
      into v_calificacion_hist_ciu
      from prom_comp_cabinas
      where prom_comp_cabinas.cod_par=5;
      EXCEPTION WHEN NO_DATA_FOUND THEN
               v_calificacion_hist_ciu:=0;
    end;

    begin
      select prom_comp_cabinas.calificacion
      into v_calificacion_hist_dest
      from prom_comp_cabinas
      where prom_comp_cabinas.cod_par=6;
      EXCEPTION WHEN NO_DATA_FOUND THEN
               v_calificacion_hist_dest:=0;
     end;

     
      --verificamos el promedio de minutos
      -- contamos el numero de meses en historico de GESTEL
      Begin
      
       select count(d.mes), avg(d.cant_llamadas), avg(d.cant_destdifer),
       avg(d.cant_ciuddifer),avg(d.dura_liqui)
       into v_cant_meses, v_prom_llam, v_prom_dest, v_prom_ciu, v_prom_dura
       from historico_consumo_alarmas d 
       where d.abonado= v_alarmas.abonado_a 
       and to_date('01-'||to_char(to_number((to_char(sysdate,'MM'))))||'-'||to_char(sysdate, 'yyyy') ,'dd-mm-yyyy') - to_date(d.mes||'-01','yyyy-mm-dd')<=150;
       EXCEPTION WHEN NO_DATA_FOUND THEN
               v_prom_llam:=0;
       
      end;  
       --Antes de calcular el porcentaje, es necesario verificar el numero de meses de historico
       if  v_cant_meses <= 2 or v_prom_llam=0 or 
       v_prom_dura=0 or v_prom_ciu=0 or v_prom_dest=0 then
       -- Para este caso no importa si tiene o no historico, porque de todos modos debe salir alarmado
       -- entonces la calificacion por historico es 5 
          v_calificacion_hist_min:=5;
          v_calificacion_hist_llam:=5;
       else 
         --   if v_cant_meses between 3 and 6 then
               -- Calculamos la diferencia entre el historico de minutos y llamadas
               v_dif_llam:=((v_historico_alarmas.cant_llamadas-v_prom_llam)/v_prom_llam)*100;
               v_dif_dura:=((v_historico_alarmas.dura_liqui-v_prom_dura)/v_prom_dura)*100;
               v_dif_ciu:=((v_historico_alarmas.cant_ciuddifer-v_prom_ciu)/v_prom_ciu)*100;
               v_dif_dest:=((v_historico_alarmas.cant_destdifer-v_prom_ciu)/v_prom_dest)*100;
               
               -- de acuerdo a los porcentajes de desviacion anteriores validamos si pasa el promedio.
               if v_dif_ciu<=v_porc_ciu then
                  v_calificacion_hist_ciu:=0;
               end if;
               
               if v_dif_dest<=v_porc_dest then
                 v_calificacion_hist_dest:=0;
               end if;

               if v_dif_llam<=v_porc_llam then
                 v_calificacion_hist_llam:=0;
               end if;

               if v_dif_dura<v_porc_dura then
                 v_calificacion_hist_min:=0;
               end if;
               
      --      end if;
         
       end if;
  
      -- ahora insertamos los resultados de la califacion en la tabla 
      -- de calificacion de abonados.
       insert into calificacion_abonados (abonado,calif_ciudades,calif_destinos,calif_llamadas,
       calif_minutos,calif_hist_llam,calif_hist_min,calif_hist_ciud,calif_hist_dest,num_dest,num_ciud)
       values (v_alarmas.abonado_a, v_calificacion_ciu,v_calificacion_dest,0,0, v_calificacion_hist_llam,
       v_calificacion_hist_min, v_calificacion_hist_ciu, v_calificacion_hist_dest, v_historico_alarmas.cant_destdifer,v_historico_alarmas.cant_ciuddifer);
               
       v_calificacion_ciu:=0; v_calificacion_dest:=0; v_calificacion_hist_llam:=0;
       v_calificacion_hist_min:=0; v_calificacion_hist_ciu:=0; v_calificacion_hist_dest:=0;
       close c_historico_alarmas;
  
        IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
      
  end loop;  
  
end Proc_evalua_abonados_alarmas;
*/
/

