create PROCEDURE proc_actualiza_etb
IS
CURSOR c_tmp_datos IS
select t.*, p.operador from cdr_etb t, tmp_suscriptores ts, pnn_series p
where  t.abon_origen = ts.telefono8
and t.called_number between p.serie_ini and p.serie_fin
 ;

CONTADOR NUMBER;
cnt_loop number;

begin

contador:= 0;
cnt_loop:= 0;



  FOR v_datos_cdr IN c_tmp_datos
  LOOP
      cnt_loop:=Cnt_loop+1;
  SELECT COUNT(*)
  INTO CONTADOR
  FROM cdr_etb t
  WHERE t.called_number = V_datos_cdr.called_number
  and t.abon_origen = V_datos_cdr.abon_origen ;

  IF CONTADOR >0  then

     UPDATE cdr_etb cd
     SET  cd.operador_destino  =  v_datos_cdr.operador
      where cd.called_number = V_datos_cdr.called_number;

 end if;


 IF cnt_loop=200 THEN
         COMMIT;
         cnt_loop:=0;
      END IF;

  END LOOP;


  commit;


END;
/

