create PACKAGE BODY ctr_portaciones_pkg IS

   -- Private type declarations
   PROCEDURE revisaportacion(vc_min             IN ctr_camsim_sin_biometria.min%TYPE,
                             vc_fecha_portacion IN VARCHAR2,
                             vc_resultado       OUT VARCHAR2,
                             nm_error           OUT NUMBER) IS
   
   BEGIN
     nm_error:=0;
   
      SELECT decode(a.id_authorizathion, '-1', 'USUARIO_ACTIV', '0',
                     'SIN_BIOMETRIA', 'CON_BIOMETRIA')
        INTO vc_resultado
        FROM ctr_camsim_sin_biometria a
       WHERE a.min = vc_min
         AND to_date(vc_fecha_portacion, 'dd/mm/yyyy') - 1 < =
             to_date(substr(a.fecha_registro, 0, 19),
                     'dd/mm/yyyy hh24:mi:ss')
         AND rownum = 1;
   EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vc_resultado := 'NO TUVO CAMBIO SIM';
      WHEN OTHERS THEN
         vc_resultado := 'REPO';
   END revisaportacion;

END ctr_portaciones_pkg;
/

