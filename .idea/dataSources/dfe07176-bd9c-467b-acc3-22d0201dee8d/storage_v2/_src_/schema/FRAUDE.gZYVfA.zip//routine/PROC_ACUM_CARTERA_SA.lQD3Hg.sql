create PROCEDURE proc_acum_CARTERA_sa
IS
-- falta agregar validacion para que no acumule periodos ya acumulados
CURSOR c_tmp_CARTERA IS
Select trim(t.codcli) as codcli,
 to_number(t.monto) as saldo,
 to_number(DECODE(TRIM(t.etiqueta),'0','0','30','1','60','2','90','3','120','4','>120','5')) as fv
from cartera_SA_sga t
order by DECODE(TRIM(t.etiqueta),'0','0','30','1','60','2','90','3','120','4','>120','5');
         
saldo       number;
CONTADOR_cartera NUMBER;
cnt_loop number;
V_monto cartera_sga.monto%type;
v_fv cartera_sga.etiqueta%type;


begin
delete edad_cartera_SA;
commit;


commit;
contador_cartera:= 0;
cnt_loop:= 0;
saldo:= '0';


 
  FOR v_cartera IN c_tmp_CARTERA
  LOOP
      cnt_loop:=Cnt_loop+1;
	SELECT COUNT(*)
  INTO CONTADOR_cartera
  FROM EDAD_CARTERA_SA t
  WHERE codcli = V_cartera.Codcli;
  
  IF CONTADOR_cartera >0  then
  
     UPDATE Edad_cartera_SA
     SET 	saldo = saldo + v_cartera.saldo,
          fv = fv + 1
     where codcli= v_cartera.codcli;
	
	ELSE
       INSERT INTO EDAD_CARTERA_SA (
      CODCLI,
      SALDO,
      FV
      )
    	VALUES 
      (
      V_CARTERA.CODCLI,
      V_CARTERA.SALDO,
      V_CARTERA.fv)
      ;
       
       

  end if;
/*        update Edad_cartera
        set saldo = saldo+v_monto+88,
            fv = fv + v_fv+88
        where codcli= v_cartera.codcli;
  
        commit;
*/        
 IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
      
  END LOOP;   

  commit;

  
END;
/

