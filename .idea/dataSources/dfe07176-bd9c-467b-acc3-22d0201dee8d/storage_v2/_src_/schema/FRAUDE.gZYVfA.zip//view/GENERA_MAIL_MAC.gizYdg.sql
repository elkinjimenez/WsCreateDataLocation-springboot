create view GENERA_MAIL_MAC as
select "SENTENCIA" from (
select
'send-mailmessage -to '|| m.email || ' -from "prevencionfraude.co@claro.com.co" -cc   "eduard.granados@claro.com.co", "prevencionfraude.co@claro.com.co", "catalina.lozano@claro.com.co", "manuel.chamorro@claro.com.co",  "alexander.guarnizo@claro.com.co",  "leonardo.castiblanco@claro.com.co" -subject "CONFIRMACION USO BIOMETRIA" -Attachments "D:\BIOMETRIA\MAC\'|| M.NOMBRE_ARCHIVO||'.csv" -body "Cordial saludo,  En el archivo adjunto se encuentran las MAC que han sido cargadas a la fecha con base en la información enviada por el distribuidor '||m.nombre_distribuidor||'. Agradecemos que validen el funcionamiento del captor Biometrico. En caso de presentar errores o fallas comunicarse al #753 opcion 1. Al cargar las MAC se elimina el error de MAC NO HABILITADA. Si se sigue presentando el error de MAC NO HABILITADA y la MAC está en este archivo adjunto verificar si se conectan por WIFI y Punto Fijo y enviar la MAC faltante para realizar el cargue. Muchas Gracias.  Cordialmente Equipo de Prevencion Fraude. " -smtpServer outlook.co.attla.corp
'as sentencia
from EMAIL_DISTR_BIOMETRIA m
ORDER BY m.nombre_distribuidor asc
)
/

