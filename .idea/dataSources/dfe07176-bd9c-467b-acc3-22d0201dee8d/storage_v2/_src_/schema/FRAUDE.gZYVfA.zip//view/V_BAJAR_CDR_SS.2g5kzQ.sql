create view V_BAJAR_CDR_SS as
select "SENTENCIA" from (
select 
'open srtcol:srtcol456@10.244.140.138:2223
cd /opt/srt_mnt03/srtcol/SRT01/ENTRADAS/HWNC/INPARCS/
lcd Y:\
get '||nombre_archivo||'
close
'as sentencia
from log_cargues_ss where flag_cargue = 'S'
ORDER BY nombre_archivo asc
)
/

