create procedure Proc_ACTUALIZA_ALARMAS_COMCEL is

CURSOR c_ALARMAS_COMCEL is
select a.abonado_a,
a.acum_dura_real,
C.ACUM_CANT_LLAM,
s.codigo_cliente,
s.enlace, 
c.tipo_trafico,
c.acum_dias,
S.NOMBRE_CLIENTE,
S.NTDIDE,
S.TIPDIDE,
S.FECHA_ASIGNACION,
S.SEGMENTO,
S.DIRCLI,
S.PROMEDIO_FACTURACION,
S.SALDO_ACTUAL,
S.DES_SUBCATEGORIA,
S.DES_CATEGORIA,
S.FV,
C.FECHA_MIN,
C.FECHA_MAX,
S.IP,
C.DESTINOS_DIF,
C.AVG_AB_B_DIF,
ROUND(C.ACUM_DURA_REAL/C.ACUM_DIAS) AS MINUTOS_DIARIOS,
ROUND(C.ACUM_CANT_LLAM/C.ACUM_DIAS) AS LLAMADAS_DIARIAS,
S.PLAN_FACTURACION
from suscriptores s, cdr_historico c, TMP_Alarmas_comcel a
WHERE a.abonado_a= s.telefono8(+)
and a.abonado_a=c.abonado_a(+)
and C.TIPO_TRAFICO(+) = 'MOVILES';

r_consulta c_alarmas_comcel%rowtype;       
                 
--cursor c_alarmas is
--select * from alarmas_new

--cursor c_califica_abonados is
--select * from califica_abonados
Begin 

DELETE ALARMAS_COMCEL;
COMMIT;

Open c_alarmas_comcel;

  Loop
  
    Fetch c_alarmas_comcel into  r_consulta;
    exit when c_alarmas_comcel%notfound;

    insert into alarmas_comcel t 
           (    CODIGO_CLIENTE                ,
                ENLACE                        ,
                ABONADO_A                     ,
                ACUM_DURA_REAL                ,
                ACUM_DURA_LIQUI               ,
                ACUM_CANT_LLAM                ,
                AVG_AB_B_DIF                  ,
                PROM_MIN_DIARIO               ,
                PROM_VALOR_DIARIO             ,
                PROM_LLAM_DIARIA              ,
                TIPO_TRAFICO                  ,
                ACUM_DIAS                     ,
                OPERADOR                      ,
                OPERADOR_NUESTRO              ,
                NOMBRE_CLIENTE                ,
                NTDIDE                        ,
                TIPDIDE                       ,
                FECHA_ASIGNACION              ,
                DIRECCION                     ,
                SEGMENTO                      ,
                PROMEDIO_FACTURACION          ,
                SALDO_ACTUAL                  ,
                DES_SUBCATEGORIA              ,
                DESC_CATEGORIA                ,
                FV                            ,
                POBLACION                     ,
                DEPTO                         ,
                FECHA_MIN_CONS                ,
                FECHA_MAX_CONS                ,
                FEC_GEN_ALARMA                ,
                IP                            ,
                DESTINOS_DIF                  ,
                PROM_MIN_DIARIO_HISTORICO     ,
                PROM_LLAM_DIARIA_HISTORICO    ,
                PORC_DESV_LLAM_RESP_HISTORICO ,
                PORC_DESV_MIN_RESP_HISTORICO  ,
                MESES_DE_INSTALADO            ,
                MESES_DE_CONSUMO              ,
                PLAN_FACTURACION              ,
                LLAMADAS_HORA_LABORAL         ,
                LLAMADAS_HORA_NO_LABORAL
              )
              values
              (
              r_consulta.codigo_cliente,
              r_consulta.enlace,
              r_consulta.abonado_a,
              r_consulta.acum_dura_real,
              NULL,
              r_consulta.acum_cant_llam,
              r_consulta.avg_ab_b_dif,
              NULL,
              NULL,
              NULL,
              r_consulta.tipo_trafico,
              r_consulta.acum_dias,
              NULL,
              NULL,
              r_consulta.nombre_cliente,
              r_consulta.ntdide,
              r_consulta.tipdide,
              r_consulta.fecha_asignacion,
              r_consulta.Dircli,
              r_consulta.Segmento,
              r_consulta.Promedio_Facturacion,
              r_consulta.Saldo_Actual,
              r_consulta.Des_Subcategoria,
              r_consulta.des_categoria,
              r_consulta.Fv,
              NULL,
              NULL,
              r_consulta.Fecha_Min,
              r_consulta.Fecha_Max,
              SYSDATE,
              r_consulta.Ip,
              r_consulta.Destinos_Dif,
              r_consulta.minutos_diarios,
              r_consulta.Llamadas_Diarias,
              NULL,
              NULL,
              NULL,
              NULL,
              r_consulta.Plan_Facturacion,
              NULL,
              NULL
              );
    
    commit;
        
    r_consulta:=null;
  end loop;
 
close c_alarmas_comcel;
  
end ;
/

