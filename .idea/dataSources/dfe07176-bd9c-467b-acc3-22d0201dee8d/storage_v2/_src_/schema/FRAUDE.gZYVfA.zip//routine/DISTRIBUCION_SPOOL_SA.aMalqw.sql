create procedure Distribucion_Spool_SA is
  --CURSOR DE LA TABLA DEL SPOOL TEMP
  CURSOR SPOOL IS 
  SELECT trim(substr(sersut_numsut,5,(length(sersut_numsut)-4))) A,
               TRIM(FECHA_EXPEDICION) B,        
               TRIM(FECHA_VENCIMIENTO) C,       
               TRIM(FECHA_NOVEDADES) D,         
               TRIM(TASA_CAMBIO) E,             
               TRIM(NOMBRE_CLIENTE) F,          
               TRIM(NIT) G,                     
               TRIM(CODIGO_CLIENTE) H,          
               TRIM(DIRECCION) I,               
               TRIM(REFERENCIA) J,              
               TRIM(CIUDAD) K,                  
               TRIM(NUMERO_TELEFONO) L,         
               REPLACE(REPLACE(REPLACE(SALDO_ANTERIOR,' ',''),'$',''),',','') M,
               REPLACE(REPLACE(REPLACE(CUOTA_FINANCIACION,' ',''),'$',''),',','')N,
               REPLACE(REPLACE(REPLACE(CARGO_MES,' ',''),'$',''),',','') O,
               REPLACE(REPLACE(REPLACE(TOTAL,' ',''),'$',''),',','') R,
               TRIM(DESCRIP_DETALLE_DIFERIDO) S,
               TRIM(FEC_INI_DETALLE_DIFERIDO) T,
               REPLACE(REPLACE(REPLACE(CUOTA_DETALLE_DIFERIDO,' ',''),'$',''),',','') P,  --NUMBER,
               REPLACE(REPLACE(REPLACE(SALDO_DETALLE_DIFERIDO,' ',''),'$',''),',','') Q,--SALDO_DETALLE_DIFERIDO                   NUMBER,
               REPLACE(REPLACE(REPLACE(TOTAL_CARGOS,' ',''),'$',''),',','') U,--TOTAL_CARGOS                     NUMBER,
               REPLACE(REPLACE(REPLACE(INTERESES_MORA,' ',''),'$',''),',','') W,--CONTRIBUCION                   NUMBER,
               REPLACE(REPLACE(REPLACE(SUBTOTAL,' ',''),'$',''),',','') V,--RETEIVA                        NUMBER,
               REPLACE(REPLACE(REPLACE(IVA,' ',''),'$',''),',','') X,--TOTALIMPUESTOS                 NUMBER,
               REPLACE(REPLACE(REPLACE(RETEICA,' ',''),'$',''),',','') Y,--GRACIASPORPAGO                 NUMBER,
               REPLACE(REPLACE(REPLACE(RETEIVA,' ',''),'$',''),',','') Z,--GRACIASPORPAGO 
               REPLACE(REPLACE(REPLACE(TOTAL_FACTURA,' ',''),'$',''),',','')AA, --SALDOANTERIOR                  NUMBER,
               REPLACE(REPLACE(REPLACE(TOTAL_PAGAR,' ',''),'$',''),',','') AB, --SALDOANTERIOR                  NUMBER,
               TRIM(VALOR_LETRAS) AC,            
               TRIM(OBSERVACIONES) AD,           
               TRIM(CODIGO_BARRAS) AE,           
               TRIM(INFORMACION_TRIBUTARIA) AF     
   FROM SPOOL_FORMATO_TEMP_SA 
   WHERE SUBSTR(SERSUT_NUMSUT, 1, 4) = '1.1.' ;   
 BEGIN

   -- DISTRIBUIR
   FOR  A1 IN SPOOL LOOP

       --Captura factura
       ------------------------------------------------------------------------------   
--      IF substr(SERSUT_NUMSUT,1,4) = '1.1.' THEN
--           Factura := Substr(C.SERSUT_NUMSUT,12,6);
       
           --Campos registros hoja principal
           ------------------------------------------------------------------------------       
           INSERT INTO SPOOL_FORMATO_ENCABEZADO_SA VALUES 
           (
A1.A ,--SERSUT_NUMSUT,
A1.B, --FECHA_EXPEDICION,
A1.C,--FECHA_VENCIMIENTO,
A1.D,--FECHA_NOVEDADES,
A1.E,--TASA_CAMBIO,
A1.F,--NOMBRE_CLIENTE,
A1.G,--NIT,
A1.H,--CODIGO_CLIENTE,
A1.I,--DIRECCION,
A1.J,--REFERENCIA,               
A1.K,--CIUDAD,                   
A1.L,--NUMERO_TELEFONO,          
A1.M,--SALDO_ANTERIOR,           
A1.N,--CUOTA_FINANCIACION,       
A1.O,--CARGO_MES,                
A1.R,--TOTAL,                    
A1.S,--DESCRIP_DETALLE_DIFERIDO, 
A1.T,--FEC_INI_DETALLE_DIFERIDO, 
A1.P,--CUOTA_DETALLE_DIFERIDO,   
A1.Q,--SALDO_DETALLE_DIFERIDO,   
A1.U,--TOTAL_CARGOS,             
A1.W,--INTERESES_MORA,           
A1.V,--SUBTOTAL,                 
A1.X,--IVA,                      
A1.Y,--RETEICA,                  
A1.Z,--RETEIVA,                  
A1.AA,--TOTAL_FACTURA,           
A1.AB,--TOTAL_PAGAR,             
A1.AC,--VALOR_LETRAS,            
A1.AD,--OBSERVACIONES,           
A1.AE,--CODIGO_BARRAS,           
A1.AF--INFORMACION_TRIBUTARIA   
       );
           COMMIT;
  --     END IF;
       
       /*       
       --Campos registros hoja ESP
       ------------------------------------------------------------------------------
       IF substr(C.SERSUT_NUMSUT,2,5) = "2.1." THEN
                           
           INSERT INTO SPOOL_FORMATOANEX1_ESP VALUES 
           (
                Factura, --NUMSUT              NUMBER,
                --NUMEROITEM          NUMBER,
                --CODIGOENLACE        VARCHAR2(10),
                --DETALLE             VARCHAR2(20),
                --CANTIDAD            NUMBER,
                --NOLINEAS            NUMBER,
                --MINUTOSPLANELEGIDO  VARCHAR2(20),
                --VALORPLANELEGIDO    NUMBER,
                --MINUTOSADICIONALES  NUMBER,
                --CONSUMOSADICIONALES NUMBER,
                --CONTRIBUCION        NUMBER,
                --FECHADESDE          DATE,
                --FECHAHASTA          DATE,
                --TOTAL               NUMBER           
            );

       END IF;*/


   
   END LOOP;
    
  
  
  
  
END Distribucion_Spool_SA;
/

