create procedure Proc_ACTUALIZA_ALARMAS_LABORAL is

CURSOR c_califica_abonados is
select B.ABONADO_A,
       b.tipo_trafico,
       nvl(A.ACUM_CANT_LLAM, 0) AS LLAMADAS_HORA_LABORAL,
       nvl(B.ACUM_CANT_LLAM, 0) - nvl(A.ACUM_CANT_LLAM, 0) AS LLAMADAS_HORA_NO_LABORAL
  from CDR_ACUM_TOTAL_LABORAL A, alarmas_NEW b
 where B.abonado_a = A.abonado_a(+)
   AND A.TIPO_TRAFICO(+) = B.TIPO_TRAFICO;


r_consulta c_califica_abonados%rowtype;       
                 
--cursor c_alarmas is
--select * from alarmas_new

--cursor c_califica_abonados is
--select * from califica_abonados
Begin 

Open c_califica_abonados;

  Loop
  
    Fetch c_califica_abonados into  r_consulta;
    exit when c_califica_abonados%notfound;

    UPDATE ALARMAS_NEW T
    SET T.LLAMADAS_HORA_LABORAL = r_consulta.LLAMADAS_HORA_LABORAL,
    T.LLAMADAS_HORA_NO_LABORAL = r_consulta.llamadas_hora_no_laboral
    WHERE T.ABONADO_A = r_consulta.ABONADO_A
    AND T.TIPO_TRAFICO = r_consulta.TIPO_TRAFICO;
    
    commit;
        
    r_consulta:=null;
  end loop;
 
close c_califica_abonados;
  
end ;
/

