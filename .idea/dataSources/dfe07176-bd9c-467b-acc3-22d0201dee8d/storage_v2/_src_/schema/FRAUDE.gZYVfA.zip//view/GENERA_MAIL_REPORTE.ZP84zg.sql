create view GENERA_MAIL_REPORTE as
select "SENTENCIA" from (
select
'send-mailmessage -to '|| m.email || ' -from "prevencionfraude.co@claro.com.co" -cc   "eduard.granados@claro.com.co", "prevencionfraude.co@claro.com.co" -subject "REPORTES BIOMETRIA" -Attachments "D:\BIOMETRIA\REPORTE\'|| M.NOMBRE_ARCHIVO||'.csv" -body "Cordial saludo,  En el archivo adjunto se detallan las transacciones de Biometría realizadas los ultimos treinta dias por el distribuidor '||m.nombre_distribuidor||'. Agradecemos continuar con el uso de Biometria. Cordialmente Equipo de Prevencion Fraude. " -smtpServer outlook.co.attla.corp
'as sentencia
from EMAIL_DISTR_BIOMETRIA m
ORDER BY m.nombre_distribuidor asc
)
/

