create view V_EXTRAE_CDR_SRT_FO_NN as
select "SENTENCIA" from (
select 'INSERT INTO TMP_CDR_SRT_FO_NN (
  Select t.*,'||Chr(39)||Chr(39)||','||Chr(39)||Chr(39)||'  from cdr_car_mas_SRT_NN t
  WHERE T.secuencia_cdr > '||Chr(39)||C.SERIAL_NUMBER||Chr(39)||');' as sentencia
from LOG_CARGUES_CDR_srt_NN C
WHERE c.FECHA_CARGUE = (SELECT MAX(m.FECHA_CARGUE) FROM LOG_CARGUES_CDR_SRT_NN m ) AND C.SERIAL_NUMBER IS NOT NULL
)
/

