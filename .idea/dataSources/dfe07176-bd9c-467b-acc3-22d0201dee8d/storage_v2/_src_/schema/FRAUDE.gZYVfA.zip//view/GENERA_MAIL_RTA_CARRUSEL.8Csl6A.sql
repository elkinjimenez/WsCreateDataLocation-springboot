create view GENERA_MAIL_RTA_CARRUSEL as
select "SENTENCIA" from (
select
'send-mailmessage -to '|| m.mail || ' -from "carlos.ramirez.r@claro.com.co" -cc   "wilmar.romerol@claro.com.co", "carlos.ramirez.r@claro.com.co" -subject "RESPUESTA REFUTACION CARRUSEL COMERCIAL" -Attachments "D:\CARRUSEL_AGENTES\Respuesta_carrusel\RESPUESTAS\RTA_CARRUSEL_'|| m.archivo ||'.csv" -body "Cordial saludo,  En el archivo adjunto se detalla el resultado de la validación de los casos reportados de carrusel comercial del agente '||m.agente||' según se haya realizado refutación o no. Por favor verificar las columnas de Observacion y Aplica_carrusel. Recordar por favor los tiempos válidos para refutar. Por favor responder directamente al correo prevencionfraude.co@claro.com.co.  Muchas Gracias.    Cordialmente Equipo de Prevencion Fraude. " -smtpServer webmail.telmexla.com.co
'as sentencia
from mail_agentes m
ORDER BY agente asc
)
/

