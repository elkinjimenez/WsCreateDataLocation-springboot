create PACKAGE BODY validacion_identidad_pkg IS

   FUNCTION fnc_cantidad_dias(vc_dias IN VARCHAR2) RETURN NUMBER IS
   
      nm_dias NUMBER := 0;
   BEGIN
   
      SELECT to_number(f.identificador)
        INTO nm_dias
        FROM parametrizacion f
       WHERE f.proceso = vc_dias;
   
      RETURN nm_dias;
   END fnc_cantidad_dias;

   PROCEDURE valida_documento(vc_tipo_doc         IN VARCHAR2,
                              vc_nm_doc           IN VARCHAR2,
                              vc_fecha_tramite    IN VARCHAR2,
                              vc_valido           OUT VARCHAR2,
                              vc_herramienta      OUT VARCHAR2,
                              vc_fecha_validacion OUT VARCHAR2) IS
   BEGIN
   
      NULL;
   
   END;

   PROCEDURE valida_biometria(vc_nm_doc           IN VARCHAR2,
                              vc_fecha_tramite    IN VARCHAR2,
                              vc_valido           OUT VARCHAR2,
                              vc_fecha_validacion OUT VARCHAR2,
                              vc_error            OUT VARCHAR2) IS
   
      vc_doc           VARCHAR2(20) := NULL;
      dt_fecha_tramite DATE := NULL;
      nm_dias          NUMBER := 0;
   
   BEGIN
      vc_valido := 'SI';
      vc_error  := 'OK';
      vc_doc    := TRIM(vc_nm_doc);
      --01/08/2019 LAS VENTAS DE LA FIJA NO TIENEN HORA 
      -- dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy hh24:mi:ss');
      dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy');
      nm_dias          := fnc_cantidad_dias('DIAS_REPORTES_FIJA');
   
      SELECT substr(r.fecha, 0, 19)
        INTO vc_fecha_validacion
        FROM reportes_biometria r
       WHERE r.documento = vc_doc
         AND upper(r.respuesta) = 'AUTORIZADO'
            --01/08/2019 LAS VENTAS DE LA FIJA NO TIENEN HORA 
            -- and dt_fecha_Tramite - to_date(substr(r.fecha, 0, 19), 'dd/mm/yyyy hh24:mi:ss')
         AND dt_fecha_tramite -
             to_date(substr(r.fecha, 0, 10), 'dd/mm/yyyy') BETWEEN 0 AND
             nm_dias
         AND rownum = 1;
   
   EXCEPTION
      WHEN no_data_found THEN
         vc_valido := 'NO';
      WHEN OTHERS THEN
         vc_error  := SQLERRM;
         vc_valido := 'NO';
   END valida_biometria;

   PROCEDURE valida_evidente(vc_nm_doc           IN VARCHAR2,
                             vc_fecha_tramite    IN VARCHAR2,
                             vc_valido           OUT VARCHAR2,
                             vc_fecha_validacion OUT VARCHAR2,
                             vc_error            OUT VARCHAR2) IS
   
      vc_doc           VARCHAR2(20) := NULL;
      dt_fecha_tramite DATE := NULL;
      nm_dias          NUMBER := 0;
   
   BEGIN
      vc_valido := 'SI';
      vc_error  := 'OK';
      vc_doc    := TRIM(vc_nm_doc);
      --01/08/2019 LAS VENTAS DE LA FIJA NO TIENEN HORA 
      --dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy hh24:mi:ss');
      dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy');
      nm_dias          := fnc_cantidad_dias('DIAS_REPORTES_FIJA');
   
      SELECT substr(r.fecha_y_hora, 0, 19)
        INTO vc_fecha_validacion
        FROM evidente_claro_view r
       WHERE r.no_id_cliente = vc_doc
         AND upper(r.resultado) IN
             ('APROBADO', 'AUTENTICACIÓN DE IDENTIDAD EXITOSA',
              'VALIDACION DE IDENTIDAD EXITOSA',
              'VALIDACION DE IDENTIDA APROBADA', 'CONFRONTACIÓN EXITOSA')
            --01/08/2019 LAS VENTAS DE LA FIJA NO TIENEN HORA      
            --and dt_fecha_Tramite - to_date(substr(r.FECHA_Y_HORA, 0, 19), 'dd/mm/yyyy hh24:mi:ss')between 0 and nm_dias
         AND dt_fecha_tramite -
             to_date(substr(r.fecha_y_hora, 0, 10), 'dd/mm/yyyy') BETWEEN 0 AND
             nm_dias
         AND rownum = 1;
   
   EXCEPTION
      WHEN no_data_found THEN
         vc_valido := 'NO';
      WHEN OTHERS THEN
         vc_error  := SQLERRM;
         vc_valido := 'NO';
   END valida_evidente;

   /*Modificacion 31/07/2019 --> Debido a que no se tiene precision en  la hora de realizar la digitacion de la venta fija
   no se debe manjear la hora minuto y segundo en el momento de revisar el idvisionde fija, 
   */
   --VALIDACION IDVISION FIJA
   PROCEDURE valida_idvision(vc_nm_doc           IN VARCHAR2,
                             vc_fecha_tramite    IN VARCHAR2,
                             vc_valido           OUT VARCHAR2,
                             vc_fecha_validacion OUT VARCHAR2,
                             vc_error            OUT VARCHAR2) IS
   
      vc_doc           VARCHAR2(20) := NULL;
      dt_fecha_tramite DATE := NULL;
      nm_dias          NUMBER := 0;
   
   BEGIN
      vc_valido := 'SI';
      vc_error  := 'OK';
      vc_doc    := TRIM(vc_nm_doc);
      --01/08/2019 LAS VENTAS DE LA FIJA NO TIENEN HORA     
      --dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy hh24:mi:ss');
      dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy');
      nm_dias          := fnc_cantidad_dias('DIAS_REPORTES_FIJA');
   
      SELECT substr(r.fecha_y_hora_de_consulta, 0, 19)
        INTO vc_fecha_validacion
        FROM idvision r
       WHERE r.numero_identificacion = vc_doc
         AND upper(r.resultado_confrontacion) IN ('APROBADO')
            --01/08/2019 LAS VENTAS DE LA FIJA NO TIENEN HORA         
            --and dt_fecha_Tramite  - to_date(substr(r.fecha_y_hora_de_consulta, 0, 19), 'dd/mm/yyyy hh24:mi:ss')
         AND dt_fecha_tramite -
             to_date(substr(r.fecha_y_hora_de_consulta, 0, 10),
                     'dd/mm/yyyy hh24:mi:ss') BETWEEN 0 AND nm_dias
         AND rownum = 1;
   
   EXCEPTION
      WHEN no_data_found THEN
         vc_valido := 'NO';
      WHEN OTHERS THEN
         vc_error  := SQLERRM;
         vc_valido := 'NO';
   END valida_idvision;

   PROCEDURE valida_biometria_movil(vc_nm_doc           IN VARCHAR2,
                                    vc_fecha_tramite    IN VARCHAR2,
                                    vc_valido           OUT VARCHAR2,
                                    vc_fecha_validacion OUT VARCHAR2,
                                    vc_error            OUT VARCHAR2) IS
   
      vc_doc           VARCHAR2(20) := NULL;
      dt_fecha_tramite DATE := NULL;
      nm_dias          NUMBER := 0;
   
   BEGIN
      vc_valido        := 'SI';
      vc_error         := 'OK';
      vc_doc           := TRIM(vc_nm_doc);
      dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy hh24:mi:ss');
      nm_dias          := fnc_cantidad_dias('DIAS_REPORTES_MOVIL');
   
      SELECT substr(r.fecha, 0, 19)
        INTO vc_fecha_validacion
        FROM reportes_biometria r
       WHERE r.documento = vc_doc
         AND upper(r.respuesta) = 'AUTORIZADO'
         AND dt_fecha_tramite -
             to_date(substr(r.fecha, 0, 19), 'dd/mm/yyyy hh24:mi:ss') BETWEEN 0 AND
             nm_dias
         AND rownum = 1;
   
   EXCEPTION
      WHEN no_data_found THEN
         vc_valido := 'NO';
      WHEN OTHERS THEN
         vc_error  := SQLERRM;
         vc_valido := 'NO';
   END valida_biometria_movil;

   PROCEDURE valida_evidente_movil(vc_nm_doc           IN VARCHAR2,
                                   vc_fecha_tramite    IN VARCHAR2,
                                   vc_valido           OUT VARCHAR2,
                                   vc_fecha_validacion OUT VARCHAR2,
                                   vc_error            OUT VARCHAR2) IS
   
      vc_doc           VARCHAR2(20) := NULL;
      dt_fecha_tramite DATE := NULL;
      nm_dias          NUMBER := 0;
   
   BEGIN
      vc_valido        := 'SI';
      vc_error         := 'OK';
      vc_doc           := TRIM(vc_nm_doc);
      dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy hh24:mi:ss');
      nm_dias          := fnc_cantidad_dias('DIAS_REPORTES_MOVIL');
   
      SELECT substr(r.fecha_y_hora, 0, 19)
        INTO vc_fecha_validacion
        FROM evidente_claro_view r
       WHERE r.no_id_cliente = vc_doc
         AND upper(r.resultado) IN
             ('APROBADO', 'AUTENTICACIÓN DE IDENTIDAD EXITOSA',
              'VALIDACION DE IDENTIDAD EXITOSA',
              'VALIDACION DE IDENTIDA APROBADA', 'CONFRONTACIÓN EXITOSA')
         AND dt_fecha_tramite -
             to_date(substr(r.fecha_y_hora, 0, 19), 'dd/mm/yyyy hh24:mi:ss') BETWEEN 0 AND
             nm_dias
         AND rownum = 1;
   
   EXCEPTION
      WHEN no_data_found THEN
         vc_valido := 'NO';
      WHEN OTHERS THEN
         vc_error  := SQLERRM;
         vc_valido := 'NO';
   END valida_evidente_movil;

   PROCEDURE valida_idvision_movil(vc_nm_doc           IN VARCHAR2,
                                   vc_fecha_tramite    IN VARCHAR2,
                                   vc_valido           OUT VARCHAR2,
                                   vc_fecha_validacion OUT VARCHAR2,
                                   vc_error            OUT VARCHAR2) IS
   
      vc_doc           VARCHAR2(20) := NULL;
      dt_fecha_tramite DATE := NULL;
      nm_dias          NUMBER := 0;
   
   BEGIN
      vc_valido        := 'SI';
      vc_error         := 'OK';
      vc_doc           := TRIM(vc_nm_doc);
      dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy hh24:mi:ss');
      nm_dias          := fnc_cantidad_dias('DIAS_REPORTES_MOVIL');
   
      SELECT substr(r.fecha_y_hora_de_consulta, 0, 19)
        INTO vc_fecha_validacion
        FROM idvision r
       WHERE r.numero_identificacion = vc_doc
         AND upper(r.resultado_confrontacion) IN ('APROBADO')
         AND dt_fecha_tramite -
             to_date(substr(r.fecha_y_hora_de_consulta, 0, 19),
                     'dd/mm/yyyy hh24:mi:ss') BETWEEN 0 AND nm_dias
         AND rownum = 1;
   
   EXCEPTION
      WHEN no_data_found THEN
         vc_valido := 'NO';
      WHEN OTHERS THEN
         vc_error  := SQLERRM;
         vc_valido := 'NO';
   END valida_idvision_movil;

   FUNCTION fn_valida_biometria_movil(vc_nm_doc        IN VARCHAR2,
                                      vc_fecha_tramite IN VARCHAR2)
      RETURN VARCHAR2 IS
   
      vc_doc              VARCHAR2(20) := NULL;
      dt_fecha_tramite    DATE := NULL;
      nm_dias             NUMBER := 0;
      vc_fecha_validacion VARCHAR2(100);
   
   BEGIN
   
      vc_doc           := TRIM(vc_nm_doc);
      dt_fecha_tramite := to_date(vc_fecha_tramite, 'dd/mm/yyyy hh24:mi:ss');
      nm_dias          := fnc_cantidad_dias('DIAS_REPORTES_MOVIL');
   
      SELECT 'SI|' || substr(r.fecha, 0, 19)
        INTO vc_fecha_validacion
        FROM reportes_biometria r
       WHERE r.documento = vc_doc
         AND upper(r.respuesta) = 'AUTORIZADO'
         AND dt_fecha_tramite -
             to_date(substr(r.fecha, 0, 19), 'dd/mm/yyyy hh24:mi:ss') BETWEEN 0 AND
             nm_dias
         AND rownum = 1;
   
      RETURN vc_fecha_validacion;
   EXCEPTION
      WHEN OTHERS THEN
         vc_fecha_validacion := 'NO|';
         RETURN vc_fecha_validacion;
   END fn_valida_biometria_movil;

   --0810/20220 validacion  de consecutivos de IDVISION OTP
   FUNCTION fnc_idvision_consecutivo(vc_consecutivo IN VARCHAR2)
      RETURN VARCHAR IS
   
      resultado VARCHAR(100) := 'NO EXISTE CONSECUTIVO';
   
   BEGIN
   
      SELECT a.resultado_confrontacion || ' - ' ||
              decode(a.resultado_opt,
                     'Identidad validada exitosamente. - Pass', 'POR OTP', '')
        INTO resultado
        FROM idvision a
       WHERE a.consecutivo = vc_consecutivo;
   
      RETURN resultado;
   
   EXCEPTION
      WHEN no_data_found THEN
         RETURN resultado;
      
   END fnc_idvision_consecutivo;

END validacion_identidad_pkg;
/

