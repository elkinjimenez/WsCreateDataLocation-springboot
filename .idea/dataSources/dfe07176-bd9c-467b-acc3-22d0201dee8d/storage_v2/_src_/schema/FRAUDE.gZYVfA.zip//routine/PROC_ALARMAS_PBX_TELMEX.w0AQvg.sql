create procedure Proc_alarmas_pbx_telmex
is

CURSOR c_acum_CDR_completa IS
select T.CALLER_NUMBER TELEFONO_ORIGEN,
T.CALLED_NUMBER TELEFONO_DESTINO, 
T.DIALED_NUMBER NUMERO_MARCADO, 
ceil(T.DURATION/60) MINUTOS, 
to_char(T.START_DATE,'YYYY-MM-DD HH24:MI:SS') FECHA_INICIO, 
to_char(T.END_DATE,'YYYY-MM-DD HH24:MI:SS') FECHA_FIN, 
T.TIPO_TRAFICO,
T.DESTINO
from cdr_huawei_ip_tmp t, suscriptores s
where t.caller_number = s.telefono8
and s.nombre_cliente like 'TELMEX%'
and to_char(t.start_date,'YYYY-MM-DD') >= TO_CHAR(SYSDATE -8,'YYYY-MM-DD');

                  
r_consulta c_acum_CDR_completa%rowtype;
tipo_alarma       varchar(500);

BEGIN

tipo_alarma := '';


Open c_acum_CDR_completa;

  Loop
  
    Fetch c_acum_CDR_completa into  r_consulta;
    exit when c_acum_CDR_completa%notfound;

-- Incluimos en la tabla alarmas_PBX las llamadas de Larga duracion              
             
             If 
                 (r_consulta.tipo_trafico not in ('11','CORPORATIVA','LOCAL+LE', 'LINEAS_018000') and r_consulta.minutos > 120)
             THEN 
             tipo_alarma:= tipo_alarma||'LARGA-DURACION,';
             
             insert into alarmas_pbx_telmex (
                                      TELEFONO_ORIGEN,
                                      TELEFONO_DESTINO,
                                      NUMERO_MARCADO,
                                      MINUTOS,
                                      FECHA_INICIO,
                                      FECHA_FIN,
                                      TIPO_TRAFICO,
                                      DESTINO,
                                      tipo_alarma
                                              )
                values (              r_consulta.TELEFONO_ORIGEN,
                                      r_consulta.TELEFONO_DESTINO,
                                      r_consulta.NUMERO_MARCADO,
                                      r_consulta.MINUTOS,
                                      r_consulta.FECHA_INICIO,
                                      r_consulta.FECHA_FIN,
                                      r_consulta.TIPO_TRAFICO,
                                      r_consulta.DESTINO,
                                      tipo_alarma                                 );
             end if;
             
-- Incluimos en la tabla alarmas_PBX las llamadas a destinos internacionales extra?os 
             
               If (r_consulta.destino not in ('ARGENTINA',
                                    'BRASIL',
                                    'CHILE',
                                    'COLOMBIA',
                                    'ECUADOR',
                                    'MEXICO',
                                    'PANAMA',
                                    'PARAGUAY',
                                    'PERU',
                                    'TOLL-FREE',
                                    'URUGUAY',
                                    'USA CANADA',
                                    'VENEZUELA')
                                    AND r_consulta.TIPO_TRAFICO IN ('LDI-TERCEROS', 'LDI-POR-TELMEX'))
               THEN
               tipo_alarma:= tipo_alarma||'DESTINOS_ATIPICOS_LDI,';
               insert into alarmas_pbx_telmex (
                                      TELEFONO_ORIGEN,
                                      TELEFONO_DESTINO,
                                      NUMERO_MARCADO,
                                      MINUTOS,
                                      FECHA_INICIO,
                                      FECHA_FIN,
                                      TIPO_TRAFICO,
                                      DESTINO,
                                      tipo_alarma
                                              )
                values (              r_consulta.TELEFONO_ORIGEN,
                                      r_consulta.TELEFONO_DESTINO,
                                      r_consulta.NUMERO_MARCADO,
                                      r_consulta.MINUTOS,
                                      r_consulta.FECHA_INICIO,
                                      r_consulta.FECHA_FIN,
                                      r_consulta.TIPO_TRAFICO,
                                      r_consulta.DESTINO,
                                      tipo_alarma                                 );
             end if;
             
     commit;
       r_consulta:=null;   
     --  v_umbral:=0; v_diferencia:=0; v_porc_desv:=0; 
       tipo_alarma:='';
  end loop;
     
close c_acum_CDR_completa;


end Proc_alarmas_pbx_telmex;
/

