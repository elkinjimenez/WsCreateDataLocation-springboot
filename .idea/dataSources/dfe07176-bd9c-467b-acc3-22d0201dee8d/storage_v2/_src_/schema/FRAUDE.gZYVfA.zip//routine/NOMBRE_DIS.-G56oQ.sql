create function NOMBRE_DIS (VNIT IN VARCHAR2)
  return varchar2 is
  Result varchar2(200);
begin

  SELECT B.NOMBRE_RAZON_SOCIAL
    INTO Result
    FROM DISTRIBUIDORES_RED B
   WHERE B.NIT = VNIT;
  return(Result);
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
end NOMBRE_DIS;
/

