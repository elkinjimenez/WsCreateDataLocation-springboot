create PROCEDURE  "PRC_RADIC_BLOQUEO_USERS" (
                                        v_user_id IN VARCHAR2 DEFAULT NULL, 
                                        v_cons    IN NUMBER DEFAULT 0,
                                        v_msg IN VARCHAR2 DEFAULT NULL,
                                        v_est IN NUMBER DEFAULT 3,
                                        v_rpst OUT VARCHAR2
                                        ) IS
/* Variables Iniciales */
VaRpta         VARCHAR2(9999);
dafech         VARCHAR(25) :=to_char(sysdate,'yyyy-mm-dd hh24:mi:ss');
v_result       NUMBER:=0;
BEGIN
  DBMS_OUTPUT.PUT_LINE('Incia  Proceso : ');
  
  IF v_user_id is not null and v_est in(3,4) THEN 
     DBMS_OUTPUT.PUT_LINE('Usuario es :  '||v_user_id );
     DBMS_OUTPUT.PUT_LINE('Usuario es :  '||v_cons );
     DBMS_OUTPUT.PUT_LINE('Usuario es :  '||v_msg );
     VaRpta    := '[msg:'||v_user_id||';'||v_cons||';0;Bloqueo Fraude BDPrufac;'||dafech||']';
    UPDATE FRAUDE.RADIC_BLOQUEO_USERS_PRUEBA R
    SET   R.ACTIVA_USER_HABILITADO=0,  R.OBSERVACION_ANALISTA=v_msg, R.ESTADO=v_est
    WHERE R.OBSERVACION_ANALISTA IS NULL
      and R.ACTIVA_USER_HABILITADO=1
      and USUARIO =v_user_id;
    v_result := SQL%ROWCOUNT;
    IF v_result>0 THEN 
      v_rpst     := VaRpta;
      INSERT INTO FRAUDE.LOG_RADIC_BLOQUEO_USERS 
            (ID_LOG, FECHA_PROCESO,USUARIO,NUMFILA, RESPUESTA_ACTIVA, RESPUESTA_PRUFAC)
      VALUES(LOG_RADIC_BLOQUEO_USERS_SEQ.NEXTVAL, to_date(dafech,'yyyy-mm-dd hh24:mi:ss'), v_user_id,v_cons, v_msg, v_rpst);
      COMMIT;
    ELSE
      v_rpst     := '[msg:'||v_user_id||';'||v_result||';0;Usuario No Existe/ No actualizado BDPrufac;'||dafech||']';
    END IF;
  END IF;
  DBMS_OUTPUT.PUT_LINE('Final  Proceso : ');

EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    VaRpta    := '[msg:'||v_user_id||';'||v_result||';'||SQLCODE||';'||SQLERRM||';'||dafech||']';
    v_rpst := VaRpta;
    RAISE_APPLICATION_ERROR(-20114,v_rpst);    
END;
/

