create PACKAGE proceso_fraude_fija IS

   -- Author  : ICM0613A
   -- Created : 27/03/2020 10:56:28 a. m.
   -- Purpose : Proceso de deteccion y bajas de la fija

   PROCEDURE cargar_tabla_ppal(p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2);

   PROCEDURE borrar_tmp_fraude(p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2);

   PROCEDURE borrar_estado_cuentas(p_nm_error OUT NUMBER,
                                   p_vc_error OUT VARCHAR2);

   PROCEDURE borrar_nunca_pago(p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2);

   PROCEDURE insertar_fraude(p_vc_cta             IN VARCHAR2,
                             p_vc_tipo_fraude     IN VARCHAR2,
                             p_vc_fecha_deteccion IN VARCHAR2,
                             p_nm_error           OUT NUMBER,
                             p_vc_error           OUT VARCHAR2);

   PROCEDURE procesar_tmp(p_nm_error OUT NUMBER,
                          p_vc_error OUT VARCHAR2);

   PROCEDURE insertar_estado_cuenta(p_vc_cta                 IN VARCHAR2,
                                    p_vc_estado_cuenta       IN VARCHAR2,
                                    p_vc_fecha_digitacion    IN VARCHAR2,
                                    p_vc_fecha_desactivacion IN VARCHAR2,
                                    p_vc_razon_dx            IN VARCHAR2,
                                    p_vc_descripcion_dx      IN VARCHAR2,
                                    p_vc_tel_casa            IN VARCHAR2,
                                    p_vc_tel_oficina         IN VARCHAR2,
                                    p_vc_tercer_tel          IN VARCHAR2,
                                    p_nm_error               OUT NUMBER,
                                    p_vc_error               OUT VARCHAR2);

   PROCEDURE insertar_cuentanp(p_vc_cta   IN VARCHAR2,
                               p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2);
   PROCEDURE insertar_tel_contacto(p_nm_error OUT NUMBER,
                                   p_vc_error OUT VARCHAR2);

   PROCEDURE insertar_tel_contacto(p_vc_cta         IN VARCHAR2,
                                   p_vc_tel_casa    IN VARCHAR2,
                                   p_vc_tel_oficina IN VARCHAR2,
                                   p_vc_tercer_tel  IN VARCHAR2,
                                   p_nm_error       OUT NUMBER,
                                   p_vc_error       OUT VARCHAR2);

   PROCEDURE actualiza_ppal(p_nm_error OUT NUMBER,
                            p_vc_error OUT VARCHAR2);

   PROCEDURE actualiza_ppal2(p_nm_error OUT NUMBER,
                             p_vc_error OUT VARCHAR2);
   PROCEDURE actualiza_tel_malla_fr(p_nm_error OUT NUMBER,
                                    p_vc_error OUT VARCHAR2);

   PROCEDURE actualiza_asesores_fr(p_nm_cant_fr NUMBER,
                                   p_nm_error   OUT NUMBER,
                                   p_vc_error   OUT VARCHAR2);

   PROCEDURE actualiza_nodos_fr(p_nm_cant_fr NUMBER,
                                p_nm_error   OUT NUMBER,
                                p_vc_error   OUT VARCHAR2);

   PROCEDURE actualiza_poblacion_fraude(p_nm_cant_fr NUMBER,
                                        p_nm_error   OUT NUMBER,
                                        p_vc_error   OUT VARCHAR2);

   PROCEDURE actualiza_wtth(p_nm_error OUT NUMBER,
                            p_vc_error OUT VARCHAR2);

   PROCEDURE actualiza_tplay(p_nm_error OUT NUMBER,
                             p_vc_error OUT VARCHAR2);

   PROCEDURE actualiza_hh_pp(p_nm_error OUT NUMBER,
                             p_vc_error OUT VARCHAR2);

   PROCEDURE actualiza_neg_movil(p_nm_error OUT NUMBER,
                                 p_vc_error OUT VARCHAR2);
   PROCEDURE insertar_mas_dos_cta(p_vc_tipo     IN VARCHAR2,
                                  p_vc_doc      IN VARCHAR2,
                                  p_nm_cantidad IN NUMBER,
                                  p_nm_error    OUT NUMBER,
                                  p_vc_error    OUT VARCHAR2);

   PROCEDURE actualiza_mas_dos_cta(p_nm_error OUT NUMBER,
                                   p_vc_error OUT VARCHAR2);

   PROCEDURE consulta_buscar_buro(p_vc_dias       VARCHAR2,
                                  p_cur_resultado OUT SYS_REFCURSOR,
                                  p_nm_resp       OUT NUMBER,
                                  p_vc_resp       OUT VARCHAR2);

   PROCEDURE coincidencia_movil(p_nm_error OUT NUMBER,
                                p_vc_error OUT VARCHAR2);

   PROCEDURE insertar_consultados_buro(p_vc_tipo   datos_ubica_pedidos.tipo_identificacion%TYPE,
                                       p_vc_numero IN datos_ubica_pedidos.numero_identificacion%TYPE,
                                       p_nm_resp   OUT NUMBER,
                                       p_vc_resp   OUT VARCHAR2);

   PROCEDURE actualiza_buro_direccion(p_nm_error OUT NUMBER,
                                      p_vc_error OUT VARCHAR2);

   PROCEDURE actualiza_buro_telefono(p_nm_error OUT NUMBER,
                                     p_vc_error OUT VARCHAR2);
END proceso_fraude_fija;
/

