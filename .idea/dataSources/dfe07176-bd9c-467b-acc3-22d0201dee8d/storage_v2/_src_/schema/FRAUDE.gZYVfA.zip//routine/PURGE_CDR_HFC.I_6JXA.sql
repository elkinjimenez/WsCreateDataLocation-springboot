create procedure PURGE_CDR_HFC is
  TYPE t_bulk_collect_test_tab IS TABLE OF CDR_HFC_SRT_TERCEROS_OLD%ROWTYPE;
  l_tab t_bulk_collect_test_tab;

  CURSOR c_data IS   -- select tabla origen
  SELECT  ldl.*
    FROM CDR_HFC_SRT_TERCEROS_OLD ldl WHERE ldl.start_date >= '20140101' and  ldl.start_date <= '20140522' ;

BEGIN

  OPEN c_data;
  LOOP
    FETCH c_data
    BULK COLLECT INTO l_tab LIMIT 1000;

    EXIT WHEN l_tab.count = 0;
    -- Process contents of collection here.

     FORALL i IN l_tab.first .. l_tab.last     ---  insert masivo sobre la tabla destino
         INSERT INTO  CDR_HFC_SRT_TERCEROS  VALUES l_tab(i);
     l_tab.extend;
     commit;
  END LOOP;
  CLOSE c_data;

END;
/

