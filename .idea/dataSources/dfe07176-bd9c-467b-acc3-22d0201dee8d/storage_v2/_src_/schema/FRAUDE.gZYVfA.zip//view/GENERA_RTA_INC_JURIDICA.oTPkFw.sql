create view GENERA_RTA_INC_JURIDICA as
select "SENTENCIA" from (
select
'send-mailmessage -to '|| m.email || ' -from "prevencionfraude.co@claro.com.co" -cc "wilmar.romerol@claro.com.co", "carlos.olivo@claro.com.co", "luis.parra@claro.com.co", "janner.monroy@claro.com.co" -subject "INCUMPLIMIENTO POLITICA DE PREVENTA PERSONA JURIDICA" -Attachments "D:\INCUMPLIMIENTOS_JURIDICA\REPORTE\'|| M.NOMBRE_ARCHIVO ||'.csv" -body "Cordial saludo,  señor distribuidor '||m.nombre_distribuidor||'. En el control a la CIRCULAR PREVENTA PERSONA JURIDICA PARA DISTRIBUIDORES se identifica un presunto incumplimiento a la misma. En esta se indican los casos que deben contar con la autorización de prevencion fraude antes de la reposicion o venta de líneas o equipos financiados. Luego de validar las refutaciones recibidas el resultado final detalla en el archivo adjunto. Se procederá a notificar oficialmente sobre el incumplimiento para las penalizaciones a que haya lugar.Agradecemos reforzar al interior del distribuidor el cumplimiento de esta politica. Cordialmente Equipo de Prevencion Fraude CLARO." -smtpServer outlook.co.attla.corp
'as sentencia
from email_distr_biometria  m
ORDER BY m.nombre_distribuidor asc
)
/

