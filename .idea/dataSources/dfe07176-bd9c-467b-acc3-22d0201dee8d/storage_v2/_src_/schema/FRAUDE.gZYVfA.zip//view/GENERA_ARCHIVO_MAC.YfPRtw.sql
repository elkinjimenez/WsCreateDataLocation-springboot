create view GENERA_ARCHIVO_MAC as
select "SENTENCIA" from (
select
'SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING on
SET LINESIZE 500
spool d:\biometria\mac\'||m.nombre_archivo||'.csv'||chr(59)||'
prompt idsucursal,mac,nit,nonmbre_distribuidor
Select idsucursal||'||chr(39)||','||chr(39)||'||
mac||'||chr(39)||','||chr(39)||'||
nit||'||chr(39)||','||chr(39)||'||
trim(nombre_distribuidor)
from mac_distribuidores C
where c.nit = '||chr(39)||trim(m.nit)||chr(39)||chr(59)||'
SPOOL OFF'||chr(59) as sentencia
from EMAIL_DISTR_BIOMETRIA m
)
/

