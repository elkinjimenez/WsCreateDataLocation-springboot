create PROCEDURE proc_informe_mta
IS
CURSOR c_tmp_datos IS
select t.cuenta,
       t.linea,
       min(t.fecha_instalado) fecha_instalado,
       t.hub nodo_hub_rr, 
       p.poblacion
  from datos_mta_tmp t, nodos_mta r, tmp m, pnn_series p
 where t.cuenta = r.cuenta
 and t.cuenta = m.codigo_cliente_cuenta
 and t.linea between p.serie_ini(+) and p.serie_fin(+)
 group by t.cuenta, t.linea, t.hub, p.poblacion;

   
CURSOR c_tmp_datos1 IS
   select distinct t.cuenta,
                t.mac
  from datos_mta_tmp t, nodos_mta r, tmp m
  where t.cuenta = r.cuenta
  and t.cuenta = m.codigo_cliente_cuenta;
  
CURSOR c_tmp_datos2 IS
   select distinct t.cuenta,
                r.nodo nodo_actual
  from datos_mta_tmp t, nodos_mta r, tmp m
  where t.cuenta = r.cuenta
  and t.cuenta = m.codigo_cliente_cuenta;
   
   
   
CONTADOR NUMBER;
cnt_loop number;

begin
delete datos_informe_mta;
commit;


commit;
contador:= 0;
cnt_loop:= 0;


 
  FOR v_datos_mta IN c_tmp_datos
  LOOP
      cnt_loop:=Cnt_loop+1;
	SELECT COUNT(*)
  INTO CONTADOR
  FROM datos_informe_mta t
  WHERE t.cuenta = V_datos_mta.cuenta;
  
  IF CONTADOR >0  then
  
     UPDATE datos_informe_mta s
     SET 	telefonos = trim(telefonos) ||', '|| v_datos_mta.linea
     where s.cuenta = v_datos_mta.cuenta;
	
	ELSE
       INSERT INTO datos_informe_mta (
        Cuenta,
        Nombre_Cliente,
        Direccion,
        Ciudad,
        Telefonos,
        MAC,
        Fecha_Instalacion,
        Nod_o_Hub_RR,
        Nodo_actual
      )
    	VALUES 
      (
       v_datos_mta.cuenta,
       '',
       '',
       v_datos_mta.poblacion,
       v_datos_mta.linea,
       '',
       v_datos_mta.Fecha_Instalado,
       v_datos_mta.Nodo_Hub_RR,
       ''
       );
       
  end if;

     
 IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
      
  END LOOP;   

  
    FOR v_datos_mta IN c_tmp_datos1
  LOOP
      cnt_loop:=Cnt_loop+1;
	SELECT COUNT(*)
  INTO CONTADOR
  FROM datos_informe_mta t
  WHERE t.cuenta = V_datos_mta.cuenta;
  
  IF CONTADOR >0  then
  
     UPDATE datos_informe_mta s
     SET 	mac = v_datos_mta.mac ||', '|| trim(mac) 
     where s.cuenta = v_datos_mta.cuenta;
	
	ELSE
       INSERT INTO datos_informe_mta (
        Cuenta,
        Nombre_Cliente,
        Direccion,
        Ciudad,
        Telefonos,
        MAC,
        Fecha_Instalacion,
        Nod_o_Hub_RR,
        Nodo_actual
      )
    	VALUES 
      (
       v_datos_mta.cuenta,
       '',
       '',
       '',
       '',
       v_datos_mta.mac,
       '',
       '',
       ''
       );
       
       

  end if;

     
 IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
      
  END LOOP; 
  
  
  
     FOR v_datos_mta IN c_tmp_datos2
  LOOP
      cnt_loop:=Cnt_loop+1;
	SELECT COUNT(*)
  INTO CONTADOR
  FROM datos_informe_mta t
  WHERE t.cuenta = V_datos_mta.cuenta;
  
  IF CONTADOR >0  then
  
     UPDATE datos_informe_mta s
     SET 	s.nodo_actual = v_datos_mta.nodo_actual ||'- '|| trim(nodo_actual) 
     where s.cuenta = v_datos_mta.cuenta
     and instr(v_datos_mta.nodo_actual,s.nod_o_hub_rr) = 0;
	
	ELSE
       INSERT INTO datos_informe_mta (
        Cuenta,
        Nombre_Cliente,
        Direccion,
        Ciudad,
        Telefonos,
        MAC,
        Fecha_Instalacion,
        Nod_o_Hub_RR,
        Nodo_actual
      )
    	VALUES 
      (
       v_datos_mta.cuenta,
       '',
       '',
       '',
       '',
       '',
       '',
       '',
       v_datos_mta.nodo_actual
       );
       
       
  end if;

     
 IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
      
  END LOOP; 
  
  commit;

  
END;
/

