create FUNCTION ubicacion_consultor_fnc(vc_usuario IN VARCHAR2,
                                                   vc_fecha   IN VARCHAR2)
   RETURN VARCHAR2 IS
   RESULT VARCHAR2(100) := NULL;
   tipo   VARCHAR2(1) := NULL;

BEGIN

   tipo := substr(vc_usuario, 1, 1);

   IF tipo = ('D') THEN
      RESULT := NULL;
   ELSE
      SELECT a.ciudad || ' ' || a.descripcion
        INTO RESULT
        FROM kit_equi_finan_consultor a
       WHERE (TRIM(a.usuario_red) = TRIM(vc_usuario) OR
             TRIM(a.usuario_poliedro) = TRIM(vc_usuario))
         AND substr(a.fecha_ultimo_ingreso, 0, 10) =
             substr(vc_fecha, 0, 10)
         AND rownum = 1;
   
   END IF;

   RETURN(RESULT);
EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;
END ubicacion_consultor_fnc;
/

