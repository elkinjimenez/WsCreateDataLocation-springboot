create PROCEDURE proc_acum_LOG_mta
IS

CURSOR c_tmp_mta IS
SELECT 	d.cuenta,
d.hub nodo_rr,
d.fecha_instalado, 
l.mac,
l.nodo,
l.polltime fecha_inicio
FROM log_mta_tmp l, datos_mta d
where l.nodo is not null and l.nodo <> 'null'
and replace(l.mac,':','') = d.mac(+)
--and d.cuenta is null
group by d.cuenta, 
d.hub,
d.fecha_instalado, 
l.mac,
l.nodo,
 	l.polltime
order by d.cuenta,
l.mac,
 	l.polltime,
  l.nodo;
         
         
contador_nodo number;
cnt_loop number;
         
begin         
         
contador_nodo:= 0;
cnt_loop:= 0;

 
  FOR v_mta IN c_tmp_mta
  LOOP
      cnt_loop:=Cnt_loop+1;
	SELECT COUNT(*)
  INTO CONTADOR_nodo
  FROM nodos_mta t
  WHERE cuenta = V_mta.cuenta 
    and replace(mac,':','') = V_mta.mac
   and nodo =  v_mta.nodo;
  
  IF CONTADOR_nodo >0  then
  
     UPDATE nodos_mta
     SET 	Fecha_max = v_mta.fecha_inicio,
     dias = dias + 1
     where cuenta = V_mta.cuenta 
    and replace(mac,':','') = V_mta.mac
   and nodo =  v_mta.nodo;
	
	ELSE
      INSERT INTO nodos_mta (
      cuenta,
      nodo_rr,
      fecha_instalado,
      mac,
      nodo,
      fecha_min,
      dias
      )
    	VALUES 
      (
      v_mta.cuenta,
      v_mta.nodo_rr,
      v_mta.fecha_instalado,
      V_mta.mac,
      V_mta.nodo,
      V_mta.fecha_inicio,
      1
      )
      ;
       
       

  end if;

 IF cnt_loop=200 THEN
         COMMIT;  
         cnt_loop:=0;      
      END IF;
      
  END LOOP;   

  commit;

  
END;
/

