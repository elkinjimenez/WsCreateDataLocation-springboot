create PROCEDURE        PROC_MODELO_predictivo is

  cursor c_mod_predictivo is
    select b.cuenta,
           b.ciudad,
           b.estrato,
           b.zona_riesgo,
           b.canal_venta,
           b.producto,
           b.tipo_cliente,
           b.ppv,
           case
             when b.antigüedad_linea <= 2 then
              'MENOR_2_MESES'
             ELSE
              'MAYOR_2_MESES'
           END ANTIGUEDAD,
           case
             when b.valor_factura <= 100000 then
              'MENOR_100000'
             when b.valor_factura BETWEEN 100000 AND 500000 then
              'MENOR_500000'
             when b.valor_factura BETWEEN 500000 AND 1000000 then
              'MENOR_1000000'
             when b.valor_factura BETWEEN 1000000 AND 2000000 then
              'MENOR_2000000'
             when b.valor_factura BETWEEN 2000000 AND 3000000 then
              'MENOR_3000000'
             ELSE
              'MAYOR_3000000'
           END VR_FACTURA,
           case
             when b.ultimo_pago <= 100000 then
              'MENOR_100000'
             when b.ultimo_pago BETWEEN 100000 AND 500000 then
              'MENOR_500000'
             when b.ultimo_pago BETWEEN 500000 AND 1000000 then
              'MENOR_1000000'
             when b.ultimo_pago BETWEEN 1000000 AND 2000000 then
              'MENOR_2000000'
             when b.ultimo_pago BETWEEN 2000000 AND 3000000 then
              'MENOR_3000000'
             ELSE
              'MAYOR_3000000'
           END VR_PAGO,
           TRIM(b.cheque_devuelto) cheque_devuelto,
           b.edad_mora,
           B.FACTURA_DEVUELTA,
           b.bienvenida,
           b.cantidad_llamadas,
           b.edad_cliente
      from datos_modelo_predictivo b;

  v_score_ciudad       number;
  v_score_estrato      number;
  v_score_zona         number;
  v_score_canal        number;
  v_score_producto     number;
  v_score_tipo_cliente number;
  v_score_ppv          number;
  v_score_antiguedad   number;
  v_score_facturacion  number;
  v_score_pagos        number;
  v_score_cheque       number;
  v_score_mora         number;
  v_score_total        number;
  cnt_loop             number;

Begin

  cnt_loop := 0;

update datos_modelo_predictivo t
set t.score = 0;

commit;

  FOR v_mod_predictivo IN c_mod_predictivo LOOP
    cnt_loop := Cnt_loop + 1;

  begin

    select k.score
      into v_score_ciudad
      from ciudad_predictivo k
     WHERE K.Ciudad = v_mod_predictivo.ciudad;

    select k.score
      into v_score_estrato
      from estrato_predictivo k
     WHERE K.estrato = v_mod_predictivo.estrato;

    select k.score
      into v_score_zona
      from zona_riesgo_predictivo k
     WHERE K.ZONA_RIESGO = v_mod_predictivo.zona_riesgo;

    select k.score
      into v_score_canal
      from canal_predictivo k
     WHERE K.Canal = v_mod_predictivo.canal_venta;

    select k.score
      into v_score_producto
      from producto_predictivo k
     WHERE K.producto = v_mod_predictivo.producto;

    select k.score
      into v_score_tipo_cliente
      from tipo_cliente_predictivo k
     WHERE K.tipo_cliente = v_mod_predictivo.tipo_cliente;

    select k.score
      into v_score_ppv
      from ppv_predictivo k
     WHERE K.ppv = v_mod_predictivo.ppv;

    select k.score
      into v_score_antiguedad
      from antiguedad_predictivo k
     WHERE K.ANTIGUEDAD = v_mod_predictivo.antiguedad;

    select k.score
      into v_score_facturacion
      from facturacion_predictivo k
     WHERE K.FACTURACION = v_mod_predictivo.vr_factura;

    select k.score
      into v_score_pagos
      from pagos_predictivo k
     WHERE K.PAGOS = v_mod_predictivo.vr_pago;

    select k.score
      into v_score_cheque
      from cheque_predictivo k
     WHERE K.CHEQUE_DEVUELTO = v_mod_predictivo.cheque_devuelto;

    select k.score
      into v_score_mora
      from edad_mora_predictivo k
     WHERE K.EDAD_MORA = v_mod_predictivo.edad_mora;

  end;



    Update datos_modelo_predictivo m
       set m.score = v_score_ciudad + v_score_estrato + v_score_zona +
                     v_score_canal + v_score_producto + v_score_tipo_cliente +
                     v_score_ppv + v_score_antiguedad + v_score_facturacion +
                     v_score_pagos + v_score_cheque + v_score_mora
     where m.cuenta = v_mod_predictivo.cuenta;

    IF cnt_loop = 200 THEN
      COMMIT;
      cnt_loop := 0;
    END IF;

    COMMIT;

  END LOOP;

END;
/

