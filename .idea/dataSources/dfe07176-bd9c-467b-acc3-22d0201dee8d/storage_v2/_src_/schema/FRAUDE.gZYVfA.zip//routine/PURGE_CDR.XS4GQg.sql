create procedure PURGE_CDR is
  TYPE t_bulk_collect_test_tab IS TABLE OF CDR_HUAWEI_IP_TMP_OLD%ROWTYPE;
  l_tab t_bulk_collect_test_tab;

  CURSOR c_data IS   -- select tabla origen
  SELECT  ldl.*
    FROM CDR_HUAWEI_IP_TMP_OLD ldl WHERE ldl.serial_number > '4164166271'  and ldl.serial_number < '4293092579';

BEGIN

  OPEN c_data;
  LOOP
    FETCH c_data
    BULK COLLECT INTO l_tab LIMIT 1000;

    EXIT WHEN l_tab.count = 0;
    -- Process contents of collection here.

     FORALL i IN l_tab.first .. l_tab.last     ---  insert masivo sobre la tabla destino
         INSERT INTO  CDR_HUAWEI_IP_TMP  VALUES l_tab(i);
     l_tab.extend;
     commit;
  END LOOP;
  CLOSE c_data;

END;
/

