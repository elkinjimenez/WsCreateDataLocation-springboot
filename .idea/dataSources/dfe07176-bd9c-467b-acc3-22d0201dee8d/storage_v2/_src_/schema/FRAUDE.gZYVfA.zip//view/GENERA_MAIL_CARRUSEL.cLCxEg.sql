create view GENERA_MAIL_CARRUSEL as
select "SENTENCIA" from (
select
'send-mailmessage -to '|| m.mail || ' -from "carlos.ramirez.r@claro.com.co" -cc "wilmar.romerol@claro.com.co", "carlos.ramirez.r@claro.com.co", "prevencionfraude.co@claro.com.co" -subject "Reporte Automático Carrusel Comercial" -Attachments "D:\CARRUSEL_ALL\'|| m.archivo ||'.csv" -body "Cordial saludo,  En el archivo adjunto se detallan las ventas de '||m.agente||' que ingresaron con tipología de carrusel comercial. Debido a esto las cuentas relacionadas deben ser validadas para determinar si aplica el carrusel comercial. Ante cualquier inquietud por favor responder al correo prevencionfraude.co@claro.com.co.  Muchas Gracias.    Cordialmente Equipo de Prevencion Fraude. " -smtpServer webmail.telmexla.com.co
'as sentencia
from mail_agentes m
ORDER BY agente asc
)
/

