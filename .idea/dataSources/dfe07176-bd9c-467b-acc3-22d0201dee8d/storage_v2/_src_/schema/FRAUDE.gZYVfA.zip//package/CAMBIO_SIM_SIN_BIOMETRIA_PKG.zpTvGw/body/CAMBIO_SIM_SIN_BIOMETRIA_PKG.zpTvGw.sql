create PACKAGE BODY cambio_sim_sin_biometria_pkg IS

   PROCEDURE correos_cliente(p_hora          IN NUMBER,
                             p_cur_resultado OUT SYS_REFCURSOR,
                             p_nm_resp       OUT NUMBER,
                             p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT p.min, p.tipo_doc, p.documento, p.email, p.id_authorizathion,
                p.fecha_registro, p.envio_correo, p.rowid
           FROM ctr_camsim_sin_biometria p
          WHERE 1 = 1
          --se incluye enviar coreo de usuari activ 13/04/2020
            AND p.id_authorizathion in ( '0','-1')
            AND p.email IS NOT NULL
            AND p.envio_correo IS NULL
            AND to_date(substr(p.fecha_registro, 0, 16),
                        'dd/mm/yyyy HH24:MI') >= SYSDATE - p_hora / 24
          --MODIFICACION, NO ENVIAR CORREO A LOS DE REPOSICIONES
            AND P.TEXT1 not like '%reposición%'
          ORDER BY to_date(substr(p.fecha_registro, 0, 10), 'dd/mm/yyyy');
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1204;
         p_vc_resp       := 'Error al buscar los correos de los cambios de sim sin biometria : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END correos_cliente;

   PROCEDURE pr_actualiza(p_vc_consecutivo IN VARCHAR2,
                          p_vc_resultado IN VARCHAR2,
                          p_nm_resp        OUT NUMBER,
                          p_vc_resp        OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      UPDATE ctr_camsim_sin_biometria p
         SET p.envio_correo = p_vc_resultado
       WHERE 1 = 1
         AND p.rowid = p_vc_consecutivo;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1204;
         p_vc_resp       := 'Error al ACTUALIZAR ROWID : ' ||p_vc_consecutivo||' ERROR: '||
                            SQLERRM;
   END pr_actualiza;

END cambio_sim_sin_biometria_pkg;
/

