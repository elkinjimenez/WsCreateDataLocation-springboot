create PACKAGE BODY encripcion_pkg AS

   --**********************************************************************************************************
   --** OBJETIVO             : CONTIENE LAS UTILIDADES DE ENCRIPCION Y DESENCRIPCION
   --** ESQUEMA              : UTIL
   --** NOMBRE               : QB_ENCRIPCION / BODY
   --** AUTOR                : JAIRO ANDRES RIVERA RODRIGUEZ
   --** FECHA MODIFICACION   : 24/AGOSTO/2011
   --**********************************************************************************************************

   crypt_raw RAW(2000);
   crypt_str VARCHAR(2000);
   -- LLAVE DE ENCRIPCION
   key_encrip VARCHAR(255) := 'ASXRFGTR';

   --------------------------------------------------------------------------
   -------------------- FUNCION QUE CODIFICA UN TEXTO------------------------
   --------------------------------------------------------------------------

   FUNCTION fb_encriptar(txt_encrip VARCHAR2) RETURN RAW AS
      l        INTEGER := length(txt_encrip);
      i        INTEGER;
      padblock RAW(2000);
      cle      RAW(8) := utl_raw.cast_to_raw(key_encrip);
   BEGIN
      i        := 8 - MOD(l, 8);
      padblock := utl_raw.cast_to_raw(txt_encrip || rpad(chr(i), i, chr(i)));
      dbms_obfuscation_toolkit.desencrypt(input => padblock, key => cle,
                                          encrypted_data => crypt_raw);
      RETURN crypt_raw;
   EXCEPTION
      WHEN OTHERS THEN
               crypt_raw:=NULL;
               RETURN crypt_raw;
   END;

   --------------------------------------------------------------------------
   ------------------- FUNCION QUE DECODIFICA UN TEXTO-----------------------
   --------------------------------------------------------------------------

   FUNCTION fb_descencriptar(txt_desencrip VARCHAR2) RETURN VARCHAR2 AS
      l         NUMBER;
      cle       RAW(8) := utl_raw.cast_to_raw(key_encrip);
      crypt_raw RAW(2000) := utl_raw.cast_to_raw(utl_raw.cast_to_varchar2(txt_desencrip));
   BEGIN
      dbms_obfuscation_toolkit.desdecrypt(input => txt_desencrip,
                                          key => cle,
                                          decrypted_data => crypt_raw);
      crypt_str := utl_raw.cast_to_varchar2(crypt_raw);
      l         := length(crypt_str);
      crypt_str := rpad(crypt_str, l - ascii(substr(crypt_str, l)));
      RETURN crypt_str;
   
   EXCEPTION
      WHEN OTHERS THEN
        crypt_raw:=NULL;
        RETURN crypt_raw;
   END;
END encripcion_pkg;
/

