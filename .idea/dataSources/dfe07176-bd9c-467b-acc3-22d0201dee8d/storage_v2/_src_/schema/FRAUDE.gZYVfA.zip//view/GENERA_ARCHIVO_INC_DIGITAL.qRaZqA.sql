create view GENERA_ARCHIVO_INC_DIGITAL as
select "SENTENCIA" from (
select
'SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING on
SET LINESIZE 500
spool d:\biometria\reporte\'||m.nombre_archivo||'.csv'||chr(59)||'
prompt min,mercado,plan,codigo_agente,nombre_agente,activacion,documento_cliente,canal,region
Select
t.tele_numb||'||chr(39)||','||chr(39)||'||
t.mercado||'||chr(39)||','||chr(39)||'||
t.plan||'||chr(39)||','||chr(39)||'||
t.agent_code||'||chr(39)||','||chr(39)||'||
t.agent_name||'||chr(39)||','||chr(39)||'||
t.activacion||'||chr(39)||','||chr(39)||'||
t.ssn||'||chr(39)||','||chr(39)||'||
t.canal||'||chr(39)||','||chr(39)||'||
t.region
from VENTAS_DIGITALES t, datos_distribuidores d
where TRIM(t.biometria) =  '||chr(39)||'S'||chr(39)||'
AND DIGITAL IS NULL
AND t.CANAL = '||chr(39)||'3. DISTRIBUIDORES'||chr(39)||'
and  t.agent_code = d.cod_distribuidor and d.nit = '||chr(39)||trim(m.nit)||chr(39)||''||chr(59)||'
SPOOL OFF'||chr(59) as sentencia
from EMAIL_DISTR_BIOMETRIA m
)
/

