create view BORRA_CDR_INTERMEDIO as
select "SENTENCIA" from (
select
'open srt:SUS3RT20@10.244.143.197:22
cd /roc/fm/srt/bk_data
rm '||s.nombre_archivo||'
close
'as sentencia
from name_file_intermedio s
ORDER BY nombre_archivo desc
)
/

