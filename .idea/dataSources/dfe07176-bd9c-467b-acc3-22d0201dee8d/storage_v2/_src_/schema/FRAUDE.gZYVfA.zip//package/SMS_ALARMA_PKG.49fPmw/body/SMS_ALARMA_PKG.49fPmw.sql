create PACKAGE BODY sms_alarma_pkg IS

   -- Private type declarations
   PROCEDURE inserta_repos(vc_mensajes OUT VARCHAR2,
                           nm_error    OUT NUMBER) IS
   
   BEGIN
      vc_mensajes := 'OK';
      nm_error    := '0';
   
      INSERT INTO sms_alarma
         (tipo_doc, no_doc, tramite_alarma)
         SELECT '1', a.documento, 'REPOSICION'
           FROM repos_diario_repo a
          WHERE to_date(substr(a.fecregis, 0, 10), 'dd/mm/yyyy') >=
                to_date(SYSDATE - 8, 'dd/mm/yyyy')
            AND a.biometria = 'NO'
         
         ;
   
      COMMIT;
   END inserta_repos;

   PROCEDURE consulta_tramites(p_nm_dias       NUMBER,
                               p_cur_resultado OUT SYS_REFCURSOR,
                               p_nm_resp       OUT NUMBER,
                               p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      OPEN p_cur_resultado FOR
         SELECT DISTINCT '1', a.documento, 'REPOSICION'
           FROM repos_diario_repo a
          WHERE to_date(substr(a.fecregis, 0, 10), 'dd/mm/yyyy') >=
                to_date(SYSDATE - p_nm_dias, 'dd/mm/yyyy')
            AND a.biometria = 'NO';
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := -1201;
         p_vc_resp := 'Error al generar cursor de kit financiado : ' ||
                      SQLERRM;
   END consulta_tramites;

   PROCEDURE consulta_kit_prepago(p_nm_dias       NUMBER,
                                  p_cur_resultado OUT SYS_REFCURSOR,
                                  p_nm_resp       OUT NUMBER,
                                  p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT DISTINCT a.documento, substr(a.fecregis, 0, 10), a.co_id
           FROM kit_equipo_financiado a
          WHERE to_date(substr(a.fecregis, 0, 10), 'dd/mm/yyyy') =
                to_date(to_char(SYSDATE - p_nm_dias, 'dd/mm/yyyy'),
                        'dd/mm/yyyy')
            AND upper(a.tipo_doc) = 'CEDULA'
               --and a.documento='32292713'
            AND a.biometria = 'NO'
         /*  UNION
         SELECT '1015395613', to_char(SYSDATE - 1, 'dd/mm/yyyy'), '0'
            FROM dual*/
         ;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1202;
         p_vc_resp       := 'Error al generar cursor  : ' || SQLERRM;
         p_cur_resultado := NULL;
   END consulta_kit_prepago;

   PROCEDURE consulta_repos_financiadas(p_nm_dias       NUMBER,
                                        p_cur_resultado OUT SYS_REFCURSOR,
                                        p_nm_resp       OUT NUMBER,
                                        p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT DISTINCT a.documento, substr(a.fecregis, 0, 10), a.co_id
           FROM repos_diario_repo a
          WHERE to_date(substr(a.fecregis, 0, 10), 'dd/mm/yyyy') =
                to_date(to_char(SYSDATE - p_nm_dias, 'dd/mm/yyyy'),
                        'dd/mm/yyyy')
               --and a.documento='32292713'
            AND a.biometria = 'NO';
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al generar cursor de repos  : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END consulta_repos_financiadas;

   --MODIFICACION 13/02/2020
   PROCEDURE consulta_ventas_movil(p_nm_dias       NUMBER,
                                   p_cur_resultado OUT SYS_REFCURSOR,
                                   p_nm_resp       OUT NUMBER,
                                   p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT DISTINCT a.numero_doc, substr(a.fecregis, 0, 10), a.co_id,
                         a.custcode, a.min
           FROM ventas_movil a
          WHERE to_date(substr(a.fecregis, 0, 10), 'dd/mm/yyyy') =
                to_date(to_char(SYSDATE - p_nm_dias, 'dd/mm/yyyy'),
                        'dd/mm/yyyy')
               --and a.documento='32292713'
            AND a.herramienta_aprobacion NOT IN ('BIOMETRIA', 'OTP')
            AND substr(a.custcode, 0, 1) <> ('8');
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al generar cursor de ventas_movil  : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END consulta_ventas_movil;
   --FIN MODIFICACION 13/02/2020
   PROCEDURE inserta_tramite(vc_tramite          VARCHAR2,
                             vc_fecha_tramite    VARCHAR2,
                             vc_contrato_tramite VARCHAR2,
                             vc_documento        VARCHAR2,
                             vc_tel_antiguo      VARCHAR2,
                             vc_contrato_antiguo VARCHAR2,
                             vc_observaciones    alarma_mensajes.observaciones%TYPE,
                             p_nm_resp           OUT NUMBER,
                             p_vc_resp           OUT VARCHAR2) IS
   
      ln_consecutivo LONG;
      nm_valida      NUMBER := 0;
   BEGIN
      p_nm_resp := 0;
   
      --BUSCAR QUE EL MISMO CLIENTE TENGA LA MISMA INFO EN LAS DOS BD. PARA NO DUPLICAR MENSAJES
      SELECT COUNT('1')
        INTO nm_valida
        FROM alarma_mensajes p
       WHERE p.documento = vc_documento
         AND p.telefono_antiguo = vc_tel_antiguo
         AND p.fecha_tramite = vc_fecha_tramite
         AND p.tramite = vc_tramite;
   
      IF vc_tel_antiguo <> '0' THEN
      
         IF nm_valida = 0 THEN
            ln_consecutivo := alarma_mensajes_seq.nextval;
         
            INSERT INTO alarma_mensajes
               (consecutivo, tramite, fecha_tramite, contrato_tramite,
                documento, telefono_antiguo, contrato_antiguo, observaciones,
                estado, fecha_proceso)
            VALUES
               (ln_consecutivo, vc_tramite, vc_fecha_tramite,
                vc_contrato_tramite, vc_documento, vc_tel_antiguo,
                vc_contrato_antiguo, vc_observaciones, p_nm_resp, p_vc_resp);
         
            COMMIT;
         ELSE
            p_nm_resp := 0;
            p_vc_resp := 'Datos ya se encuentran registrados para el cliente';
         END IF;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -1;
         p_vc_resp := SQLERRM;
   END inserta_tramite;

   --20/03/2020 --> Creacion de archivos POM por tramite
   PROCEDURE consulta_tramites_pom(p_nm_dias       NUMBER,
                                   p_vc_tramite    VARCHAR2,
                                   p_cur_resultado OUT SYS_REFCURSOR,
                                   p_nm_resp       OUT NUMBER,
                                   p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT a.consecutivo, a.fecha_tramite, a.documento,
                a.telefono_antiguo
           FROM alarma_mensajes a
          WHERE a.tramite = upper(p_vc_tramite)
            AND a.fecha_tramite =
                to_char(SYSDATE - p_nm_dias, 'dd/mm/yyyy');
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := -1201;
         p_vc_resp := 'Error al generar cursor de tramites de POM : ' ||
                      SQLERRM;
   END consulta_tramites_pom;

   PROCEDURE consulta_alarma(p_vc_tipo    IN VARCHAR2,
                             cursoralarma OUT SYS_REFCURSOR,
                             p_nm_resp    OUT NUMBER,
                             p_vc_resp    OUT VARCHAR2) IS
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 0;
   
      IF (p_vc_tipo = 'VENTAS_MOVILES') THEN
      
         OPEN cursoralarma FOR
            SELECT DISTINCT b.consecutivo, b.telefono_antiguo, b.documento,
                            h.custcode, h.co_id,
                            substr(h.fecregis, 0, 10) fecha_activacion, 'a',
                            '31', 'CAMP_SMS', '24',
                            'Se realiza validación por el proceso POM consecutivo ' ||
                             b.consecutivo || ' el dia ' || b.fecha_tramite,
                            'CAR', 11, 18
              FROM alarma_rta_pom a, alarma_mensajes b, ventas_movil h
             WHERE a.consecutivo = b.consecutivo
               AND b.documento = h.numero_doc
               AND a.tramite = 'VENTAS_MOVIL'
               AND b.fecha_tramite = substr(h.fecregis, 0, 10)
               AND h.herramienta_aprobacion NOT IN ('BIOMETRIA', 'OTP')
               AND a.procesado_sus IS NULL
               AND substr(h.custcode, 0, 1) NOT IN ('8') --No tomar custcode que son SPLIT BILLING
               AND a.m_movil_no_confirma = '2';
      
      ELSIF (p_vc_tipo = 'KIT_PREPAGO') THEN
         OPEN cursoralarma FOR
            SELECT DISTINCT b.consecutivo, b.telefono_antiguo, b.documento,
                            h.custcode, h.co_id,
                            substr(h.fecregis, 0, 10) fecha_activacion, 'a',
                            '31', 'CAMP_SMS', '24',
                            'Se realiza validación por el proceso POM consecutivo ' ||
                             b.consecutivo || ' el dia ' || b.fecha_tramite,
                            'CAR', 11, 18
              FROM alarma_rta_pom a, alarma_mensajes b,
                   kit_equipo_financiado h
             WHERE a.consecutivo = b.consecutivo
               AND b.documento = h.documento
               AND a.tramite = 'KIT_FINANCIADO'
               AND b.fecha_tramite = substr(h.fecregis, 0, 10)
               AND h.biometria IN ('NO')
               AND a.procesado_sus IS NULL
               AND substr(h.text1, 0, 1) NOT IN ('8') --No tomar custcode que son SPLIT BILLING
               AND a.m_movil_no_confirma = '2';
      ELSE
         --REPOS
         OPEN cursoralarma FOR
            SELECT DISTINCT b.consecutivo, b.telefono_antiguo, b.documento,
                            h.custcode, h.co_id,
                            substr(h.fecregis, 0, 10) fecha_activacion, 'a',
                            '31', 'CAMP_SMS', '24',
                            'Se realiza validación por el proceso POM consecutivo ' ||
                             b.consecutivo || ' el dia ' || b.fecha_tramite,
                            'CAR', 11, 18
              FROM alarma_rta_pom a, alarma_mensajes b, repos_diario_repo h
             WHERE a.consecutivo = b.consecutivo
               AND b.documento = h.documento
               AND a.tramite = 'REPOSICIONES EQUIPO'
               AND b.fecha_tramite = substr(h.fecregis, 0, 10)
               AND h.biometria IN ('NO')
               AND a.procesado_sus IS NULL
               AND substr(h.text1, 0, 1) NOT IN ('8') --No tomar custcode que son SPLIT BILLING
               AND a.m_movil_no_confirma = '2';
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := -1201;
         p_vc_resp := 'Error al generar cursor de tramites de POM : ' ||
                      SQLERRM;
   END consulta_alarma;

   PROCEDURE actualiza_alarma_rta_pom(p_vc_consecutivo IN VARCHAR2,
                                      p_vc_custcode    IN VARCHAR2,
                                      p_nm_resp        OUT NUMBER,
                                      p_vc_resp        OUT VARCHAR2) IS
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 0;
   
      UPDATE alarma_rta_pom a
         SET a.procesado_sus = 'SI',
             a.fecha_envio_sus = to_char(SYSDATE, 'dd/mm/yyyy'),
             a.custcode = p_vc_custcode
       WHERE a.consecutivo = p_vc_consecutivo;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := SQLCODE;
         p_vc_resp := 'Error al actualiza rta POM : ' || SQLERRM;
   END actualiza_alarma_rta_pom;

   --modificacion 04/09/2020 inclusion de vents de tecnologia asociadoa hogares
   --FIN MODIFICACION 13/02/2020
   PROCEDURE inserta_tramite_sal(vc_tramite          VARCHAR2,
                                 vc_fecha_tramite    VARCHAR2,
                                 vc_contrato_tramite VARCHAR2,
                                 vc_documento        VARCHAR2,
                                 vc_tel_antiguo      VARCHAR2,
                                 vc_contrato_antiguo VARCHAR2,
                                 vc_observaciones    alarma_mensajes.observaciones%TYPE,
                                 p_nm_consecutivo    OUT NUMBER,
                                 p_nm_resp           OUT NUMBER,
                                 p_vc_resp           OUT VARCHAR2) IS
   
      ln_consecutivo NUMBER;
      nm_valida      NUMBER := 0;
   BEGIN
      p_nm_resp := 0;
   
      --BUSCAR QUE EL MISMO CLIENTE TENGA LA MISMA INFO EN LAS DOS BD. PARA NO DUPLICAR MENSAJES
      SELECT COUNT('1')
        INTO nm_valida
        FROM alarma_mensajes p
       WHERE p.documento = vc_documento
         AND p.telefono_antiguo = vc_tel_antiguo
         AND p.fecha_tramite = vc_fecha_tramite
         AND p.tramite = vc_tramite;
   
      IF vc_tel_antiguo <> '0' THEN
      
         IF nm_valida = 0 THEN
            ln_consecutivo   := alarma_mensajes_seq.nextval;
            p_nm_consecutivo := ln_consecutivo;
            INSERT INTO alarma_mensajes
               (consecutivo, tramite, fecha_tramite, contrato_tramite,
                documento, telefono_antiguo, contrato_antiguo, observaciones,
                estado, fecha_proceso)
            VALUES
               (ln_consecutivo, vc_tramite, vc_fecha_tramite,
                vc_contrato_tramite, vc_documento, vc_tel_antiguo,
                vc_contrato_antiguo, vc_observaciones, p_nm_resp, p_vc_resp);
         
            COMMIT;
         ELSE
            p_nm_resp := 0;
            p_vc_resp := 'Datos ya se encuentran registrados para el cliente';
         END IF;
      END IF;
   
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -1;
         p_vc_resp := SQLERRM;
   END inserta_tramite_sal;

   PROCEDURE consulta_tecnologia(p_nm_dias       NUMBER,
                                 p_cur_resultado OUT SYS_REFCURSOR,
                                 p_nm_resp       OUT NUMBER,
                                 p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT DISTINCT a.documentnumber, substr(a.executedate, 0, 10),
                         a.customerid
           FROM ventas_tecnologia_reservation a
          WHERE 1 = 1
            AND a.enviar_pom IS NULL
            AND a.herramienta NOT IN ('BIOMETRIA')
            AND upper(a.accounttype) IN ('F')
            AND to_date(substr(a.executedate, 0, 10), 'dd/mm/yyyy') =
                to_date(to_char(SYSDATE - p_nm_dias, 'dd/mm/yyyy'),
                        'dd/mm/yyyy')
             UNION
         SELECT to_number('53040613'), to_char(SYSDATE - 1, 'dd/mm/yyyy'), to_number('0')
            FROM dual                                     
                        ;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al generar cursor de ventas detecnologia hogares  : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END consulta_tecnologia;

   PROCEDURE radicacion_tecnologia_movil(p_vc_tipo        IN VARCHAR2,
                                         cursorradicacion OUT SYS_REFCURSOR,
                                         p_nm_resp        OUT NUMBER,
                                         p_vc_resp        OUT VARCHAR2) IS
   
      vc_tipo VARCHAR2(5);
   
   BEGIN
   
      p_nm_resp := 0;
      p_vc_resp := 0;
   
      IF (p_vc_tipo = 'VENTA_TECNOLOGIA_MOVIL') THEN
         vc_tipo := 'M';
      ELSE
         vc_tipo := 'F';
      END IF;
   
      OPEN cursorradicacion FOR
         SELECT DISTINCT b.consecutivo, b.telefono_antiguo, b.documento,
                         h.custcode, h.contractid,
                         substr(h.executedate, 0, 10) fecha_activacion, 'a',
                         '31', 'CAMP_SMS', '24',
                         'Se realiza validación por el proceso POM consecutivo ' ||
                          b.consecutivo || ' el dia ' || b.fecha_tramite,
                         'CAR', 11, 18
           FROM alarma_rta_pom a, alarma_mensajes b,
                ventas_tecnologia_reservation h
          WHERE a.consecutivo = b.consecutivo
            AND b.documento = to_char(h.documentnumber)
            AND b.fecha_tramite = substr(h.executedate, 0, 10)
            AND h.herramienta NOT IN ('BIOMETRIA')
            AND a.procesado_sus IS NULL
            AND substr(h.custcode, 0, 1) NOT IN ('8') --No tomar custcode que son SPLIT BILLING
            AND a.m_movil_no_confirma = '2'
            AND h.accounttype = vc_tipo;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := -1201;
         p_vc_resp := 'Error al generar cursor de respuestas de radicacion : ' ||
                      p_vc_tipo || SQLERRM;
   END radicacion_tecnologia_movil;

   --18/10/2020 Insertar en tabla de whast app
   PROCEDURE inserta_tramite_whastapp(vc_documento        VARCHAR2,
                                      vc_custcode         VARCHAR2,
                                      vc_customer_id      VARCHAR2,
                                      vc_co_id            VARCHAR2,
                                      vc_fecha_activacion VARCHAR2,
                                      vc_min_venta        VARCHAR2,
                                      p_nm_resp           OUT NUMBER,
                                      p_vc_resp           OUT VARCHAR2) IS
   
      vc_min_celular VARCHAR2(50);
      nm_cantidad    NUMBER := 0;
   
   BEGIN
      p_nm_resp := 0;
      BEGIN
      
         SELECT COUNT('1')
           INTO nm_cantidad
           FROM alarma_whatsapp_vm v
          WHERE v.custcode = vc_custcode
            AND v.numero_documento = vc_documento;
           
         if nm_cantidad=0 then
        
         --BUSCAR QUE EL MISMO CLIENTE TENGA LA MISMA INFO EN LAS DOS BD. PARA NO DUPLICAR MENSAJES
         SELECT b.celular_21
           INTO vc_min_celular
           FROM datos_ubicacion b
          WHERE b.numero_identificacion = vc_documento;
      
      
         INSERT INTO alarma_whatsapp_vm
            (numero_documento, custcode, customer_id, co_id,
             fecha_activacion, min_venta, telefono_contacto)
         VALUES
            (vc_documento, vc_custcode, vc_customer_id, vc_co_id,
             vc_fecha_activacion, vc_min_venta, vc_min_celular);
      
         COMMIT;
         end if;
      EXCEPTION
         WHEN OTHERS THEN
            INSERT INTO alarma_whatsapp_vm
               (numero_documento, custcode, customer_id, co_id,
                fecha_activacion, min_venta)
            VALUES
               (vc_documento, vc_custcode, vc_customer_id, vc_co_id,
                vc_fecha_activacion, vc_min_venta);
         
            COMMIT;
      END;
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -2;
         p_vc_resp := SQLERRM || 'Error al insertar en tabla d whast app';
   END inserta_tramite_whastapp;

END sms_alarma_pkg;
/

