create PROCEDURE proc_sus_subex_hfc
IS
CURSOR c_tmp_datos IS
select *
  from tmp_subex_hfc
 ;



CONTADOR NUMBER;
cnt_loop number;

begin
delete suscriptores_subex_hfc;
commit;


commit;
contador:= 0;
cnt_loop:= 0;



  FOR v_datos_sus IN c_tmp_datos
  LOOP
      cnt_loop:=Cnt_loop+1;
  SELECT COUNT(*)
  INTO CONTADOR
  FROM suscriptores_subex_hfc t
  WHERE t.cuenta = V_datos_sus.cuenta;
  --and t.telefono is null;

  IF CONTADOR >0  then

     UPDATE suscriptores_subex_hfc s
     SET  tipo_servicios  = trim(tipo_servicios)  ||', '|| v_datos_sus.tipo_servicios,
       servicios  = trim(servicios)  ||', '|| v_datos_sus.servicios
     --  tipo_equipo  = trim(tipo_equipo)  ||', '|| v_datos_sus.tipo_equipo,
     --  Mac = trim(Mac)  ||', '|| v_datos_sus.Mac,
     --  direccion_mac = trim(direccion_mac)  ||', '|| v_datos_sus.direccion_mac
     where s.cuenta = v_datos_sus.cuenta;

  ELSE
       INSERT INTO suscriptores_subex_hfc (
                  TELEFONO,
                  CUENTA,
                  NOMBRE1,
                  NOMBRE2,
                  NOMBRE3,
                  DIRECCION1,
                  DIRECCION2,
                  DIRECCION3,
                  TEL_CASA,
                  TEL_OFICINA,
                  TERCER_TELEFONO,
                  TIPO_DOC,
                  CC_NIT,
                  TIPO_SERVICIOS,
                  Servicios,
                  FECHA_DIGITACION,
                  DIVISION,
                  CIUDAD,
                  TIPO_CLIENTE,
                  NUMERO_CONTRATO,
                  SALDO_ACTUAL,
                  RENTA_MENSUAL,
                  CODIGO_VENDEDOR,
                  Nombre_asesor,
                  COD_SUSCRIPTOR_PROBLEMA,
                  ESTADO,
                  DESC_ESTADO,
                  NODO,
                  Canal_venta,
                  Canal_venta1,
                  TARIFA,
                  CAMPAÑA,
                  Fecha_venc_campaña,
                  Ultima_OT,
                  Fecha_Ultima_ot,
                  User_creac_OT,
                  Cod_Movil,
                  FECHA_DESCONEXION,
                  RAZON_DESCONEXION,
                  Codigo_Home_pass,
                  VALOR_ULTIMA_FACTURA,
                  Fecha_ULTIMA_factura,
                  OT,
                  Tipo_red,
                  Descripcion_Ciudad,
                  DIVISIONAL,
                  Desc_movil,
                  Des_nodo,
                  TIPO_Equipo,
                  MAC,
                  DIRECCION_MAC,
                  HUB,
                  CANTIDAD,
                  FECHA_INSTALADO,
                  Especialista,
                  Unidad_Gestion_venta,
                  Ciclo_facturacion
      )
      VALUES
      (
                  v_datos_sus.TELEFONO,
                  v_datos_sus.CUENTA,
                  v_datos_sus.NOMBRE1,
                  v_datos_sus.NOMBRE2,
                  v_datos_sus.NOMBRE3,
                  v_datos_sus.DIRECCION1,
                  v_datos_sus.DIRECCION2,
                  v_datos_sus.DIRECCION3,
                  v_datos_sus.TEL_CASA,
                  v_datos_sus.TEL_OFICINA,
                  v_datos_sus.TERCER_TELEFONO,
                  v_datos_sus.TIPO_DOC,
                  v_datos_sus.CC_NIT,
                  v_datos_sus.TIPO_SERVICIOS,
                  v_datos_sus.Servicios,
                  v_datos_sus.FECHA_DIGITACION,
                  v_datos_sus.DIVISION,
                  v_datos_sus.CIUDAD,
                  v_datos_sus.TIPO_CLIENTE,
                  v_datos_sus.NUMERO_CONTRATO,
                  v_datos_sus.SALDO_ACTUAL,
                  v_datos_sus.RENTA_MENSUAL,
                  v_datos_sus.CODIGO_VENDEDOR,
                  v_datos_sus.Nombre_asesor,
                  v_datos_sus.COD_SUSCRIPTOR_PROBLEMA,
                  v_datos_sus.ESTADO,
                  v_datos_sus.DESC_ESTADO,
                  v_datos_sus.NODO,
                  v_datos_sus.Canal_venta,
                  v_datos_sus.Canal_venta1,
                  v_datos_sus.TARIFA,
                  v_datos_sus.CAMPAÑA,
                  v_datos_sus.Fecha_venc_campaña,
                  v_datos_sus.Ultima_OT,
                  v_datos_sus.Fecha_Ultima_ot,
                  v_datos_sus.User_creac_OT,
                  v_datos_sus.Cod_Movil,
                  v_datos_sus.FECHA_DESCONEXION,
                  v_datos_sus.RAZON_DESCONEXION,
                  v_datos_sus.Codigo_Home_pass,
                  v_datos_sus.VALOR_ULTIMA_FACTURA,
                  v_datos_sus.Fecha_ULTIMA_factura,
                  v_datos_sus.OT,
                  v_datos_sus.Tipo_red,
                  v_datos_sus.Descripcion_Ciudad,
                  v_datos_sus.DIVISIONAL,
                  v_datos_sus.Desc_movil,
                  v_datos_sus.Des_nodo,
                  v_datos_sus.TIPO_Equipo,
                  v_datos_sus.MAC,
                  v_datos_sus.DIRECCION_MAC,
                  v_datos_sus.HUB,
                  v_datos_sus.CANTIDAD,
                  v_datos_sus.FECHA_INSTALADO,
                  v_datos_sus.Especialista,
                  v_datos_sus.Unidad_Gestion_venta,
                  v_datos_sus.Ciclo_facturacion
       );

  end if;


 IF cnt_loop=200 THEN
         COMMIT;
         cnt_loop:=0;
      END IF;

  END LOOP;


  commit;


END;
/

