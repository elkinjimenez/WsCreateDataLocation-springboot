create trigger TRG_VENTAS_DIGITADAS_AUTO_AF
    before insert
    on VENTAS_DIGITADAS_FIJA_AUTO
    for each row
DECLARE
   -- local variables here
   nm_existe      NUMBER := 0;
   nm_existe_vf   NUMBER := 0;
   vc_nodo_riesgo VARCHAR2(10) := 0;

BEGIN

   /*   IF upper(:new.cvatyp) = 'PY' THEN
      :new.biometria       := 'NO';
      :new.evidente        := 'NO';
      :new.otp             := 'NO';
      :new.idvision        := 'NO';
      :new.incumplimiento  := 'NO_APLICA';
      :new.razon           := 'CUENTA PYME';
      :new.fecha_procesado := to_char(SYSDATE, 'dd/mm/yyyy');
      :new.procesado       := 'SI';
   ELSE*/

   --Validacion DTH
   IF upper(:new.cvaarg) IN ('DTH','DGH') THEN
      :new.dth := 'SI';
   ELSE
      :new.dth := 'NO';
   END IF;
   
   --Ciudad Riesgosa
   vc_nodo_riesgo := reporte_digitada_proceso_pkg.fn_valida_ciudad_riesgosa(:new.cvaccd);
   IF (vc_nodo_riesgo = 'SI') THEN
      :new.ciudad_riesgosa := 'SI';
   ELSE
      :new.ciudad_riesgosa := 'NO';
   END IF;

   --Venta nueva o cruzada
   :new.venta_cruzada := 'SI';
   
   SELECT COUNT(*)
     INTO nm_existe
     FROM ventas_digitadas_fija_auto a
    WHERE TRIM(a.cvacct) = TRIM(:new.cvacct)
      AND a.venta_cruzada = 'NO';
   ---
   IF nm_existe > 0 THEN
      /*       UPDATE ventas_digitadas_fija_auto a
        SET a.venta_cruzada = 'SI'
      WHERE a.rowid = :NEW.rowid
        AND a.venta_cruzada IS NULL;*/
      :new.venta_cruzada := 'SI';
   ELSE
      --Buscar en Ventas Digitadas Fija en la tabla consolidada
      SELECT COUNT(*)
        INTO nm_existe_vf
        FROM ventas_digitadas_fija a
       WHERE TRIM(a.cvacct) = TRIM(:new.cvacct)
         AND a.cvayco || a.cvamco != :new.cvayco || :new.cvamco;
   
      IF nm_existe_vf > 0 THEN
         /*UPDATE ventas_digitadas_fija_auto a
           SET a.venta_cruzada = 'SI'
         WHERE a.rowid = i.rowid
           AND a.venta_cruzada IS NULL;*/
         :new.venta_cruzada := 'SI';
      ELSE
         /*UPDATE ventas_digitadas_fija_auto a
           SET a.venta_cruzada = 'NO'
         WHERE a.rowid = i.rowid
           AND a.venta_cruzada IS NULL;*/
         :new.venta_cruzada := 'NO';
      END IF;
   
   END IF;
   
   if (:NEW.CVATYS='T') THEN
      :new.venta_cruzada := 'TRASLADO';
   ELSIF (:NEW.CVATYS='C')THEN
     :new.venta_cruzada := 'SI';
   ELSE 
     :new.venta_cruzada := 'NO';
   END IF;
   
   commit;
   --   END IF;
EXCEPTION
   WHEN OTHERS THEN
      NULL;
END trg_ventas_digitadas_auto_af;
/

