create function COD_ALARMA_FNC(VC_NOMBRE IN VARCHAR2)
  return varchar2 is
  Result varchar2(100);
begin
  SELECT A.COD_ALARMA
    INTO Result
    FROM RFH_alarma_fraude A
   WHERE UPPER(A.DESC_ALARMA) = UPPER(VC_NOMBRE);
  return(Result);
exception
  when others then
    return null;
end COD_ALARMA_FNC;
/

