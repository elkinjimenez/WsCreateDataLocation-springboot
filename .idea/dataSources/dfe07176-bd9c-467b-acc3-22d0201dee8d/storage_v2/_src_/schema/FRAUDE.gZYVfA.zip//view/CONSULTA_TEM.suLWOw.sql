create view CONSULTA_TEM as
select a.numero_identificacion,max(to_date(substr(a.fecha_y_hora_de_consulta, 0, 10), 'dd,mm,yyyy')) fecha_cal_max
  from idvision a
 where to_date(substr(a.fecha_y_hora_de_consulta, 0, 10), 'dd,mm,yyyy') >
       trunc(sysdate - 58)
   and a.resultado_confrontacion not in ('APROBADO')
   and a.numero_identificacion not in
       (

        select p.numero_identificacion
          from idvision p
         where to_date(substr(a.fecha_y_hora_de_consulta, 0, 10),
                       'dd,mm,yyyy') > trunc(sysdate - 58)
           and p.numero_identificacion = a.numero_identificacion
           and p.resultado_confrontacion in ('APROBADO')

           )
   group by a.numero_identificacion
/

