create procedure CAMBIO_SIM_DATOS(VC_MIN          in VARCHAR2,
                                             VC_FECHA        in VARCHAR2,
                                             VC_COD_USUARIO  in VARCHAR2,
                                             VC_COD_DISTRI   in VARCHAR2,
                                             VC_USUARIO_EXCL OUT VARCHAR2,
                                             VC_USUARIO_RSA  OUT VARCHAR2,
                                             VC_USUARIO_TMK  OUT VARCHAR2,
                                             VC_EXISTE       OUT VARCHAR2,
                                             vc_error        out number) is
  nm_excluir number := 0;
  nm_rsa     number := 0;
  nm_tmk     number := 0;
  nm_tmk_sec number := 0;

begin

  VC_USUARIO_EXCL := 'NO';
  VC_USUARIO_RSA  := 'NO';
  VC_USUARIO_TMK  := 'NO';
  vc_error        := 0;

  SELECT COUNT(*)
    into nm_excluir
    FROM CTR_CAMSIM_USUARIOS_VAL A
   WHERE A.COD_USUARIO = VC_COD_USUARIO
     AND A.EXCLUIR = 'SI';

  IF nm_excluir > 0 THEN
    VC_USUARIO_EXCL := 'SI';
  END IF;

  SELECT COUNT(*)
    into nm_rsa
    FROM CTR_CAMSIM_USUARIOS_VAL A
   WHERE A.COD_USUARIO = VC_COD_USUARIO
     AND A.Tipo_Usuario = 'RSA';

  IF nm_rsa > 0 THEN
    VC_USUARIO_RSA := 'SI';
  END IF;

  --  
  SELECT COUNT(*)
    into nm_tmk
    FROM CTR_CAMSIM_USUARIOS_VAL A
   WHERE A.COD_USUARIO = VC_COD_USUARIO
     AND A.Tipo_Usuario = 'TMK';

  SELECT COUNT(*)
    into nm_tmk_sec
    FROM CTR_CAMSIM_USUARIOS_VAL A
   WHERE A.COD_DISTRI = VC_COD_DISTRI
     AND A.Tipo_Usuario = 'TMK';

/*  IF nm_tmk_sec = 0 THEN
    SELECT COUNT(*)
      INTO nm_tmk_sec
      FROM gpc_distribuidor L
     WHERE L.COD_DISTRIBUIDOR = VC_COD_DISTRI
       AND L.CANAL = 'TELEFONICO';
  END IF;
*/
  IF nm_tmk > 0 or nm_tmk_sec > 0 THEN
    VC_USUARIO_TMK := 'SI';
  END IF;
  --Valida si el registro ya existe 
  select count(*)
    INTO VC_EXISTE
    --from CTR_CAMSIM_SIN_BIOMETRIA_DES T --> POR DESARROLLO
    from CTR_CAMSIM_SIN_BIOMETRIA t
   where t.min = VC_MIN
     and t.fecha_registro = VC_FECHA;

exception
  when others then
    vc_error := sqlcode;
end CAMBIO_SIM_DATOS;
/

