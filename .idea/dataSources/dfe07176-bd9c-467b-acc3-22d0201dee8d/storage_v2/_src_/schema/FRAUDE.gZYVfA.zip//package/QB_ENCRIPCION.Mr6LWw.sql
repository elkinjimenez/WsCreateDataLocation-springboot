create PACKAGE QB_ENCRIPCION AS
--**********************************************************************************************************
--** OBJETIVO             : CONTIENE LAS UTILIDADES DE ENCRIPCION Y DESENCRIPCION
--** ESQUEMA              : UTIL
--** NOMBRE               : QB_ENCRIPCION / HEADER
--** AUTOR                : JAIRO ANDRES RIVERA RODRIGUEZ
--** FECHA MODIFICACION   : 24/AGOSTO/2011
--**********************************************************************************************************

   --------------------------------------------------------------------------
   -------------------- FUNCION QUE CODIFICA UN TEXTO------------------------
   --------------------------------------------------------------------------
   FUNCTION FB_ENCRIPTAR( TXT_ENCRIP VARCHAR2 ) RETURN RAW;

   --------------------------------------------------------------------------
   ------------------- FUNCION QUE DECODIFICA UN TEXTO-----------------------
   --------------------------------------------------------------------------

   FUNCTION FB_DESCENCRIPTAR( TXT_DESENCRIP VARCHAR2 ) RETURN VARCHAR2;

END QB_ENCRIPCION;
/

