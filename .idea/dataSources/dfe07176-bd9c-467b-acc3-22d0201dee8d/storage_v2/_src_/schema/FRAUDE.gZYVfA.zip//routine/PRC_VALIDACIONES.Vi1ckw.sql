create PROCEDURE PRC_VALIDACIONES( V_COD_ERROR OUT INT,
                                              V_COD_DESC  OUT VARCHAR2) is
BEGIN
EXECUTE IMMEDIATE ('TRUNCATE TABLE tmp_validacion');
--TRUNCATE TABLE tmp_validacion
INSERT INTO tmp_validacion
       (
            NRO_IDENTIFICACION,FECHA_DIGITACION
        )

         SELECT sv.nodcto,
                vf.fecha_dig
             FROM tbl_ventas_fija vf ,
                  tb_status_ventas sv
             WHERE vf.cvacct=sv.cuenta
             AND  sv.nodcto IS NOT NULL
             AND sv.estado IN ('A','N');
            COMMIT;
--************************************************************************
--CURSORES SEGUNDA EJECUCION
--REVISION BIOMETRIA : Cargar en la tabla TMP_VALIDACION la informacion ,
--                     con el procedimiento PRC_VALIDACIONES
--                     los campos NRO_IDENTIFICACION y FECHA_DIGITACION
--************************************************************************


--************************************************************************
--Cursor 1
--REVISION BIOMETRIA
--Debo ajustar el Between a -1 and 1
--************************************************************************

DECLARE
   CURSOR c IS
      SELECT t.nro_identificacion, t.fecha_digitacion, a.respuesta,
             MIN(to_date(substr(a.fecha, 0, 10), 'dd/mm/yyyy')) fecha_biometria
        FROM tmp_validacion t, reportes_biometria a
       WHERE t.nro_identificacion = a.documento
         AND upper(a.respuesta) = 'AUTORIZADO'
         AND to_date(substr(t.fecha_digitacion, 0, 10),'dd/mm/yyyy') -
             to_date(substr(a.fecha, 0, 10), 'dd/mm/yyyy') BETWEEN -8 AND 8
         AND t.herramienta IS NULL
       GROUP BY t.nro_identificacion, t.fecha_digitacion, a.respuesta;

BEGIN
   FOR i IN c
   LOOP
      UPDATE tmp_validacion x
         SET x.herramienta = 'BIOMETRIA',
             x.fecha_validacion = to_char(i.fecha_biometria,'dd/mm/yyyy')
       WHERE x.nro_identificacion = i.nro_identificacion
         AND x.fecha_digitacion = i.fecha_digitacion;
      COMMIT;
      DBMS_OUTPUT.put_line ('');

   END LOOP;
END;


--************************************************************************
--Cursor 2
--REVISION EVIDENTE FIJA
--************************************************************************
DECLARE
   CURSOR c IS
      SELECT t.nro_identificacion, t.fecha_digitacion, a.resultado,
             MIN(to_date(substr(a.fecha_y_hora, 0, 10),
                          'dd/mm/yyyy')) fecha_evidente
        FROM tmp_validacion t, evidente_claro_fija_view a
       WHERE t.nro_identificacion = a.no_id_cliente
         AND upper(a.resultado) IN
             ('APROBADO', 'AUTENTICACIÓN DE IDENTIDAD EXITOSA',
              'VALIDACION DE IDENTIDAD EXITOSA',
              'VALIDACIÓN DE IDENTIDAD APROBADA', 'CONFRONTACIÓN EXITOSA'
              )
         AND to_date(substr(t.fecha_digitacion, 0, 10),'dd/mm/yyyy') -
             to_date(substr(a.fecha_y_hora, 0, 10), 'dd/mm/yyyy') BETWEEN -8 AND 8
         AND t.herramienta IS NULL
       GROUP BY t.nro_identificacion, t.fecha_digitacion, a.resultado;
BEGIN
   FOR i IN c
   LOOP
      UPDATE tmp_validacion x
         SET x.herramienta = 'EVIDENTE',
             x.fecha_validacion = to_char(i.fecha_evidente,'dd/mm/yyyy')
       WHERE x.nro_identificacion = i.nro_identificacion
         AND x.fecha_digitacion = i.fecha_digitacion;
      COMMIT;
   END LOOP;
END;


--************************************************************************
--Cursor 3
--EVIDENTE CLARO MOVIL FIJA
--************************************************************************

DECLARE
   CURSOR c IS
      SELECT t.nro_identificacion, t.fecha_digitacion, a.resultado,
             MIN(to_date(substr(a.fecha_y_hora, 0, 10),'dd/mm/yyyy')) fecha_evidente
        FROM tmp_validacion t, evidente_claro_view a
       WHERE t.nro_identificacion = a.no_id_cliente
         AND upper(a.resultado) IN
             ('APROBADO', 'AUTENTICACIÓN DE IDENTIDAD EXITOSA',
              'VALIDACION DE IDENTIDAD EXITOSA',
              'VALIDACIÓN DE IDENTIDAD APROBADA', 'CONFRONTACIÓN EXITOSA'
              )
         AND to_date(substr(t.fecha_digitacion, 0, 10),'dd/mm/yyyy') -
             to_date(substr(a.fecha_y_hora, 0, 10), 'dd/mm/yyyy') BETWEEN -8 AND 8
         AND t.herramienta IS NULL
       GROUP BY t.nro_identificacion, t.fecha_digitacion, a.resultado;
BEGIN
   FOR i IN c
   LOOP
      UPDATE tmp_validacion x
         SET x.herramienta = 'EVIDENTE',
             x.fecha_validacion = to_char(i.fecha_evidente,'dd/mm/yyyy')
       WHERE x.nro_identificacion = i.nro_identificacion
         AND x.fecha_digitacion = i.fecha_digitacion;
    COMMIT;
   END LOOP;
END;


--************************************************************************
--Cursor 4
--REVISION OTP
--************************************************************************

DECLARE
   CURSOR c IS
      SELECT t.nro_identificacion, t.fecha_digitacion,
             a.resultado_confrontacion,
             MIN(to_date(substr(a.fecha_y_hora_de_consulta, 0, 10),'dd/mm/yyyy')) fecha_otp
        FROM tmp_validacion t, idvision a
       WHERE t.nro_identificacion = a.numero_identificacion
         AND a.resultado_opt = 'Identidad validada exitosamente. - Pass'
         AND to_date(substr(t.fecha_digitacion, 0, 10),'dd/mm/yyyy') -
             to_date(substr(a.fecha_y_hora_de_consulta, 0, 10),'dd/mm/yyyy') BETWEEN -8 AND 8
         AND t.herramienta IS NULL
       GROUP BY t.nro_identificacion, t.fecha_digitacion,
                a.resultado_confrontacion;
BEGIN
   FOR i IN c
   LOOP
      UPDATE tmp_validacion x
         SET x.herramienta = 'IDVISION_OTP',
             x.fecha_validacion = to_char(i.fecha_otp,'dd/mm/yyyy')
       WHERE x.nro_identificacion = i.nro_identificacion
         AND x.fecha_digitacion = i.fecha_digitacion;
      COMMIT;
   END LOOP;
END;

--************************************************************************
--Cursor 5
--IDVISION
--************************************************************************

DECLARE
   CURSOR c IS
      SELECT t.nro_identificacion, t.fecha_digitacion,
             a.resultado_confrontacion,
             MIN(to_date(substr(a.fecha_y_hora_de_consulta, 0, 10),'dd/mm/yyyy')) fecha_otp
        FROM tmp_validacion t, idvision a
       WHERE t.nro_identificacion = a.numero_identificacion
         AND upper(a.resultado_confrontacion) = 'APROBADO'
         AND to_date(substr(t.fecha_digitacion, 0, 10),'dd/mm/yyyy') -
             to_date(substr(a.fecha_y_hora_de_consulta, 0, 10),'dd/mm/yyyy') BETWEEN -8 AND 8
         AND t.herramienta IS NULL
       GROUP BY t.nro_identificacion, t.fecha_digitacion,
                a.resultado_confrontacion;

BEGIN
   FOR i IN c
   LOOP
      UPDATE tmp_validacion x
         SET x.herramienta = 'IDVISION',
             x.fecha_validacion = to_char(i.fecha_otp,'dd/mm/yyyy')
       WHERE x.nro_identificacion = i.nro_identificacion
         AND x.fecha_digitacion = i.fecha_digitacion;
      COMMIT;
   END LOOP;
END;


--************************************************************************
--UPDATE
--NINGUNO
--************************************************************************

UPDATE tmp_validacion x
   SET x.herramienta = 'NINGUNO'
 WHERE x.herramienta IS NULL;


COMMIT;


END PRC_VALIDACIONES;
/

