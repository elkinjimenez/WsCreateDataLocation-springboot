create PACKAGE BODY proceso_fraude_fija IS

   PROCEDURE cargar_tabla_ppal(p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2)
   
    IS
      nm_repetir NUMBER;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      INSERT INTO tbl_fraude_fija_j
         (cvacct, cvaoñ, cvatid, cvanid, telefono1, telefono2, telefono3,
          cvastr, direccion1, direccion2, direccion3, cvadco, cvamco, cvayco,
          canal, canal2, categoria, fecha_digitacion, paquete_pg, d_division,
          gv_area, gv_gerente_area, gv_jefe_zona, gv_especialista,
          gv_descripcion, nom_zona, cvanod, cvaccd, poblacion, cvadlr2,
          cvaase, d_distrito, cvacde)
         SELECT cvacct, cvaoñ, cvatid,
                --tipo_doc,
                cvanid,
                --documento,
                '',
                --telefono1,
                '',
                --telefono2,
                '',
                --telefono3,    
                '',
                --cvastr  --> se encuentra en ventas_digitadas auto, no en ventas digitadas
                cvatnm direccion1, cvahom direccion2,
                --
                cvaapt direccion3, cvadco, cvamco, cvayco, canal, canal2,
                categoria,
                lpad(cvadco, 2, '0') || '/' || lpad(cvamco, 2, 0) || '/20' ||
                 lpad(cvayco, 2, '0') fecha_digitacion,
                --fecha_digitacion,
                paquete_pg, d_division, gv_area, gv_gerente_area,
                gv_jefe_zona, gv_especialista, gv_descripcion, nom_zona,
                cvanod, cvaccd, poblacion, cvadlr2, cvaase, d_distrito,
                cvacde
           FROM ventas_digitadas_fija
          WHERE cvayco IN ('18', '19', '20')
            AND cvacct NOT IN (SELECT j.cvacct FROM tbl_fraude_fija_j j);
   
      COMMIT;
   
      --4. Ingresar las cuentas de ventas digitadas AUTO
      INSERT INTO tbl_fraude_fija_j
         (cvacct, cvaoñ, cvatid, cvanid, telefono1, telefono2, telefono3,
          cvastr, direccion1, direccion2, direccion3, cvadco, cvamco, cvayco,
          canal, canal2, categoria, fecha_digitacion, paquete_pg, d_division,
          gv_area, gv_gerente_area, gv_jefe_zona, gv_especialista,
          gv_descripcion, nom_zona, cvanod, cvaccd, poblacion, cvadlr2,
          cvaase, d_distrito, cvacde, biometria, evidente, idv_otp, idvision,
          validacion)
         SELECT b.cvacct, b.cvaoñ, b.cvatid, b.cvanid, b.cvapho, b.cvabph,
                '' telefono3, b.cvastr,
                ---DIRECCIONES
                '' direccion1, TRIM(b.cvahom) direccion2,
                b.cvaapt direccion3, b.cvadco, b.cvamco, b.cvayco,
                b.cvaca1 canal, b.cvaca2 canal2, b.cvacat categoria,
                lpad(b.cvadco, 2, '0') || '/' || lpad(b.cvamco, 2, '0') || '/' || '20' ||
                 b.cvayco, '' paquete_pg,
                
                b.cvadvg d_division, b.cvacrg gv_area,
                b.cvange gv_gerente_area, b.cvanje gv_jefe_zona,
                b.cvanes gv_especialista, b.cvagvd gv_descripcion,
                b.cvazng nom_zona, b.cvanod, b.cvaccd,
                (SELECT a.nombre_comunidad
                    FROM nodo_rr a
                   WHERE a.idnodo = b.cvanod
                     AND rownum = 1) poblacion, b.cvadlr, b.cvaase,
                b.cvdist d_distrito, b.cvacde, b.biometria, b.evidente,
                b.otp, b.idvision, b.herramienta_aprobacion
           FROM ventas_digitadas_fija_auto b
          WHERE b.venta_cruzada = 'NO'
            AND b.cvacct NOT IN (SELECT a.cvacct FROM tbl_fraude_fija_j a);
   
      COMMIT;
   
      --Quita cuentas duplicadas
      SELECT nvl(MAX(COUNT(*)), 0)
        INTO nm_repetir
        FROM tbl_fraude_fija_j a
      HAVING COUNT(*) > 1
       GROUP BY a.cvacct, a.cvaoñ, a.cvadco, a.cvamco, a.cvayco;
   
      FOR i IN 1 .. nm_repetir
      LOOP
         DELETE tbl_fraude_fija_j j
          WHERE j.rowid IN
                (SELECT MIN(k.rowid) --k.cvacct --, COUNT(*)
                   FROM tbl_fraude_fija_j k
                 HAVING COUNT(*) > 1
                  GROUP BY k.cvacct, k.cvaoñ, k.cvadco, k.cvamco, k.cvayco);
      
         COMMIT;
      END LOOP;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END cargar_tabla_ppal;

   PROCEDURE borrar_tmp_fraude(p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2)
   
    IS
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      DELETE tmp_cuenta_hogares; ---Tabla que fue creada por hugo
      COMMIT;
      --NO SE BORRA, ACUMULA
      /*DELETE tel_contacto;
      COMMIT;*/
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END borrar_tmp_fraude;

   PROCEDURE borrar_estado_cuentas(p_nm_error OUT NUMBER,
                                   p_vc_error OUT VARCHAR2)
   
    IS
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      --ESTADO CUENTAS DIFERENTES A ACTIVAS 
      INSERT INTO estado_cuentas_hist
         SELECT *
           FROM estado_cuentas
                
                 COMMIT;
   
      DELETE estado_cuentas;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END borrar_estado_cuentas;

   PROCEDURE borrar_nunca_pago(p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2)
   
    IS
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      --NUNCA PAGO
      INSERT INTO nunca_pago_hist
         SELECT * FROM nunca_pago;
   
      COMMIT;
   
      DELETE nunca_pago;
      COMMIT;
   
      --NO SE BORRA, ACUMULA
      /*DELETE tel_contacto;
      COMMIT;*/
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END borrar_nunca_pago;

   PROCEDURE insertar_fraude(p_vc_cta             IN VARCHAR2,
                             p_vc_tipo_fraude     IN VARCHAR2,
                             p_vc_fecha_deteccion IN VARCHAR2,
                             p_nm_error           OUT NUMBER,
                             p_vc_error           OUT VARCHAR2)
   
    IS
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      INSERT INTO tmp_cuenta_hogares
         (cuenta, titulo_nota, fecha_deteccion)
      VALUES
         (TRIM(p_vc_cta), TRIM(p_vc_tipo_fraude),
          TRIM(p_vc_fecha_deteccion));
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END insertar_fraude;

   PROCEDURE procesar_tmp(p_nm_error OUT NUMBER,
                          p_vc_error OUT VARCHAR2)
   
    IS
      nm_repetir NUMBER;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      --Calcula un campo fecha, en formato DD/MM/YYYY
      UPDATE tmp_cuenta_hogares a
         SET a.fecha_respuesta = substr(a.fecha_deteccion, 7, 2) || '/' ||
                                  substr(a.fecha_deteccion, 5, 2) || '/' ||
                                  substr(a.fecha_deteccion, 0, 4);
      COMMIT;
   
      --SE VALIDA CUANTAS VECES SE DEBE EJECUTAR UN DELETE DE DUPLICADOS
      SELECT nvl(MAX(COUNT(*)), 0)
        INTO nm_repetir
        FROM tmp_cuenta_hogares a
       WHERE a.cuenta NOT IN (SELECT x.cuenta FROM fraudes_hogares x)
       HAVING COUNT(*) > 1
       GROUP BY a.cuenta;
   
      FOR i IN 1 .. nm_repetir
      LOOP
         DELETE tmp_cuenta_hogares y
          WHERE y.cuenta IN (SELECT a.cuenta --, count(*)
                               FROM tmp_cuenta_hogares a
                              WHERE a.cuenta NOT IN
                                    (SELECT x.cuenta FROM fraudes_hogares x)
                              HAVING COUNT(*) > 1
                              GROUP BY a.cuenta)
            AND to_date(y.fecha_respuesta, 'dd/mm/yyyy') IN
                (SELECT MAX(to_date(a.fecha_respuesta, 'dd/mm/yyyy')) --, count(*)
                   FROM tmp_cuenta_hogares a
                  WHERE a.cuenta = y.cuenta
                  GROUP BY a.cuenta);
         COMMIT;
      END LOOP;
   
      --Insertar en la tabla de CJ Fraudes_hogares
      INSERT INTO fraudes_hogares f
         (SELECT t.cuenta, t.titulo_nota, t.fecha_deteccion
            FROM tmp_cuenta_hogares t
           WHERE t.cuenta NOT IN (SELECT x.cuenta FROM fraudes_hogares x));
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END procesar_tmp;

   --carga cuentas en estados diferentes de A
   PROCEDURE insertar_estado_cuenta(p_vc_cta                 IN VARCHAR2,
                                    p_vc_estado_cuenta       IN VARCHAR2,
                                    p_vc_fecha_digitacion    IN VARCHAR2,
                                    p_vc_fecha_desactivacion IN VARCHAR2,
                                    p_vc_razon_dx            IN VARCHAR2,
                                    p_vc_descripcion_dx      IN VARCHAR2,
                                    p_vc_tel_casa            IN VARCHAR2,
                                    p_vc_tel_oficina         IN VARCHAR2,
                                    p_vc_tercer_tel          IN VARCHAR2,
                                    p_nm_error               OUT NUMBER,
                                    p_vc_error               OUT VARCHAR2)
   
    IS
   
      nm_cuenta NUMBER := 0;
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      INSERT INTO estado_cuentas
         (cuenta, sustat, fecha_digitacion, fecha_dx, razon_dx,
          descripcion_dx, tel_casa, tel_oficina, tercer_tel, fecha_cargue)
      VALUES
         (TRIM(p_vc_cta), TRIM(p_vc_estado_cuenta),
          TRIM(p_vc_fecha_digitacion), TRIM(p_vc_fecha_desactivacion),
          TRIM(p_vc_razon_dx), TRIM(p_vc_descripcion_dx),
          TRIM(p_vc_tel_casa), TRIM(p_vc_tel_oficina), TRIM(p_vc_tercer_tel),
          SYSDATE);
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END insertar_estado_cuenta;

   PROCEDURE insertar_cuentanp(p_vc_cta   IN VARCHAR2,
                               p_nm_error OUT NUMBER,
                               p_vc_error OUT VARCHAR2)
   
    IS
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      INSERT INTO nunca_pago
         (cuenta, fecha_cargue)
      VALUES
         (TRIM(p_vc_cta), SYSDATE);
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END insertar_cuentanp;

   PROCEDURE insertar_tel_contacto(p_nm_error OUT NUMBER,
                                   p_vc_error OUT VARCHAR2)
   
    IS
      nm_contador NUMBER := 0;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      INSERT INTO tel_contacto
         SELECT l.cuenta, l.fecha_digitacion, l.tel_casa, l.tel_oficina,
                l.tercer_tel
           FROM estado_cuentas l
          WHERE l.cuenta NOT IN (SELECT p.cuenta FROM tel_contacto p);
   
      COMMIT;
   
      ---TABLA DE CUENTAS DISTINTAS A A (fecha de desconexion)
      BEGIN
         UPDATE tbl_fraude_fija_j a
            SET a.razon_dx = NULL, a.fecha_dx = NULL, a.causal_dx = NULL,
                a.estado_actual = NULL;
      
         MERGE INTO tbl_fraude_fija_j a
         USING estado_cuentas b
         ON (TRIM(a.cvacct) = TRIM(b.cuenta))
         WHEN MATCHED THEN
            UPDATE
               SET a.razon_dx = b.razon_dx, a.fecha_dx = b.fecha_dx,
                   a.telefono1 = b.tel_casa, a.telefono2 = b.tel_oficina,
                   a.telefono3 = b.tercer_tel,
                   a.causal_dx = b.descripcion_dx;
         COMMIT;
      
         UPDATE tbl_fraude_fija_j a
            SET a.estado_actual = 'DX_CARTERA'
          WHERE a.razon_dx = '02';
      
         COMMIT;
      
         UPDATE tbl_fraude_fija_j a
            SET a.estado_actual = 'DX_FRAUDE'
          WHERE a.razon_dx = 'DR';
      
         COMMIT;
      
         UPDATE tbl_fraude_fija_j a
            SET a.estado_actual = 'ACTIVA'
          WHERE a.razon_dx IS NULL;
      
         COMMIT;
      
         UPDATE tbl_fraude_fija_j a
            SET a.estado_actual = 'DX_VOLUNTARIA'
          WHERE a.estado_actual IS NULL;
         COMMIT;
      EXCEPTION
         WHEN OTHERS THEN
            p_vc_error := 'Error al calcular campo estado_actual' ||
                          SQLERRM;
      END;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Erroe al copiar telefonos de contacto ' || SQLERRM;
   END insertar_tel_contacto;

   PROCEDURE insertar_tel_contacto(p_vc_cta         IN VARCHAR2,
                                   p_vc_tel_casa    IN VARCHAR2,
                                   p_vc_tel_oficina IN VARCHAR2,
                                   p_vc_tercer_tel  IN VARCHAR2,
                                   p_nm_error       OUT NUMBER,
                                   p_vc_error       OUT VARCHAR2)
   
    IS
      nm_contador NUMBER := 0;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      SELECT COUNT(*)
        INTO nm_contador
        FROM tel_contacto a
       WHERE a.cuenta = p_vc_cta;
   
      IF nm_contador = 0 THEN
         INSERT INTO tel_contacto
            (cuenta, tel_casa, tel_oficin, tercer_tel)
         VALUES
            (TRIM(p_vc_cta), TRIM(p_vc_tel_casa), TRIM(p_vc_tel_oficina),
             TRIM(p_vc_tercer_tel));
      ELSE
         p_vc_error := 'Contacto ya existe en tabla ' || p_vc_cta;
      END IF;
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END insertar_tel_contacto;

   PROCEDURE actualiza_ppal(p_nm_error OUT NUMBER,
                            p_vc_error OUT VARCHAR2) IS
   
      varsql VARCHAR2(500) := '';
   BEGIN
   
      p_nm_error := 0;
      p_vc_error := 0;
   
      /*--CREAR UNA FOTO DE LO ANTERIOR
         varsql:='tbl_fraude_fija_j TABLE TBL_FRAUDE_'|| to_char(SYSDATE, 'DD_MM_YYYY')||' AS
            SELECT * FROM tbl_fraude_fija_j ';
            
          EXECUTE IMMEDIATE varsql;
      */
      BEGIN
         --1 TABLA DE FRAUDE --> cuentas fraude
         MERGE INTO tbl_fraude_fija_j i
         USING fraudes_hogares f
         ON (TRIM(i.cvacct) = TRIM(f.cuenta))
         WHEN MATCHED THEN
            UPDATE
               SET i.tipo_fraude = f.tipo_fraud,
                   i.fecha_deteccion = f.fecha_deteccion,
                   i.fecha_proceso = to_char(SYSDATE, 'dd/mm/yyyy');
      
         COMMIT;
      
         UPDATE tbl_fraude_fija_j i
            SET i.tipo_fraude = 'NEGACION'
          WHERE TRIM(i.tipo_fraude) = 'NC';
      
         COMMIT;
      
         UPDATE tbl_fraude_fija_j i --> quiere la palabra ALARMAS
            SET i.tipo_fraude = 'ALARMAS'
          WHERE TRIM(i.tipo_fraude) IN ('FR', '10', 'PCF');
      
         COMMIT;
      
         UPDATE tbl_fraude_fija_j i --> quiere la palabra ALARMAS
            SET i.tipo_fraude = 'NINGUNO'
          WHERE i.tipo_fraude IS NULL;
      
         COMMIT;
      EXCEPTION
         WHEN OTHERS THEN
            p_vc_error := 'Error al calcular campo tipo_fraude' || SQLERRM;
      END;
   
      --2. Cuentas nunca pago    
      BEGIN
         UPDATE tbl_fraude_fija_j a SET a.nunca_pago = NULL;
      
         COMMIT;
      
         MERGE INTO tbl_fraude_fija_j a
         USING nunca_pago n
         ON (a.cvacct = n.cuenta)
         WHEN MATCHED THEN
            UPDATE SET a.nunca_pago = 'SI';
      
         COMMIT;
      
         UPDATE tbl_fraude_fija_j a
            SET a.nunca_pago = 'NO'
          WHERE a.nunca_pago IS NULL;
      
         COMMIT;
      EXCEPTION
         WHEN OTHERS THEN
            p_vc_error := 'Error al calcular campo nunca_pago' || SQLERRM;
      END;
      --3 Contactos
      BEGIN
         MERGE INTO tbl_fraude_fija_j a
         USING tel_contacto t
         ON (a.cvacct = t.cuenta) ---ojo por si hay duplicados
         WHEN MATCHED THEN
            UPDATE
               SET a.telefono1 = t.tel_casa, a.telefono2 = t.tel_oficin,
                   a.telefono3 = t.tercer_tel;
         COMMIT;
      EXCEPTION
         WHEN OTHERS THEN
            p_vc_error := 'Error al calcular campos telefonos' || SQLERRM;
      END;
   
      --4 Carrusell
      BEGIN
         UPDATE tbl_fraude_fija_j a
            SET a.carrusel = 'SI'
          WHERE a.cvacct IN (SELECT h.cuenta_nueva FROM carrusel h);
         COMMIT;
      
         UPDATE tbl_fraude_fija_j a
            SET a.carrusel = 'NO'
          WHERE a.cvacct NOT IN (SELECT h.cuenta_nueva FROM carrusel h);
         COMMIT;
      
      EXCEPTION
         WHEN OTHERS THEN
            p_vc_error := 'Error al calcular campos telefonos' || SQLERRM;
      END;
   
      --29/06/2020  MODIFICACION DE INCLUSION DE TEMAS
      proceso_fraude_fija.actualiza_mas_dos_cta(p_nm_error => p_nm_error,
                                                p_vc_error => p_vc_error);
   
      proceso_fraude_fija.actualiza_tel_malla_fr(p_nm_error => p_nm_error,
                                                 p_vc_error => p_vc_error);
   
      --fin 29/06/2020  MODIFICACION DE INCLUSION DE TEMAS
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END actualiza_ppal;

   PROCEDURE actualiza_ppal2(p_nm_error OUT NUMBER,
                             p_vc_error OUT VARCHAR2) IS
   
      varsql VARCHAR2(500) := '';
   BEGIN
   
      p_nm_error := 0;
      p_vc_error := 0;
   
      proceso_fraude_fija.actualiza_asesores_fr(p_nm_cant_fr => '50',
                                                --query de hugo lo traia
                                                p_nm_error => p_nm_error,
                                                p_vc_error => p_vc_error);
   
      proceso_fraude_fija.actualiza_nodos_fr(p_nm_cant_fr => '50',
                                             --query de hugo lo traia
                                             p_nm_error => p_nm_error,
                                             p_vc_error => p_vc_error);
   
      proceso_fraude_fija.actualiza_poblacion_fraude(p_nm_cant_fr => '50',
                                                     p_nm_error => p_nm_error,
                                                     p_vc_error => p_vc_error);
   
      proceso_fraude_fija.coincidencia_movil(p_nm_error => p_nm_error,
                                             p_vc_error => p_vc_error);
   
      proceso_fraude_fija.actualiza_neg_movil(p_nm_error => p_nm_error,
                                              p_vc_error => p_vc_error);
   
      proceso_fraude_fija.actualiza_buro_direccion(p_nm_error => p_nm_error,
                                                   p_vc_error => p_vc_error);
   
      proceso_fraude_fija.actualiza_buro_telefono(p_nm_error => p_nm_error,
                                                  p_vc_error => p_vc_error);
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END actualiza_ppal2;

   PROCEDURE actualiza_tel_malla_fr(p_nm_error OUT NUMBER,
                                    p_vc_error OUT VARCHAR2) IS
   
   BEGIN
   
      p_nm_error := 0;
      p_vc_error := 0;
   
      UPDATE tbl_fraude_fija_j a
         SET a.contactofr = 'SI'
       WHERE substr(TRIM(a.telefono1), 2, 15) IN
             (SELECT TRIM(m.telefono) FROM tel_mallas m);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.contactofr = 'SI'
       WHERE TRIM(a.telefono1) IN
             (SELECT TRIM(m.telefono) FROM tel_mallas m);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.contactofr = 'SI'
       WHERE substr(TRIM(a.telefono2), 2, 15) IN
             (SELECT TRIM(m.telefono) FROM tel_mallas m);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.contactofr = 'SI'
       WHERE TRIM(a.telefono3) IN
             (SELECT TRIM(m.telefono) FROM tel_mallas m);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.contactofr = 'SI'
       WHERE substr(TRIM(a.telefono3), 2, 15) IN
             (SELECT TRIM(m.telefono) FROM tel_mallas m);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.contactofr = 'SI'
       WHERE TRIM(a.telefono1) IN
             (SELECT TRIM(m.telefono) FROM tel_mallas m);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.contactofr = 'NO'
       WHERE a.contactofr IS NULL;
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error al actualizar campo contactofr ' || SQLERRM;
   END actualiza_tel_malla_fr;

   PROCEDURE actualiza_asesores_fr(p_nm_cant_fr NUMBER,
                                   p_nm_error   OUT NUMBER,
                                   p_vc_error   OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      DELETE asesores_fraude_hogar;
   
      COMMIT;
   
      INSERT INTO asesores_fraude_hogar
         (SELECT p.asesor, fraude, ventas,
                 round((fraude / ventas) * 100) porc_fraude
            FROM (SELECT t.cvadlr2 asesor, COUNT(1) fraude
                     FROM tbl_fraude_fija_j t
                    WHERE tipo_fraude NOT IN ('NINGUNO')
                      AND t.cvayco IN ('18', '19', '20')
                    GROUP BY t.cvadlr2) q,
                 (SELECT v.cvadlr2 asesor, COUNT(1) ventas
                     FROM tbl_fraude_fija_j v
                    WHERE v.cvayco IN ('18', '19', '20')
                    GROUP BY v.cvadlr2) p
           WHERE p.asesor = q.asesor(+)
             AND (fraude / ventas) * 100 >= 10
             AND ventas >= p_nm_cant_fr);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j i
         SET i.cvaasefr = 'SI'
       WHERE i.cvadlr2 IN (SELECT a.asesor FROM asesores_fraude_hogar a);
      COMMIT;
   
      --Actualizo si el asesor es fraudulento - consulta mejor performance
      /* MERGE INTO tbl_fraude_fija_j a
      USING asesores_fraude_hogar b
      ON (b.asesor = a.cvadlr2)
      WHEN MATCHED THEN
         UPDATE SET a.cvaasefr = 'SI';
      COMMIT;*/
   
      UPDATE tbl_fraude_fija_j a
         SET a.cvaasefr = 'NO'
       WHERE a.cvaasefr IS NULL;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error al actualizad campo asesor fraude' || SQLERRM;
   END actualiza_asesores_fr;

   PROCEDURE actualiza_nodos_fr(p_nm_cant_fr NUMBER,
                                p_nm_error   OUT NUMBER,
                                p_vc_error   OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      DELETE nodos_fraude;
   
      COMMIT;
   
      INSERT INTO nodos_fraude --> actualiza
         (SELECT p.nodo, fraude, ventas,
                 round((fraude / ventas) * 100) porc_fraude
            FROM (SELECT t.cvanod nodo, COUNT(1) fraude
                     FROM tbl_fraude_fija_j t
                    WHERE tipo_fraude NOT IN ('NINGUNO')
                      AND t.cvayco IN ('18', '19', '20')
                    GROUP BY t.cvanod) q,
                 (SELECT v.cvanod nodo, COUNT(1) ventas
                     FROM tbl_fraude_fija_j v
                    WHERE v.cvayco IN ('18', '19', '20')
                    GROUP BY v.cvanod) p
           WHERE p.nodo = q.nodo(+)
             AND (fraude / ventas) * 100 >= 6
             AND ventas >= p_nm_cant_fr);
   
      COMMIT;
   
      /*MERGE INTO tbl_fraude_fija_j a
      USING nodos_fraude b
      ON (a.cvanod = b.nodo)
      WHEN MATCHED THEN
         UPDATE SET a.cvanodfr = 'SI';*/
      UPDATE tbl_fraude_fija_j s
         SET s.cvanodfr = 'SI'
       WHERE s.cvanod IN (SELECT h.nodo FROM nodos_fraude h);
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.cvanodfr = 'NO'
       WHERE a.cvanodfr IS NULL;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error a actualziar campo cvanodfr ' || SQLERRM;
   END actualiza_nodos_fr;

   PROCEDURE actualiza_poblacion_fraude(p_nm_cant_fr NUMBER,
                                        p_nm_error   OUT NUMBER,
                                        p_vc_error   OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      DELETE poblacion_fraude;
      COMMIT;
   
      INSERT INTO poblacion_fraude
         (SELECT p.poblacion, fraude, ventas,
                 round((fraude / ventas) * 100) porc_fraude
            FROM (SELECT t.poblacion poblacion, COUNT(1) fraude
                     FROM tbl_fraude_fija_j t
                    WHERE tipo_fraude NOT IN ('NINGUNO')
                      AND t.cvayco IN ('18', '19','20')
                    GROUP BY t.poblacion) q,
                 (SELECT v.poblacion poblacion, COUNT(1) ventas
                     FROM tbl_fraude_fija_j v
                    WHERE v.cvayco IN ('18', '19','20')
                    GROUP BY v.poblacion) p
           WHERE p.poblacion = q.poblacion(+)
             AND (fraude / ventas) * 100 >= 2
             AND ventas >= p_nm_cant_fr);
   
      COMMIT;
   
      --Actualizo si la población es fraudulenta
      UPDATE tbl_fraude_fija_j a
         SET a.poblacifr = 'SI'
       WHERE a.poblacion IN (SELECT p.poblacion FROM poblacion_fraude p);
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.poblacifr = 'NO'
       WHERE a.poblacifr IS NULL;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error al actualizar campo de poblacion fraude ' ||
                       SQLERRM;
   END actualiza_poblacion_fraude;

   PROCEDURE actualiza_wtth(p_nm_error OUT NUMBER,
                            p_vc_error OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      UPDATE tbl_fraude_fija_j y
         SET y.wtth = 'SI'
       WHERE y.cvacct IN
             (SELECT j.cvacct
                FROM ventas_digitadas_fija_auto j
               WHERE 1 = 1
                 AND j.venta_cruzada = 'NO'
                 AND j.cvaarg IN (SELECT a.tcargu
                                    FROM servicios_prametrizacion a
                                   WHERE a.tipo = '@DTH'))
         AND y.wtth IS NULL;
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y SET y.wtth = 'NO' WHERE y.wtth IS NULL;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END actualiza_wtth;

   PROCEDURE actualiza_tplay(p_nm_error OUT NUMBER,
                             p_vc_error OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      UPDATE tbl_fraude_fija_j y
         SET y.trplay_pgfr = 'SI'
       WHERE y.cvacct IN (
                          
                          SELECT j.cvacct
                            FROM ventas_digitadas_fija_auto j
                           WHERE 1 = 1
                             AND j.venta_cruzada = 'NO'
                             AND j.paquete_pg LIKE '%TV+@+VOZ%');
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.trplay_pgfr = 'NO'
       WHERE y.trplay_pgfr IS NULL;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END actualiza_tplay;

   PROCEDURE actualiza_hh_pp(p_nm_error OUT NUMBER,
                             p_vc_error OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      MERGE INTO tbl_fraude_fija_j a
      USING hhpp_fraude h
      ON (TRIM(a.direccion1) || TRIM(a.direccion2) || TRIM(a.direccion3) || TRIM(a.cvaccd) || TRIM(a.cvacde) = TRIM(h.ststnm) || TRIM(h.unhome) || TRIM(h.unaptñ) || TRIM(h.unccde) || TRIM(h.undcde))
      WHEN MATCHED THEN
         UPDATE SET a.hhppfr = 'SI';
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.hhppfr = 'NO'
       WHERE y.hhppfr IS NULL;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END actualiza_hh_pp;

   PROCEDURE actualiza_neg_movil(p_nm_error OUT NUMBER,
                                 p_vc_error OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      UPDATE tbl_fraude_fija_j a
         SET a.negenmov = 'SI'
       WHERE TRIM(a.cvanid) IN
             (SELECT DISTINCT TRIM(h.nro_documento) FROM negaciones_movil h);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.negenmov = 'SI'
       WHERE TRIM(a.cvanid) IN
             (SELECT DISTINCT TRIM(h.numero_doc_cliente)
                FROM radic_movil_data h);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.negenmov = 'NO'
       WHERE a.negenmov IS NULL;
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error al actualizar Negacion Movil ' || SQLERRM;
   END actualiza_neg_movil;

   PROCEDURE coincidencia_movil(p_nm_error OUT NUMBER,
                                p_vc_error OUT VARCHAR2) IS
   
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      UPDATE tbl_fraude_fija_j h
         SET h.coinciden_tel_claro = 'SI'
       WHERE h.cvacct IN (SELECT a.cvacct
                            FROM ventas_movil v, tbl_fraude_fija_j a
                           WHERE v.min = a.telefono1
                             AND a.cvanid = v.numero_doc);
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j h
         SET h.coinciden_tel_claro = 'SI'
       WHERE h.cvacct IN (SELECT a.cvacct
                            FROM ventas_movil v, tbl_fraude_fija_j a
                           WHERE v.min = a.telefono2
                             AND a.cvanid = v.numero_doc);
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j h
         SET h.coinciden_tel_claro = 'SI'
       WHERE h.cvacct IN (SELECT a.cvacct
                            FROM ventas_movil v, tbl_fraude_fija_j a
                           WHERE v.min = a.telefono3
                             AND a.cvanid = v.numero_doc);
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.coinciden_tel_claro = 'NO'
       WHERE a.coinciden_tel_claro IS NULL;
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.coincid_dir_claro = 'SI'
       WHERE a.cvacct IN
             (SELECT DISTINCT cvacct
                FROM tbl_fraude_fija_j a, ventas_movil v
               WHERE a.cvanid = v.numero_doc
                 AND utl_match.edit_distance_similarity(REPLACE(TRIM(a.direccion1) ||
                                                                TRIM(a.direccion2) ||
                                                                TRIM(a.direccion3),
                                                                ' ', ''),
                                                        REPLACE(v.direccion,
                                                                 ' ', '')) > '50'
              
              );
   
      UPDATE tbl_fraude_fija_j a
         SET a.coincid_dir_claro = 'NO'
       WHERE a.coincid_dir_claro IS NULL;
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error actualizando coincidencia de telefono/ dir  de ac ' ||
                       SQLERRM;
   END coincidencia_movil;

   PROCEDURE insertar_mas_dos_cta(p_vc_tipo     IN VARCHAR2,
                                  p_vc_doc      IN VARCHAR2,
                                  p_nm_cantidad IN NUMBER,
                                  p_nm_error    OUT NUMBER,
                                  p_vc_error    OUT VARCHAR2) IS
   
      nm_cantidad NUMBER := 0;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      SELECT COUNT('1')
        INTO nm_cantidad
        FROM mas_dos_cuentas r
       WHERE r.cvanid = p_vc_doc
         AND r.cvatid = p_vc_tipo;
   
      IF nm_cantidad = 0 THEN
         INSERT INTO mas_dos_cuentas
            (cvatid, cvanid, cantidad, fecha)
         VALUES
            (p_vc_tipo, p_vc_doc, p_nm_cantidad,
             to_char(SYSDATE, 'dd/mm/yyyy'));
      
         COMMIT;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := SQLERRM;
   END insertar_mas_dos_cta;

   PROCEDURE actualiza_mas_dos_cta(p_nm_error OUT NUMBER,
                                   p_vc_error OUT VARCHAR2) IS
   
      nm_cantidad NUMBER := 0;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      UPDATE mas_dos_cuentas y
         SET y.cvanid = TRIM(y.cvanid), y.cvatid = TRIM(y.cvatid);
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j a
         SET a.my2ctas = 'SI'
       WHERE a.cvanid IN (SELECT m.cvanid FROM mas_dos_cuentas m);
      COMMIT;
   
      UPDATE tbl_fraude_fija_j f
         SET f.my2ctas = 'NO'
       WHERE f.my2ctas IS NULL;
   
      COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error al actualizar campo mas de dos cuentas ' ||
                       SQLERRM;
   END actualiza_mas_dos_cta;

   PROCEDURE consulta_buscar_buro(p_vc_dias       VARCHAR2,
                                  p_cur_resultado OUT SYS_REFCURSOR,
                                  p_nm_resp       OUT NUMBER,
                                  p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      --Busca los documentos de ventas de buro, y valida cuantas veces se ha solicitado ese documeto
      OPEN p_cur_resultado FOR
         SELECT *
           FROM (SELECT consulta.*,
                         nvl(p.veces_buscado, 0) cantidad_veces_buscado
                    FROM (SELECT DISTINCT h.cvatid tipo_doc, h.cvanid
                             FROM tbl_fraude_fija_j h
                            WHERE TRIM(h.cvanid) NOT IN
                                  (SELECT TRIM(y.numero_identificacion)
                                     FROM datos_ubicacion y)
                              AND h.cvatid IS NOT NULL
                              --21/07/2020 Indicado por Eduard en reunion de entrega
                              AND h.validacion not in ('BIOMETRIA','OTP OK','OTP INTERNO')
                             --AND h.validacion in ('NINGUNO')
                              AND to_date(h.fecha_digitacion, 'dd/mm/yyyy') >=
                                  SYSDATE - p_vc_dias                      
                           
                           ) consulta
                    LEFT JOIN datos_ubica_pedidos p
                      ON consulta.cvanid = p.numero_identificacion)
          WHERE cantidad_veces_buscado <= 2
         
         ;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := SQLCODE;
         p_vc_resp       := SQLERRM;
         p_cur_resultado := NULL;
   END consulta_buscar_buro;

   PROCEDURE insertar_consultados_buro(p_vc_tipo   datos_ubica_pedidos.tipo_identificacion%TYPE,
                                       p_vc_numero IN datos_ubica_pedidos.numero_identificacion%TYPE,
                                       p_nm_resp   OUT NUMBER,
                                       p_vc_resp   OUT VARCHAR2) IS
      nm_contador NUMBER := 0;
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      SELECT COUNT(*)
        INTO nm_contador
        FROM datos_ubica_pedidos x
       WHERE x.tipo_identificacion = p_vc_tipo
         AND x.numero_identificacion = p_vc_numero;
   
      IF nm_contador = 0 THEN
         --Busca los documentos de ventas de buro, y valida cuantas veces se ha solicitado ese documeto
         INSERT INTO datos_ubica_pedidos p
            (tipo_identificacion, numero_identificacion, fecha_buscado,
             veces_buscado)
         VALUES
            (p_vc_tipo, p_vc_numero, to_char(SYSDATE, 'dd/mm/yyyy'), 1);
      ELSE
         UPDATE datos_ubica_pedidos a
            SET a.veces_buscado = a.veces_buscado + 1
          WHERE a.tipo_identificacion = p_vc_tipo
            AND a.numero_identificacion = p_vc_numero;
      END IF;
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp := SQLCODE;
         p_vc_resp := SQLERRM;
   END insertar_consultados_buro;

   PROCEDURE actualiza_buro_direccion(p_nm_error OUT NUMBER,
                                      p_vc_error OUT VARCHAR2) IS
   
      nm_cantidad NUMBER := 0;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      --1. Direccion
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct /*, a.categoria, a.cvatid, a.cvanid, a.direccion1, a.direccion2,
                                                                                                                                                                         a.direccion3, a.telefono1, a.telefono2, a.telefono3, b.direccion_1,
                                                                                                                                                                         REPLACE(a.direccion1, ' ', '') || REPLACE(a.direccion2, ' ', '') ||
                                                                                                                                                                          REPLACE(a.direccion3, ' ', ''), REPLACE(b.direccion_1, ' ', ''),
                                                                                                                                                                         utl_match.edit_distance_similarity(REPLACE(a.direccion1, ' ', '') ||
                                                                                                                                                                                                             REPLACE(a.direccion2, ' ', '') ||
                                                                                                                                                                                                             REPLACE(a.direccion3, ' ', ''),
                                                                                                                                                                                                             REPLACE(regexp_replace(regexp_replace(b.direccion_1,
                                                                                                                                                                                                                                     'KR', 'CR'),'#',''),
                                                                                                                                                                                                                      ' ', ''))*/
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_1,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_1, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_2,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_2, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_3,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_3, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_4,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_4, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_5,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_5, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_6,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_6, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_7,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_7, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_8,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_8, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_9,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_9, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND utl_match.edit_distance_similarity(REPLACE(a.direccion1 ||
                                                                a.direccion2 ||
                                                                a.direccion3,
                                                                ' ', ''),
                                                        REPLACE(REPLACE(b.direccion_10,
                                                                         'KR',
                                                                         'CR'),
                                                                 '#', '')) > 40
              --and to_date(b.fecha_de_primer_reporte_10, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_dir_buro = 'NO'
       WHERE y.coincid_dir_buro IS NULL;
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error al actualizar campos de buro s ' || SQLERRM;
   END actualiza_buro_direccion;

   PROCEDURE actualiza_buro_telefono(p_nm_error OUT NUMBER,
                                     p_vc_error OUT VARCHAR2) IS
   
      nm_cantidad NUMBER := 0;
   BEGIN
      p_nm_error := 0;
      p_vc_error := 0;
   
      --1. Direccion
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct /*, a.categoria, a.cvatid, a.cvanid, a.direccion1, a.direccion2,
                                                                                                                                                                         a.direccion3, a.telefono1, a.telefono2, a.telefono3, b.direccion_1,
                                                                                                                                                                         REPLACE(a.direccion1, ' ', '') || REPLACE(a.direccion2, ' ', '') ||
                                                                                                                                                                          REPLACE(a.direccion3, ' ', ''), REPLACE(b.direccion_1, ' ', ''),
                                                                                                                                                                         utl_match.edit_distance_similarity(REPLACE(a.direccion1, ' ', '') ||
                                                                                                                                                                                                             REPLACE(a.direccion2, ' ', '') ||
                                                                                                                                                                                                             REPLACE(a.direccion3, ' ', ''),
                                                                                                                                                                                                             REPLACE(regexp_replace(regexp_replace(b.direccion_1,
                                                                                                                                                                                                                                     'KR', 'CR'),'#',''),
                                                                                                                                                                                                                      ' ', ''))*/
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_11,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_11,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_11,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_1, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_12,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_12,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_12,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_2, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_13,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_13,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_13,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_3, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_14,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_14,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_14,
                                                                  ' ', '')) > 90)
              --   and to_date(b.fecha_de_primer_reporte_4, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_15,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_15,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_15,
                                                                  ' ', '')) > 90)
              --   and to_date(b.fecha_de_primer_reporte_4, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_16,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_16,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_16,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_5, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_17,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_17,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_17,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_6, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_18,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_18,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_18,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_7, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_19,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_19,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_19,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_8, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'SI'
       WHERE y.cvacct IN
             (SELECT a.cvacct
                FROM fraude.tbl_fraude_fija_j a, datos_ubicacion b
               WHERE a.cvanid = b.numero_identificacion
                 AND (utl_match.edit_distance_similarity(REPLACE(a.telefono1,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_20,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono2,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_20,
                                                                  ' ', '')) > 90 OR
                     utl_match.edit_distance_similarity(REPLACE(a.telefono3,
                                                                 ' ', ''),
                                                         REPLACE(b.telefono_20,
                                                                  ' ', '')) > 90)
              --and to_date(b.fecha_de_primer_reporte_9, 'dd/mm/yyyy') <=  to_date('01/01/2018','dd/mm/yyyy')
              );
   
      COMMIT;
   
      UPDATE tbl_fraude_fija_j y
         SET y.coincid_tel_buro = 'NO'
       WHERE y.coincid_tel_buro IS NULL;
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_error := SQLCODE;
         p_vc_error := 'Error al actualizar campos de buro s ' || SQLERRM;
   END actualiza_buro_telefono;
END proceso_fraude_fija;
/

