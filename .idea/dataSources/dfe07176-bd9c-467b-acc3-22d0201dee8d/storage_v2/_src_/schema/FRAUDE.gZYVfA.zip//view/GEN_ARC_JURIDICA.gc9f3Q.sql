create view GEN_ARC_JURIDICA as
select "SENTENCIA" from (
select
'SET PAGESIZE 0
SET ECHO OFF
SET FEEDBACK OFF
SET HEADING on
SET LINESIZE 1500
spool d:\incumplimientos_juridica\reporte\'||m.nombre_archivo||'.csv'||chr(59)||'
prompt documento;custcode;customer_id;contrato;min;fec_activacion;razon_social;ciudad;plan;modelo;cod_distribuidor;distribuidor;nit_distribuidor;vr_equipo;vr_comcel;tipo_de_incumplimiento;distribuidor_refuta;REFUTACION;APLICA_INCUMPLIMIENTO;observaciones
Select
E.documento||'||chr(39)||';'||chr(39)||'||
E.custcode||'||chr(39)||';'||chr(39)||'||
E.customer_id||'||chr(39)||';'||chr(39)||'||
E.contrato||'||chr(39)||';'||chr(39)||'||
E.min||'||chr(39)||';'||chr(39)||'||
E.fec_activacion||'||chr(39)||';'||chr(39)||'||
E.razon_social||'||chr(39)||';'||chr(39)||'||
E.ciudad||'||chr(39)||';'||chr(39)||'||
E.plan||'||chr(39)||';'||chr(39)||'||
E.modelo||'||chr(39)||';'||chr(39)||'||
E.cod_distribuidor||'||chr(39)||';'||chr(39)||'||
E.distribuidor||'||chr(39)||';'||chr(39)||'||
E.nit_distribuidor||'||chr(39)||';'||chr(39)||'||
E.vr_equipo||'||chr(39)||';'||chr(39)||'||
E.vr_comcel||'||chr(39)||';'||chr(39)||'||
E.tipo_de_incumplimiento||'||chr(39)||';'||chr(39)||'||
E.distribuidor_refuta||'||chr(39)||';'||chr(39)||'||
E.REFUTACION||'||chr(39)||';'||chr(39)||'||
E.APLICA_INCUMPLIMIENTO||'||chr(39)||';'||chr(39)||'||
E.observaciones
from incumplimientos_juridica e
where e.nit_distribuidor = '||chr(39)||trim(m.nit)||chr(39)||chr(59)||'
SPOOL OFF'||chr(59) as sentencia
from email_distr_biometria m
)
/

