create PACKAGE BODY radic_movil_analisis_pkg IS

  --FUNCION QUE DEVUELVE EL TIPO DE CANAL 
   FUNCTION fn_canal_cod_coddistri(vc_cod_distri VARCHAR2) RETURN VARCHAR IS
      rta VARCHAR2(50);
   BEGIN
      SELECT a.canal || '-' || a.subcanal
        INTO rta
        FROM agentes_netezza a
       WHERE a.custcode_agente = vc_cod_distri
         AND rownum = 1;
   
      RETURN(rta);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN rta;
   END fn_canal_cod_coddistri;
   
   PROCEDURE inserta_tramite(vc_custcode               radic_movil_data.custcode%TYPE,
                             vc_cod_comentario         radic_movil_data.cod_comentario%TYPE,
                             vc_cod_diagnostico        radic_movil_data.cod_diagnostico%TYPE,
                             vc_desc_diagnostico       radic_movil_data.desc_diagnostico%TYPE,
                             vc_nombre_analista        radic_movil_data.nombre_analista%TYPE,
                             vc_fecha_radicacion       radic_movil_data.fecha_radicacion%TYPE,
                             vc_tipo_doc_cliente       radic_movil_data.tipo_doc_cliente%TYPE,
                             vc_numero_doc_cliente     radic_movil_data.numero_doc_cliente%TYPE,
                             vc_nombre_cliente         radic_movil_data.nombre_cliente%TYPE,
                             vc_tipo_cliente           radic_movil_data.tipo_cliente%TYPE,
                             vc_co_id                  radic_movil_data.co_id%TYPE,
                             vc_estado                 radic_movil_data.estado%TYPE,
                             vc_fecha_activacion       radic_movil_data.fecha_activacion%TYPE,
                             vc_fecha_desactivacion    radic_movil_data.fecha_desactivacion%TYPE,
                             vc_causal                 radic_movil_data.causal%TYPE,
                             vc_tmcode                 radic_movil_data.tmcode%TYPE,
                             vc_tmcode_desc            radic_movil_data.tmcode_desc%TYPE,
                             vc_dealer                 radic_movil_data.dealer%TYPE,
                             vc_cod_distri             radic_movil_data.cod_distri%TYPE,
                             vc_cod_distri_nit         radic_movil_data.cod_distri_nit%TYPE,
                             vc_cod_distri_name        radic_movil_data.cod_distri_name%TYPE,
                             vc_activa_user            radic_movil_data.activa_user%TYPE,
                             vc_activa_ciudad          radic_movil_data.activa_ciudad%TYPE,
                             vc_activa_min             radic_movil_data.activa_min%TYPE,
                             vc_activa_user_habilitado radic_movil_data.activa_user_habilitado%TYPE,
                             vc_observacion            radic_movil_data.observacion%TYPE,
                             p_nm_resp                 OUT NUMBER,
                             p_vc_resp                 OUT VARCHAR2) IS
   
      ln_consecutivo LONG;
      nm_valida      NUMBER := 0;
   BEGIN
      p_nm_resp := 0;
   
      --BUSCAR QUE EL MISMO CLIENTE TENGA LA MISMA INFO EN LAS DOS BD. PARA NO DUPLICAR MENSAJES
      SELECT COUNT('1')
        INTO nm_valida
        FROM radic_movil_data p
       WHERE p.custcode = vc_custcode;
   
      IF nm_valida = 0 THEN
         ln_consecutivo := radic_movil_data_seq.nextval;
      
         INSERT INTO radic_movil_data
            (consecutivo, custcode, cod_comentario, cod_diagnostico,
             desc_diagnostico, nombre_analista, fecha_radicacion,
             tipo_cliente, co_id, estado, fecha_activacion,
             fecha_desactivacion, causal, tmcode, tmcode_desc, dealer,
             cod_distri, cod_distri_nit, cod_distri_name, activa_user,
             activa_ciudad, activa_min, activa_user_habilitado,
             fecha_eje_proceso, observacion, tipo_doc_cliente,
             numero_doc_cliente, nombre_cliente)
         VALUES
            (ln_consecutivo, vc_custcode, vc_cod_comentario,
             vc_cod_diagnostico, vc_desc_diagnostico, vc_nombre_analista,
             vc_fecha_radicacion, vc_tipo_cliente, vc_co_id, vc_estado,
             vc_fecha_activacion, vc_fecha_desactivacion, vc_causal,
             vc_tmcode, vc_tmcode_desc, vc_dealer, vc_cod_distri,
             vc_cod_distri_nit, vc_cod_distri_name, vc_activa_user,
             vc_activa_ciudad, vc_activa_min, vc_activa_user_habilitado,
             SYSDATE, vc_observacion, vc_tipo_doc_cliente,
             vc_numero_doc_cliente, vc_nombre_cliente);
      
         COMMIT;
      ELSE
         p_nm_resp := 0;
         p_vc_resp := 'Custcode ya se encuentran registrados';
      END IF;
   
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -1;
         p_vc_resp := SQLERRM;
   END inserta_tramite;

   PROCEDURE actualiza_tramite(vc_tipo   radic_bloqueo_users.tipo%TYPE,
                               vc_valor  radic_movil_data.activa_user%TYPE,
                               p_nm_resp OUT NUMBER,
                               p_vc_resp OUT VARCHAR2) IS
   
   BEGIN
      p_vc_resp := 'OK';
      p_nm_resp := 0;
   
      IF vc_tipo = 'CVC' THEN
         UPDATE radic_movil_data a
            SET a.aplica_bloqueo_user = 'BLOQUEADO POR USUARIO - ' ||
                                         to_char(SYSDATE,
                                                 'dd/mm/yyyy hh24:mi:ss')
          WHERE a.activa_user = vc_valor
            AND a.aplica_bloqueo_user IS NULL;
      ELSE
         UPDATE radic_movil_data a
            SET a.aplica_bloqueo_user = 'BLOQUEADO POR DISTRIBUIDOR - ' ||
                                         to_char(SYSDATE,
                                                 'dd/mm/yyyy hh24:mi:ss')
          WHERE a.cod_distri = vc_valor
            AND a.aplica_bloqueo_user IS NULL;
      
      END IF;
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -3;
         p_vc_resp := SQLERRM;
   END actualiza_tramite;

   PROCEDURE consulta_usuario_est(p_nm_max        IN NUMBER,
                                  p_vc_tipo       IN VARCHAR2,
                                  f_inicial       IN VARCHAR2,
                                  f_final         IN VARCHAR2,
                                  p_cur_resultado OUT SYS_REFCURSOR,
                                  p_nm_resp       OUT NUMBER,
                                  p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      IF p_vc_tipo = 'CVC' THEN
      
         OPEN p_cur_resultado FOR
            SELECT consulta.cod_distri, consulta.activa_user,
                   consulta.activa_user_habilitado, consulta.tramite,
                   consulta.cod_distri_name, fn_canal_cod_coddistri(consulta.cod_distri), COUNT(*) cantidad
              FROM (SELECT a.numero_doc_cliente, a.activa_user,
                            a.activa_user_habilitado, a.cod_distri,
                            decode(a.observacion, '', 'VENTA', 'EQUIPO_FINANC') tramite,
                            a.cod_distri_name
                       FROM radic_movil_data a
                      WHERE a.activa_user IS NOT NULL
                        AND a.activa_user_habilitado NOT IN ('0')
                           --Modificacion 18/11/2019 La estadistica solo debe llevar lo de los 3 meses
                           -- AND to_date(substr(a.fecha_radicacion, 0, 10),'dd/mm/yyyy') >= SYSDATE - 90
                        AND to_date(substr(a.fecha_activacion, 0, 10),
                                    'dd/mm/yyyy') BETWEEN
                            to_date(f_inicial, 'dd/mm/yyyy') AND
                            to_date(f_final, 'dd/mm/yyyy')
                      GROUP BY a.numero_doc_cliente, a.activa_user,
                               a.activa_user_habilitado, a.cod_distri,
                               a.cod_distri,
                               decode(a.observacion, '', 'VENTA',
                                       'EQUIPO_FINANC'), a.cod_distri_name) consulta
             WHERE substr(consulta.cod_distri, 0, 1) IN ('A', 'C')
               AND consulta.activa_user NOT IN
                   (SELECT j.usuario
                      FROM radic_bloqueo_users j
                     WHERE j.usuario = consulta.activa_user
                       AND j.observacion_analista IS NOT NULL)
               AND consulta.activa_user NOT IN
                   (SELECT TRIM(o.usuario_poliedro)
                      FROM radic_usuarios_back_office o)
             GROUP BY consulta.cod_distri, consulta.activa_user,
                      consulta.activa_user_habilitado, consulta.tramite,
                      -- consulta.cod_distri,
                      consulta.cod_distri_name
            HAVING COUNT(*) > p_nm_max
             ORDER BY cantidad DESC;
      
      ELSE
         OPEN p_cur_resultado FOR
            SELECT consulta.cod_distri, consulta.activa_user,
                   consulta.activa_user_habilitado, consulta.tramite,
                   consulta.cod_distri_name, fn_canal_cod_coddistri(consulta.cod_distri),  COUNT(*) cantidad
              FROM (SELECT a.numero_doc_cliente, a.activa_user,
                            a.activa_user_habilitado, a.cod_distri,
                            decode(a.observacion, '', 'VENTA', 'EQUIPO_FINANC') tramite,
                            a.cod_distri_name
                       FROM radic_movil_data a
                      WHERE a.activa_user IS NOT NULL
                        AND a.activa_user_habilitado NOT IN ('0')
                           --Modificacion 18/11/2019 La estadistica solo debe llevar lo de los 3 meses
                           --AND to_date(substr(a.fecha_radicacion, 0, 10),'dd/mm/yyyy') >= SYSDATE - 90
                        AND to_date(substr(a.fecha_activacion, 0, 10),
                                    'dd/mm/yyyy') BETWEEN
                            to_date(f_inicial, 'dd/mm/yyyy') AND
                            to_date(f_final, 'dd/mm/yyyy')
                      GROUP BY a.numero_doc_cliente, a.activa_user,
                               a.activa_user_habilitado, a.cod_distri,
                               a.cod_distri,
                               decode(a.observacion, '', 'VENTA',
                                       'EQUIPO_FINANC'), a.cod_distri_name) consulta
             WHERE substr(consulta.cod_distri, 0, 1) NOT IN ('A', 'C')
               AND consulta.activa_user NOT IN
                   (SELECT j.usuario
                      FROM radic_bloqueo_users j
                     WHERE j.usuario = consulta.activa_user
                       AND j.observacion_analista IS NOT NULL)
               AND consulta.activa_user NOT IN
                   (SELECT TRIM(o.usuario_poliedro)
                      FROM radic_usuarios_back_office o)
             GROUP BY consulta.cod_distri, consulta.activa_user,
                      consulta.activa_user_habilitado, consulta.tramite,
                      consulta.cod_distri_name
            HAVING COUNT(*) > p_nm_max
             ORDER BY cantidad DESC;
      END IF;
   
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := -1203;
         p_vc_resp       := 'Error al generar cursor de estadistica de usuario  : ' ||
                            SQLERRM;
         p_cur_resultado := NULL;
   END consulta_usuario_est;

   PROCEDURE inserta_bloqueo_usuario(vc_tipo            IN radic_bloqueo_users.tipo%TYPE,
                                     vc_cod_distri      IN radic_bloqueo_users.cod_distri%TYPE,
                                     vc_usuario         IN radic_bloqueo_users.usuario%TYPE,
                                     vc_cod_distri_name IN radic_bloqueo_users.nombre%TYPE,
                                     vc_habilitado      IN radic_bloqueo_users.activa_user_habilitado%TYPE,
                                     vc_tramite         IN radic_bloqueo_users.tramite%TYPE,
                                     vc_cantidad        IN radic_bloqueo_users.cantidad%TYPE,
                                     --09/08/2020 Inclusion de cantidad de ventas
                                     vc_fec_inicial IN VARCHAR2,
                                     vc_fec_final   IN VARCHAR2,
                                     --Fin inclusion
                                     p_nm_resp OUT NUMBER,
                                     p_vc_resp OUT VARCHAR2) IS
   
      ln_consecutivo LONG;
      nm_valida      NUMBER := 0;
   
      --09/08/2020 Inclusion de cantidad de ventas
      nm_cant_kit_financiado NUMBER := 0;
      nm_cant_ventas_movil   NUMBER := 0;
      nm_cant_repos_movil    NUMBER := 0;
   
      nm_cant_kit_coddistri    NUMBER := 0;
      nm_cant_ventas_coddistri NUMBER := 0;
      nm_cant_repos_coddistri  NUMBER := 0;
      --Fin inclusion   
   
   BEGIN
      p_vc_resp := 'OK';
      p_nm_resp := 0;
   
      --BUSCAR QUE EL MISMO CLIENTE TENGA LA MISMA INFO EN LAS DOS BD. PARA NO DUPLICAR MENSAJES
      SELECT COUNT('1')
        INTO nm_valida
        FROM radic_bloqueo_users p
       WHERE p.usuario = vc_usuario
         AND p.cod_distri = vc_cod_distri
         AND p.tipo = vc_tipo
         AND p.tramite = vc_tramite
         AND p.estado = '2';
   
      IF nm_valida = 0 THEN
      
         ln_consecutivo := radic_bloqueo_users_seq.nextval;
      
         INSERT INTO radic_bloqueo_users
            (consecutivo, tipo, usuario, cod_distri, nombre,
             activa_user_habilitado, tramite, cantidad, estado, feha_proceso)
         VALUES
            (ln_consecutivo, vc_tipo, vc_usuario, vc_cod_distri,
             vc_cod_distri_name, vc_habilitado, vc_tramite, vc_cantidad, '2',
             to_char(SYSDATE, 'dd/mm/yyyy hh24:mi:ss'));
      
         COMMIT;
      
         --09/08/2020 inclusion de cantidad de ventas y tramites del usuario       
         nm_cant_kit_financiado := fn_cantidad_kit_financiado(f_inicial => vc_fec_inicial,
                                                              f_final => vc_fec_final,
                                                              usuario => vc_usuario);
      
         nm_cant_ventas_movil := fn_cantidad_ventas_movil(f_inicial => vc_fec_inicial,
                                                          f_final => vc_fec_final,
                                                          usuario => vc_usuario);
      
         nm_cant_repos_movil := fn_cantidad_repos_movil(f_inicial => vc_fec_inicial,
                                                        f_final => vc_fec_final,
                                                        usuario => vc_usuario);
      
         nm_cant_kit_coddistri := fn_cant_kit_coddistr(f_inicial => vc_fec_inicial,
                                                       f_final => vc_fec_final,
                                                       cod_distribuidor => vc_cod_distri);
      
         nm_cant_ventas_coddistri := fn_cant_ventasm_coddistri(f_inicial => vc_fec_inicial,
                                                               f_final => vc_fec_final,
                                                               cod_distribuidor => vc_cod_distri);
      
         nm_cant_repos_coddistri := fn_cant_repos_coddistri(f_inicial => vc_fec_inicial,
                                                            f_final => vc_fec_final,
                                                            cod_distribuidor => vc_cod_distri);
      
         INSERT INTO radic_bloqueo_users_estadis
            (consecutivo, feha_proceso, cod_distribuidor, usuario,
             fecha_inicio, fecha_fin, cantidad_fraude, cant_ventas_usu,
             cant_kit_usu, cant_ventas_cod_distri, cant_kit_cod_distri)
         VALUES
            (ln_consecutivo, to_char(SYSDATE, 'dd/mm/yyyy hh24:mi:ss'), vc_cod_distri, vc_usuario,
             vc_fec_inicial, vc_fec_final, vc_cantidad, nm_cant_ventas_movil,
             nm_cant_kit_financiado, nm_cant_ventas_coddistri, nm_cant_kit_coddistri);
      
         COMMIT;
         -- Fin inclusion
      ELSE
         p_nm_resp := 0;
         p_vc_resp := 'Usuario o Distribuidor ya habia sido registrado';
      END IF;
   
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -2;
         p_vc_resp := SQLERRM;
   END inserta_bloqueo_usuario;

   PROCEDURE proceso_doc_inv(vc_doc_cliente  radic_movil_data.numero_doc_cliente%TYPE,
                             vc_tipo_cliente radic_movil_data.tipo_doc_cliente%TYPE,
                             p_nm_resp       OUT NUMBER,
                             p_vc_resp       OUT VARCHAR2) IS
   
   BEGIN
      p_vc_resp := 'OK';
      p_nm_resp := 0;
   
      UPDATE radic_movil_data a
         SET a.activa_doc_bloqueado = 'BLOQUEADO DOC INVALIDOS - ' ||
                                       to_char(SYSDATE,
                                               'dd/mm/yyyy hh24:mi:ss')
       WHERE a.numero_doc_cliente = vc_doc_cliente
         AND a.tipo_doc_cliente = vc_tipo_cliente
         AND a.activa_doc_bloqueado IS NULL;
   
      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -3;
         p_vc_resp := SQLERRM;
   END proceso_doc_inv;

   --Usuario:LC
   --Fecha:24/06/2020

   --FUNCION KIT FINANCIADO
   FUNCTION fn_cantidad_kit_financiado(f_inicial VARCHAR2,
                                       f_final   VARCHAR2,
                                       usuario   VARCHAR2) RETURN NUMBER IS
      RESULT NUMBER;
   BEGIN
      SELECT COUNT(1)
        INTO RESULT
        FROM kit_equipo_financiado
       WHERE TRIM(text1) = TRIM(usuario)
         AND to_date(substr(fecregis, 0, 10), 'dd/mm/yyyy') BETWEEN
             to_date(f_inicial, 'dd/mm/yyyy') AND
             to_date(f_final, 'dd/mm/yyyy');
      RETURN(RESULT);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN 0;
   END;

   --FUNCION VENTAS MOVIL
   FUNCTION fn_cantidad_ventas_movil(f_inicial VARCHAR2,
                                     f_final   VARCHAR2,
                                     usuario   VARCHAR2) RETURN NUMBER IS
      RESULT NUMBER;
   BEGIN
      SELECT COUNT(1)
        INTO RESULT
        FROM ventas_movil
       WHERE TRIM(codigo_usuario) = TRIM(usuario)
         AND to_date(substr(fecregis, 0, 10), 'dd/mm/yyyy') BETWEEN
             to_date(f_inicial, 'dd/mm/yyyy') AND
             to_date(f_final, 'dd/mm/yyyy')
       GROUP BY codigo_usuario;
      RETURN(RESULT);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN 0;
   END;

   --FUNCION REPOS MOVIL
   FUNCTION fn_cantidad_repos_movil(f_inicial VARCHAR2,
                                    f_final   VARCHAR2,
                                    usuario   VARCHAR2) RETURN NUMBER IS
      RESULT NUMBER;
   BEGIN
      SELECT COUNT(1)
        INTO RESULT
        FROM repos_diario_repo
       WHERE TRIM(cod_usuario) = TRIM(usuario)
         AND to_date(substr(fecregis, 0, 10), 'dd/mm/yyyy') BETWEEN
             to_date(f_inicial, 'dd/mm/yyyy') AND
             to_date(f_final, 'dd/mm/yyyy');
      RETURN(RESULT);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN 0;
   END;

   --FUNCION KIT PREPAGO POR DISTRIBUIDOR
   FUNCTION fn_cant_kit_coddistr(f_inicial        VARCHAR2,
                                 f_final          VARCHAR2,
                                 cod_distribuidor VARCHAR2) RETURN NUMBER IS
      RESULT NUMBER;
   BEGIN
      SELECT COUNT(1)
        INTO RESULT
        FROM kit_equipo_financiado
       WHERE TRIM(coddistri) = TRIM(cod_distribuidor)
         AND to_date(substr(fecregis, 0, 10), 'dd/mm/yyyy') BETWEEN
             to_date(f_inicial, 'dd/mm/yyyy') AND
             to_date(f_final, 'dd/mm/yyyy');
      RETURN(RESULT);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN 0;
   END;

   --FUNCION VENTAS MOVIL POR DISTRIBUIDOR
   FUNCTION fn_cant_ventasm_coddistri(f_inicial        VARCHAR2,
                                      f_final          VARCHAR2,
                                      cod_distribuidor VARCHAR2) RETURN NUMBER IS
      RESULT NUMBER;
   BEGIN
      SELECT COUNT(1)
        INTO RESULT
        FROM ventas_movil
       WHERE TRIM(codigo_distribuidor) = TRIM(cod_distribuidor)
         AND to_date(substr(fecregis, 0, 10), 'dd/mm/yyyy') BETWEEN
             to_date(f_inicial, 'dd/mm/yyyy') AND
             to_date(f_final, 'dd/mm/yyyy')
       GROUP BY codigo_distribuidor;
      RETURN(RESULT);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN 0;
   END;

   --FUNCION REPOS MOVIL POR DISTRIBUIDOR
   FUNCTION fn_cant_repos_coddistri(f_inicial        VARCHAR2,
                                    f_final          VARCHAR2,
                                    cod_distribuidor VARCHAR2) RETURN NUMBER IS
      RESULT NUMBER;
   BEGIN
      SELECT COUNT(1)
        INTO RESULT
        FROM repos_diario_repo
       WHERE TRIM(coddistri) = TRIM(cod_distribuidor)
         AND to_date(substr(fecregis, 0, 10), 'dd/mm/yyyy') BETWEEN
             to_date(f_inicial, 'dd/mm/yyyy') AND
             to_date(f_final, 'dd/mm/yyyy');
      RETURN(RESULT);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN 0;
   END;

   PROCEDURE pr_cons_estadistica(vc_usuario         IN VARCHAR2,
                                 vc_cod_distri      IN VARCHAR2,
                                 vc_tipo            IN VARCHAR2,
                                 nm_cant_rad        IN NUMBER,
                                 p_nm_consecutivo   OUT NUMBER,
                                 p_nm_total_tramite OUT NUMBER,
                                 p_nm_indic_fraude  OUT NUMBER,
                                 p_nm_resp          OUT NUMBER,
                                 p_vc_resp          OUT VARCHAR2) IS
   
      nm_consecutivo NUMBER := 0;
   BEGIN
      p_vc_resp := 'OK';
      p_nm_resp := 0;
   
      SELECT a.consecutivo
        INTO nm_consecutivo
        FROM radic_bloqueo_users a
       WHERE a.tipo = vc_tipo
         AND a.usuario = vc_usuario
         AND a.cod_distri = vc_cod_distri;
   
      IF vc_tipo = 'CVC' THEN
         SELECT a.consecutivo,
                nvl(SUM(a.cant_ventas_usu + a.cant_kit_usu), 0),
                round(nvl((nm_cant_rad /
                           SUM(a.cant_ventas_usu + a.cant_kit_usu)) * 100, 0),
                       2)
           INTO p_nm_consecutivo, p_nm_total_tramite, p_nm_indic_fraude
           FROM radic_bloqueo_users_estadis a
          WHERE a.consecutivo = nm_consecutivo
          GROUP BY a.consecutivo;
          
          update radic_bloqueo_users_estadis b
           set b.porcentaje= p_nm_indic_fraude
          where b.consecutivo=nm_consecutivo;
          
          commit;
      ELSE
         SELECT a.consecutivo,
                nvl(SUM(a.cant_ventas_usu + a.cant_kit_usu), 0),
                round(nvl((nm_cant_rad /
                           SUM(a.cant_ventas_cod_distri +
                                a.cant_kit_cod_distri)) * 100, 0), 2)
           INTO p_nm_consecutivo, p_nm_total_tramite, p_nm_indic_fraude
           FROM radic_bloqueo_users_estadis a
          WHERE a.consecutivo = nm_consecutivo
          GROUP BY a.consecutivo;
          
            
          update radic_bloqueo_users_estadis b
           set b.porcentaje= p_nm_indic_fraude
          where b.consecutivo=nm_consecutivo;
          
          commit;
      END IF;
   
   EXCEPTION
      WHEN OTHERS THEN
      
         p_nm_resp := -4;
         p_vc_resp := SQLERRM;
   END pr_cons_estadistica;

   --FUNCION REPOS MOVIL POR DISTRIBUIDOR
   FUNCTION fn_es_radicado_fraude(vc_coid  radic_movil_data.co_id%type) 
     RETURN NUMBER IS
      RESULT NUMBER;
   BEGIN
      SELECT COUNT(1)
        INTO RESULT
        FROM radic_movil_data s
       WHERE trim(s.co_id)=trim(vc_coid);
      RETURN(RESULT);
   EXCEPTION
      WHEN no_data_found THEN
         RETURN 0;
   END;
 
END radic_movil_analisis_pkg;
/

