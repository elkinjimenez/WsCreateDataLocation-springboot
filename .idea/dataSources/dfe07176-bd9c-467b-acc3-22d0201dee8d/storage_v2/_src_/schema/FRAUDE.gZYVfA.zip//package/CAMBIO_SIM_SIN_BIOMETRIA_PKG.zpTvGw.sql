create PACKAGE cambio_sim_sin_biometria_pkg IS

   -- Author  : ICM0613A
   -- Created : 19/03/2020 5:54:50 p. m.
   PROCEDURE correos_cliente(p_hora          IN NUMBER,
                             p_cur_resultado OUT SYS_REFCURSOR,
                             p_nm_resp       OUT NUMBER,
                             p_vc_resp       OUT VARCHAR2);

    PROCEDURE pr_actualiza(p_vc_consecutivo IN VARCHAR2,
                            p_vc_resultado IN VARCHAR2,
                            p_nm_resp        OUT NUMBER,
                            p_vc_resp        OUT VARCHAR2);

END cambio_sim_sin_biometria_pkg;
/

