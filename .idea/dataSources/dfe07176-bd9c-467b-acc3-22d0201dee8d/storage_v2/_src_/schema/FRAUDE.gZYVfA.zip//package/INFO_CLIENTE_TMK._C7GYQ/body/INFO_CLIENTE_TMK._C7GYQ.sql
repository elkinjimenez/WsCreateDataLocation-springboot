create PACKAGE BODY info_cliente_tmk IS

   PROCEDURE buscar_documento(p_cur_resultado OUT SYS_REFCURSOR,
                              p_nm_resp       OUT NUMBER,
                              p_vc_resp       OUT VARCHAR2) IS
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      OPEN p_cur_resultado FOR
         SELECT DISTINCT a.documento FROM clientes_tmk_doc a;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := SQLCODE;
         p_vc_resp       := SQLERRM;
         p_cur_resultado := NULL;
   END buscar_documento;

   PROCEDURE insertarinfo(p_vc_num_cel         IN VARCHAR2,
                          p_vc_co_id           IN VARCHAR2,
                          p_vc_numero_doc      IN VARCHAR2,
                          p_vc_nombre          IN VARCHAR2,
                          p_vc_tel_contacto    IN VARCHAR2,
                          p_vc_direccion       IN VARCHAR2,
                          p_vc_ciudad          IN VARCHAR2,
                          p_vc_custcode        IN VARCHAR2,
                          p_vc_cod_plan        IN VARCHAR2,
                          p_vc_tipo_linea      IN VARCHAR2,
                          p_vc_fecha_act       IN VARCHAR2,
                          p_vc_saldo           IN VARCHAR2,
                          p_vc_fecha_mod_saldo IN VARCHAR2,
                          p_nm_resp            OUT NUMBER,
                          p_vc_resp            OUT VARCHAR2) IS
   BEGIN
      p_nm_resp := 0;
      p_vc_resp := 'OK';
   
      INSERT INTO clientes_ac_rr_info
         (num_celular, co_id, numero_doc, nombre, telefonos_contacto,
          direccion, ciudad, custcode, cod_plan, tipo_linea,
          fecha_activacion, saldo, csmoddate)
      VALUES
         (p_vc_num_cel, p_vc_co_id, p_vc_numero_doc, p_vc_nombre,
          p_vc_tel_contacto, p_vc_direccion, p_vc_ciudad, p_vc_custcode,
          p_vc_cod_plan, p_vc_tipo_linea, p_vc_fecha_act, p_vc_saldo,
          p_vc_fecha_mod_saldo);
          
        commit;
   EXCEPTION
      WHEN OTHERS THEN
         p_nm_resp       := SQLCODE;
         p_vc_resp       := SQLERRM;
         
   END insertarinfo;

END info_cliente_tmk;
/

